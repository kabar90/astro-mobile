
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../main.dart';
import '../models/product.dart';
import '../widgets/astro_cached_image.dart';
import 'account_screen.dart';
import 'product_detail_screen.dart';

class ProductInquiryInline extends StatefulWidget {
  final int categoryId;
  final String categoryName;

  const ProductInquiryInline({
    super.key,
    required this.categoryId,
    required this.categoryName,
  });

  @override
  State<ProductInquiryInline> createState() => _ProductInquiryInlineState();
}

class _ProductInquiryInlineState extends State<ProductInquiryInline> {
  final _db = Supabase.instance.client;
  final _model = TextEditingController();
  final _note = TextEditingController();
  bool _sending = false;
  bool _loading = true;
  List<Map<String, dynamic>> _items = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(covariant ProductInquiryInline oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.categoryId != widget.categoryId) _load();
  }

  @override
  void dispose() {
    _model.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final user = _db.auth.currentUser;
    if (user == null) {
      if (mounted) setState(() { _items = []; _loading = false; });
      return;
    }
    if (mounted) setState(() => _loading = true);
    try {
      final rows = await _db.from('product_inquiries')
          .select()
          .eq('user_id', user.id)
          .eq('category_id', widget.categoryId)
          .order('created_at', ascending: false);
      if (!mounted) return;
      setState(() {
        _items = List<Map<String, dynamic>>.from(rows);
        _loading = false;
      });
    } catch (e) {
      debugPrint('ASTRO inline inquiry load: $e');
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _send() async {
    final user = _db.auth.currentUser;
    if (user == null) {
      _message('سجّل الدخول أولاً لإرسال استفسار.');
      Navigator.push(context, MaterialPageRoute(
        builder: (_) => const AccountScreen(),
      )).then((_) => _load());
      return;
    }
    final model = _model.text.trim();
    if (model.length < 2) {
      _message('اكتب موديل الجهاز أولاً.');
      return;
    }
    setState(() => _sending = true);
    try {
      await _db.from('product_inquiries').insert({
        'user_id': user.id,
        'category_id': widget.categoryId,
        'device_model': model,
        'customer_note': _note.text.trim().isEmpty ? null : _note.text.trim(),
      });
      _model.clear();
      _note.clear();
      _message('تم إرسال طلبك. سنراجع التوفر ونرسل لك الخيارات هنا.');
      await _load();
    } catch (e) {
      debugPrint('ASTRO inline inquiry submit: $e');
      _message('تعذر إرسال الاستفسار. حاول مرة أخرى.');
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  void _message(String value) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(value), behavior: SnackBarBehavior.floating),
    );
  }

  String _status(String value) {
    switch (value) {
      case 'in_progress': return 'قيد المراجعة';
      case 'answered': return 'تم الرد';
      case 'closed': return 'مغلق';
      default: return 'جديد';
    }
  }

  Future<List<Product>> _products(dynamic ids) async {
    if (ids is! List || ids.isEmpty) return [];
    try {
      final rows = await _db.from('products').select()
          .inFilter('id', ids.map((e) => e.toString()).toList());
      return List<Map<String, dynamic>>.from(rows)
          .map((r) => Product.fromMap(r['id'].toString(), r)).toList();
    } catch (_) { return []; }
  }

  Widget _replyCard(Map<String, dynamic> item) {
    final status = (item['status'] ?? 'new').toString();
    final reply = (item['admin_reply'] ?? '').toString().trim();
    final ids = item['recommended_product_ids'];
    return Container(
      margin: const EdgeInsets.only(top: 8),
      padding: const EdgeInsets.all(11),
      decoration: BoxDecoration(
        color: const Color(0xFFF7FAFE),
        border: Border.all(color: const Color(0xFFE2ECF7)),
        borderRadius: BorderRadius.circular(13),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(child: Text('جهاز: ${item['device_model'] ?? ''}',
            style: const TextStyle(fontWeight: FontWeight.w800, color: astroNavy))),
          Text(_status(status), style: const TextStyle(
            color: astroBlue, fontSize: 11, fontWeight: FontWeight.w800)),
        ]),
        if (reply.isNotEmpty) ...[
          const SizedBox(height: 7),
          Text(reply, style: const TextStyle(height: 1.45)),
        ],
        if (status == 'answered' && ids is List && ids.isNotEmpty)
          FutureBuilder<List<Product>>(
            future: _products(ids),
            builder: (context, snap) {
              final products = snap.data ?? [];
              if (snap.connectionState == ConnectionState.waiting) {
                return const Padding(padding: EdgeInsets.all(8),
                  child: LinearProgressIndicator());
              }
              return Column(children: products.map((p) => InkWell(
                onTap: () => Navigator.push(context, MaterialPageRoute(
                  builder: (_) => ProductDetailScreen(product: p))),
                child: Padding(
                  padding: const EdgeInsets.only(top: 9),
                  child: Row(children: [
                    SizedBox(width: 54, height: 54, child: p.imageUrl.isEmpty
                      ? const Icon(Icons.image_outlined)
                      : AstroCachedImage(imageUrl: p.imageUrl, fit: BoxFit.contain)),
                    const SizedBox(width: 9),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(p.name, maxLines: 2, overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontWeight: FontWeight.w800)),
                        if (p.colors.isNotEmpty)
                          Text('الألوان: ${p.colors.join('، ')}',
                            style: const TextStyle(fontSize: 10, color: Colors.black54)),
                        Text('${p.price.toStringAsFixed(0)} د.ل',
                          style: const TextStyle(color: astroBlue, fontWeight: FontWeight.w900)),
                      ])),
                    const Icon(Icons.chevron_left, color: astroBlue),
                  ]),
                ),
              )).toList());
            },
          ),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final signedIn = _db.auth.currentUser != null;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(children: const [
            Icon(Icons.search_rounded, color: astroBlue),
            SizedBox(width: 7),
            Expanded(child: Text('لم تجد المنتج المناسب؟',
              style: TextStyle(color: astroNavy, fontWeight: FontWeight.w900))),
          ]),
          const SizedBox(height: 5),
          Text('اكتب موديل جهازك وسنرسل لك الخيارات المتوافقة والمتوفرة في قسم ${widget.categoryName}.',
            style: const TextStyle(color: Colors.black54, fontSize: 12, height: 1.45)),
          const SizedBox(height: 11),
          TextField(controller: _model,
            decoration: const InputDecoration(
              labelText: 'موديل الجهاز',
              hintText: 'مثال: iPhone 13 Pro Max',
              prefixIcon: Icon(Icons.phone_iphone_rounded))),
          const SizedBox(height: 9),
          TextField(controller: _note, maxLines: 2,
            decoration: const InputDecoration(
              labelText: 'ملاحظة إضافية (اختياري)',
              alignLabelWithHint: true)),
          const SizedBox(height: 10),
          ElevatedButton.icon(
            onPressed: _sending ? null : _send,
            icon: _sending
              ? const SizedBox(width: 17, height: 17,
                  child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
              : const Icon(Icons.send_rounded),
            label: Text(_sending ? 'جارٍ الإرسال...' : 'استفسر عن التوفر'),
          ),
          if (signedIn) ...[
            const SizedBox(height: 13),
            const Text('استفساراتك في هذا القسم',
              style: TextStyle(color: astroNavy, fontWeight: FontWeight.w900)),
            if (_loading)
              const Padding(padding: EdgeInsets.all(12),
                child: Center(child: CircularProgressIndicator()))
            else if (_items.isEmpty)
              const Padding(padding: EdgeInsets.only(top: 8),
                child: Text('لا توجد استفسارات سابقة في هذا القسم.',
                  style: TextStyle(color: Colors.black45, fontSize: 12)))
            else
              ..._items.map(_replyCard),
            Align(alignment: AlignmentDirectional.centerEnd,
              child: TextButton.icon(
                onPressed: _load,
                icon: const Icon(Icons.refresh_rounded, size: 17),
                label: const Text('تحديث الردود'))),
          ],
        ]),
      ),
    );
  }
}

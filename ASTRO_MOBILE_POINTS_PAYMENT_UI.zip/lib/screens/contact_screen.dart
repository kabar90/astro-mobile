import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import '../main.dart';

class ContactScreen extends StatefulWidget {
  const ContactScreen({super.key});

  @override
  State<ContactScreen> createState() => _ContactScreenState();
}

class _ContactScreenState extends State<ContactScreen> {
  Map<String, dynamic> _settings = {};
  bool _loading = true;
  static const _address = 'طرابلس، أبوسليم، شارع أم درمان الرئيسي، بالقرب من شارع السلام';
  static const _mapUrl = 'https://maps.app.goo.gl/17RkmhNwxXHJ5XKi7';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final row = await Supabase.instance.client
          .from('store_contact_settings')
          .select()
          .eq('id', 1)
          .maybeSingle();
      if (mounted) setState(() { _settings = row ?? {}; _loading = false; });
    } catch (e) {
      debugPrint('ASTRO contact settings: $e');
      if (mounted) setState(() => _loading = false);
    }
  }

  String _value(String key, [String fallback = '']) =>
      (_settings[key] ?? fallback).toString().trim();

  Future<void> _open(String value) async {
    final uri = Uri.tryParse(value);
    if (uri == null) return;
    try {
      if (!await launchUrl(uri, mode: LaunchMode.externalApplication) && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذر فتح الرابط')));
      }
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذر فتح الرابط')));
    }
  }

  Widget _tile(IconData icon, String title, String subtitle, VoidCallback? onTap, {Color color = astroBlue}) =>
      Card(child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
        leading: Container(width: 46, height: 46,
          decoration: BoxDecoration(color: color.withOpacity(.09), borderRadius: BorderRadius.circular(14)),
          child: Icon(icon, color: color)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900, color: astroNavy)),
        subtitle: subtitle.isEmpty ? null : Text(subtitle, style: const TextStyle(height: 1.5)),
        trailing: onTap == null ? null : const Icon(Icons.arrow_forward_ios_rounded, size: 15),
        onTap: onTap,
      ));

  @override
  Widget build(BuildContext context) {
    final phone = _value('phone');
    final whatsapp = _value('whatsapp');
    final facebook = _value('facebook_url');
    final instagram = _value('instagram_url');
    final tiktok = _value('tiktok_url');
    final hours = _value('working_hours');
    final address = _value('address', _address);
    return Scaffold(
      backgroundColor: astroBackground,
      appBar: AppBar(title: const Text('تواصل معنا')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 28), children: [
                Container(
                  padding: const EdgeInsets.all(22),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [astroNavy, astroBlue], begin: Alignment.topRight, end: Alignment.bottomLeft),
                    borderRadius: BorderRadius.circular(22),
                  ),
                  child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('ASTRO MOBILE', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900, letterSpacing: .6)),
                    SizedBox(height: 7),
                    Text('نسعد بتواصلك معنا', style: TextStyle(color: Colors.white70, fontSize: 15)),
                  ]),
                ),
                const SizedBox(height: 18),
                const Padding(padding: EdgeInsets.symmetric(horizontal: 4, vertical: 7), child: Text('موقع المتجر', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: astroNavy))),
                _tile(Icons.location_on_outlined, 'عنواننا', address, () => _open(_mapUrl), color: Colors.redAccent),
                const Padding(
                  padding: EdgeInsets.fromLTRB(4, 18, 4, 7),
                  child: Text('تواصل مباشر', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: astroNavy)),
                ),
                _tile(
                  Icons.call_outlined,
                  'اتصل بنا',
                  phone.isEmpty ? 'أضف رقم الهاتف من لوحة الإدارة' : phone,
                  phone.isEmpty ? null : () => _open('tel:$phone'),
                  color: Colors.green,
                ),
                _tile(
                  Icons.chat_bubble_outline,
                  'تواصل عبر واتساب',
                  whatsapp.isEmpty ? 'أضف رقم الواتساب من لوحة الإدارة' : whatsapp,
                  whatsapp.isEmpty ? null : () {
                    final digits = whatsapp.replaceAll(RegExp(r'[^0-9+]'), '').replaceFirst(RegExp(r'^\\+'), '');
                    _open('https://wa.me/$digits');
                  },
                  color: const Color(0xFF25D366),
                ),
                const Padding(
                  padding: EdgeInsets.fromLTRB(4, 18, 4, 7),
                  child: Text('صفحات التواصل الاجتماعي', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: astroNavy)),
                ),
                _tile(
                  Icons.facebook,
                  'Facebook',
                  facebook.isEmpty ? 'أضف رابط صفحة Facebook من لوحة الإدارة' : 'تابعنا على Facebook',
                  facebook.isEmpty ? null : () => _open(facebook),
                  color: const Color(0xFF1877F2),
                ),
                _tile(
                  Icons.camera_alt_outlined,
                  'Instagram',
                  instagram.isEmpty ? 'أضف رابط Instagram من لوحة الإدارة' : 'تابعنا على Instagram',
                  instagram.isEmpty ? null : () => _open(instagram),
                  color: const Color(0xFFE1306C),
                ),
                _tile(
                  Icons.music_note_rounded,
                  'TikTok',
                  tiktok.isEmpty ? 'أضف رابط TikTok من لوحة الإدارة' : 'تابعنا على TikTok',
                  tiktok.isEmpty ? null : () => _open(tiktok),
                  color: Colors.black87,
                ),
                if (hours.isNotEmpty) ...[
                  const Padding(
                    padding: EdgeInsets.fromLTRB(4, 18, 4, 7),
                    child: Text('أوقات العمل', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: astroNavy)),
                  ),
                  _tile(Icons.access_time_rounded, 'ساعات الدوام', hours, null, color: Colors.orange),
                ],
                const SizedBox(height: 12),
                const Center(child: Text('ASTRO MOBILE • كل ما تحتاجه من التقنية', style: TextStyle(color: Colors.black45, fontSize: 12))),
              ]),
            ),
    );
  }
}

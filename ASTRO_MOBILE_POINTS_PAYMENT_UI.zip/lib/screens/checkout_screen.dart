import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../main.dart';
import '../services/cart_service.dart';
import 'bank_transfer_screen.dart';
import 'account_screen.dart';
import '../services/notification_service.dart';

class CheckoutScreen extends StatefulWidget {
  const CheckoutScreen({super.key});

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _address = TextEditingController();
  final _db = Supabase.instance.client;

  String _payment = 'cash';
  String _delivery = 'delivery';
  bool _busy = false;
  int _pointsBalance = 0;
  bool _pointsLoading = true;
  bool _citiesLoading = true;
  List<Map<String, dynamic>> _cities = [];
  String? _selectedCityId;

  Map<String, dynamic>? get _selectedCity {
    for (final city in _cities) {
      if (city['id'].toString() == _selectedCityId) return city;
    }
    return null;
  }

  double get _deliveryFee =>
      _delivery == 'delivery' ? ((_selectedCity?['delivery_fee'] as num?)?.toDouble() ?? 0) : 0;

  double get _orderTotal => CartService.instance.total + _deliveryFee;

  @override
  void initState() {
    super.initState();
    _prefillCustomer();
    _loadPointsBalance();
    _loadDeliveryCities();
  }

  void _prefillCustomer() {
    final user = _db.auth.currentUser;
    if (user == null) return;
    final metadata = user.userMetadata ?? {};
    _name.text = (metadata['full_name'] ?? '').toString();
    _phone.text = (metadata['phone'] ?? user.phone ?? '').toString();
  }

  Future<void> _loadDeliveryCities() async {
    try {
      final rows = await _db.from('delivery_cities')
          .select('id,city_name,delivery_fee,estimated_delivery')
          .eq('is_active', true)
          .order('city_name');
      if (!mounted) return;
      setState(() {
        _cities = List<Map<String, dynamic>>.from(rows);
        _citiesLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _citiesLoading = false);
      _message('تعذر تحميل مدن التوصيل: $e');
    }
  }

  Future<void> _loadPointsBalance() async {
    final user = _db.auth.currentUser;
    if (user == null) {
      if (mounted) setState(() => _pointsLoading = false);
      return;
    }
    try {
      final row = await _db
          .from('customer_points')
          .select('balance')
          .eq('user_id', user.id)
          .maybeSingle();
      if (!mounted) return;
      setState(() {
        _pointsBalance = (row?['balance'] as num?)?.toInt() ?? 0;
        _pointsLoading = false;
      });
    } catch (_) {
      if (mounted) setState(() => _pointsLoading = false);
    }
  }

  bool get _cartAllowsPoints {
    final items = CartService.instance.items;
    return items.isNotEmpty && items.every((item) => item.product.allowPointsPayment);
  }

  int get _requiredPoints => (CartService.instance.total * 10).ceil();

  Future<void> _submit() async {
    final cart = CartService.instance;

    if (_db.auth.currentUser == null) {
      _message('يجب إنشاء حساب أو تسجيل الدخول قبل إتمام الطلب');
      return;
    }
    if (cart.items.isEmpty) {
      _message('السلة فارغة');
      return;
    }
    if (_name.text.trim().isEmpty || _phone.text.trim().isEmpty) {
      _message('يرجى إدخال الاسم ورقم الهاتف');
      return;
    }
    if (_delivery == 'delivery' && _selectedCityId == null) {
      _message('يرجى اختيار مدينة التوصيل');
      return;
    }
    if (_delivery == 'delivery' && _address.text.trim().isEmpty) {
      _message('يرجى إدخال عنوان التوصيل');
      return;
    }

    if (_payment == 'points') {
      await _submitPointsOrder();
      return;
    }

    // التحويل المصرفي يفتح صفحة مستقلة لعرض بيانات الحساب
    // وإرفاق إيصال التحويل ثم إرسال الطلب.
    if (_payment == 'transfer') {
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => BankTransferScreen(
            customerName: _name.text.trim(),
            customerPhone: _phone.text.trim(),
            customerAddress:
                _delivery == 'pickup' ? '' : _address.text.trim(),
            deliveryMethod: _delivery,
            deliveryCityId: _selectedCityId,
            deliveryCityName: _selectedCity?['city_name']?.toString(),
            deliveryFee: _deliveryFee,
            deliveryEstimate: _selectedCity?['estimated_delivery']?.toString(),
          ),
        ),
      );
      return;
    }

    setState(() => _busy = true);
    try {
      final items = cart.items.map((item) => {
        'product_id': item.product.id,
        'product_name': item.product.name,
        'quantity': item.quantity,
        'unit_price': item.product.price,
        'color': item.color,
      }).toList();

      final result = await _db.rpc('astro_create_order', params: {
        'p_customer_name': _name.text.trim(),
        'p_customer_phone': _phone.text.trim(),
        'p_customer_address':
            _delivery == 'pickup' ? '' : _address.text.trim(),
        'p_delivery_method': _delivery,
        'p_payment_method': 'cash',
        'p_total_price': cart.total, // قاعدة البيانات تضيف رسوم التوصيل مرة واحدة
        'p_delivery_city': _selectedCityId,
        'p_items': items,
        'p_receipt_path': null,
      });

      await NotificationService.instance.bindCurrentCustomerPhone(_phone.text.trim());
      cart.clear();
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) => AlertDialog(
          title: const Text('تم استلام طلبك بنجاح'),
          content: Text('رقم الطلب: $result\nسنتواصل معك لتأكيد الطلب.'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(dialogContext).pop();
                Navigator.of(context).popUntil((route) => route.isFirst);
              },
              child: const Text('حسناً'),
            ),
          ],
        ),
      );
    } catch (e) {
      if (mounted) _message('تعذر إرسال الطلب: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _submitPointsOrder() async {
    final user = _db.auth.currentUser;
    if (user == null) {
      _message('يجب تسجيل الدخول لاستخدام نقاط المكافآت');
      return;
    }
    if (!_cartAllowsPoints) {
      _message('بعض منتجات السلة غير متاحة للشراء بالنقاط');
      return;
    }
    if (_pointsBalance < _requiredPoints) {
      _message('رصيد النقاط غير كافٍ لإتمام شراء السلة');
      return;
    }

    final pointsToSpend = _requiredPoints;
    setState(() => _busy = true);
    try {
      final items = CartService.instance.items.map((item) => {
        'product_id': item.product.id,
        'quantity': item.quantity,
        'color': item.color,
      }).toList();

      final result = await _db.rpc('astro_create_points_order', params: {
        'p_customer_name': _name.text.trim(),
        'p_customer_phone': _phone.text.trim(),
        'p_customer_address': _delivery == 'pickup' ? '' : _address.text.trim(),
        'p_delivery_method': _delivery,
        'p_items': items,
        'p_delivery_city': _selectedCityId,
      });

      await NotificationService.instance.bindCurrentCustomerPhone(_phone.text.trim());
      CartService.instance.clear();
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) => AlertDialog(
          title: const Text('تم إنشاء طلبك بالنقاط بنجاح'),
          content: Text('رقم الطلب: $result\nتم خصم $pointsToSpend نقطة من رصيدك مقابل المنتجات.\nرسوم التوصيل ${_deliveryFee.toStringAsFixed(2)} د.ل تُدفع عند الاستلام.'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(dialogContext).pop();
                Navigator.of(context).popUntil((route) => route.isFirst);
              },
              child: const Text('حسناً'),
            ),
          ],
        ),
      );
    } catch (e) {
      if (mounted) _message('تعذر إتمام الشراء بالنقاط: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _message(String value) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(value)),
    );
  }

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _address.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: astroBackground,
      appBar: AppBar(title: const Text('إتمام الطلب'), centerTitle: true),
      body: _db.auth.currentUser == null
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.lock_outline, size: 58, color: astroBlue),
                    const SizedBox(height: 14),
                    const Text(
                      'لإتمام الطلب، أنشئ حساباً أو سجّل الدخول برقم هاتفك.',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: astroNavy),
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: () async {
                        await Navigator.push(context, MaterialPageRoute(builder: (_) => const AccountScreen()));
                        if (mounted) {
                          _prefillCustomer();
                          _loadPointsBalance();
                          setState(() {});
                        }
                      },
                      child: const Text('الدخول أو إنشاء حساب'),
                    ),
                  ],
                ),
              ),
            )
          : ListView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFF0756C8), Color(0xFF087FE5)],
                      begin: Alignment.topRight,
                      end: Alignment.bottomLeft,
                    ),
                    borderRadius: BorderRadius.circular(22),
                    boxShadow: const [BoxShadow(color: Color(0x22075BCB), blurRadius: 15, offset: Offset(0, 6))],
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(color: Colors.white.withOpacity(.16), borderRadius: BorderRadius.circular(15)),
                        child: const Icon(Icons.shopping_bag_outlined, color: Colors.white, size: 26),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('أكمل طلبك', style: TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w900)),
                            const SizedBox(height: 3),
                            Text('${CartService.instance.items.length} منتجات في سلتك', style: const TextStyle(color: Colors.white70, fontSize: 12)),
                          ],
                        ),
                      ),
                      Text('${CartService.instance.total.toStringAsFixed(2)} د.ل', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 16)),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                _sectionCard(
                  title: 'بيانات العميل',
                  icon: Icons.person_outline_rounded,
                  children: [
                    _field('الاسم الكامل', _name),
                    _field('رقم الهاتف', _phone, keyboard: TextInputType.phone),
                  ],
                ),
                const SizedBox(height: 13),
                _sectionCard(
                  title: 'طريقة الاستلام',
                  icon: Icons.local_shipping_outlined,
                  children: [
                    _choiceTile(
                      value: 'delivery',
                      groupValue: _delivery,
                      title: 'توصيل إلى العنوان',
                      subtitle: 'توصيل إلى مدينتك وعنوانك',
                      icon: Icons.delivery_dining_outlined,
                      onChanged: (value) => setState(() { _delivery = value!; }),
                    ),
                    _choiceTile(
                      value: 'pickup',
                      groupValue: _delivery,
                      title: 'استلام من المحل',
                      subtitle: 'استلم طلبك مباشرة من المتجر',
                      icon: Icons.storefront_outlined,
                      onChanged: (value) => setState(() { _delivery = value!; _selectedCityId = null; }),
                    ),
                    if (_delivery == 'delivery') ...[
                      const SizedBox(height: 8),
                      if (_citiesLoading)
                        const Center(child: Padding(padding: EdgeInsets.all(12), child: CircularProgressIndicator()))
                      else if (_cities.isEmpty)
                        const Text('لا توجد مدن توصيل متاحة حالياً. يرجى التواصل مع المتجر.', style: TextStyle(color: Colors.red))
                      else
                        DropdownButtonFormField<String>(
                          value: _selectedCityId,
                          decoration: const InputDecoration(labelText: 'اختر مدينة التوصيل', prefixIcon: Icon(Icons.location_city_outlined)),
                          items: _cities.map((city) => DropdownMenuItem<String>(
                            value: city['id'].toString(),
                            child: Text('${city['city_name']} — ${(city['delivery_fee'] as num).toStringAsFixed(2)} د.ل'),
                          )).toList(),
                          onChanged: (value) => setState(() => _selectedCityId = value),
                        ),
                      if (_selectedCity != null) ...[
                        const SizedBox(height: 8),
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(color: const Color(0xFFEAF4FF), borderRadius: BorderRadius.circular(13)),
                          child: Row(
                            children: [
                              const Icon(Icons.local_shipping_outlined, color: astroBlue),
                              const SizedBox(width: 8),
                              Expanded(child: Text('رسوم التوصيل: ${_deliveryFee.toStringAsFixed(2)} د.ل\nمدة الوصول: ${_selectedCity!['estimated_delivery']}', style: const TextStyle(color: astroNavy, fontSize: 12, height: 1.5, fontWeight: FontWeight.w700))),
                            ],
                          ),
                        ),
                      ],
                      const SizedBox(height: 10),
                      _field('العنوان بالتفصيل', _address),
                    ],
                  ],
                ),
                const SizedBox(height: 13),
                _sectionCard(
                  title: 'طريقة الدفع',
                  icon: Icons.account_balance_wallet_outlined,
                  children: [
                    _choiceTile(
                      value: 'cash', groupValue: _payment,
                      title: 'الدفع عند الاستلام', subtitle: 'ادفع نقداً عند استلام طلبك',
                      icon: Icons.payments_outlined,
                      onChanged: (value) => setState(() => _payment = value!),
                    ),
                    _choiceTile(
                      value: 'transfer', groupValue: _payment,
                      title: 'تحويل مصرفي', subtitle: 'مصرف شمال أفريقيا – رفع إيصال التحويل',
                      icon: Icons.account_balance_outlined,
                      onChanged: (value) => setState(() => _payment = value!),
                    ),
                    if (_cartAllowsPoints && _db.auth.currentUser != null) ...[
                      _choiceTile(
                        value: 'points', groupValue: _payment,
                        title: 'الدفع بنقاط المكافآت',
                        subtitle: _pointsLoading ? 'جارٍ تحميل رصيدك...' : 'رصيدك $_pointsBalance نقطة • المطلوب $_requiredPoints نقطة',
                        icon: Icons.card_giftcard_rounded,
                        onChanged: _pointsLoading ? null : (value) => setState(() => _payment = value!),
                      ),
                      if (!_pointsLoading && _pointsBalance < _requiredPoints)
                        const Padding(
                          padding: EdgeInsetsDirectional.only(start: 12, top: 4),
                          child: Text('رصيدك غير كافٍ لشراء جميع منتجات السلة بالنقاط.', style: TextStyle(color: Colors.red, fontSize: 11)),
                        ),
                    ],
                  ],
                ),
                const SizedBox(height: 13),
                Container(
                  padding: const EdgeInsets.all(17),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFFE1EAF5)), boxShadow: const [BoxShadow(color: Color(0x0A082C5C), blurRadius: 12, offset: Offset(0, 4))]),
                  child: Column(
                    children: [
                      _totalLine('قيمة المنتجات', CartService.instance.total),
                      const SizedBox(height: 8),
                      _totalLine('رسوم التوصيل', _deliveryFee),
                      const Padding(padding: EdgeInsets.symmetric(vertical: 10), child: Divider()),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('الإجمالي', style: TextStyle(color: astroNavy, fontSize: 16, fontWeight: FontWeight.w900)),
                          Text('${_orderTotal.toStringAsFixed(2)} د.ل', style: const TextStyle(color: astroBlue, fontSize: 22, fontWeight: FontWeight.w900)),
                        ],
                      ),
                      const SizedBox(height: 14),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          onPressed: _busy || (_delivery == 'delivery' && (_citiesLoading || _cities.isEmpty)) ? null : _submit,
                          icon: _busy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.check_circle_outline_rounded),
                          label: Text(_busy ? 'جارٍ إرسال الطلب...' : 'تأكيد ومتابعة الطلب'),
                        ),
                      ),
                      const SizedBox(height: 7),
                      const Text('بياناتك وطلبك تتم معالجتها بأمان', style: TextStyle(color: Color(0xFF8A98A9), fontSize: 10)),
                    ],
                  ),
                ),
              ],
            ),
    );
  }

  Widget _sectionCard({required String title, required IconData icon, required List<Widget> children}) =>
      Container(
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFFE1EAF5)), boxShadow: const [BoxShadow(color: Color(0x09082C5C), blurRadius: 11, offset: Offset(0, 4))]),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [Icon(icon, color: astroBlue, size: 21), const SizedBox(width: 8), Text(title, style: const TextStyle(color: astroNavy, fontSize: 16, fontWeight: FontWeight.w900))]),
            const SizedBox(height: 13),
            ...children,
          ],
        ),
      );

  Widget _choiceTile({required String value, required String groupValue, required String title, required String subtitle, required IconData icon, required ValueChanged<String?>? onChanged}) =>
      RadioListTile<String>(
        value: value,
        groupValue: groupValue,
        onChanged: onChanged,
        contentPadding: const EdgeInsets.symmetric(horizontal: 3),
        dense: true,
        activeColor: astroBlue,
        secondary: Icon(icon, color: astroBlue, size: 22),
        title: Text(title, style: const TextStyle(color: astroNavy, fontSize: 13, fontWeight: FontWeight.w800)),
        subtitle: Text(subtitle, style: const TextStyle(color: Color(0xFF8492A3), fontSize: 10)),
      );

  Widget _totalLine(String label, double amount) => Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: Color(0xFF718096), fontSize: 13, fontWeight: FontWeight.w600)),
          Text('${amount.toStringAsFixed(2)} د.ل', style: const TextStyle(color: astroNavy, fontSize: 13, fontWeight: FontWeight.w800)),
        ],
      );

  Widget _field(
    String label,
    TextEditingController controller, {
    TextInputType? keyboard,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        keyboardType: keyboard,
        decoration: InputDecoration(
          labelText: label,
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
          ),
        ),
      ),
    );
  }
}

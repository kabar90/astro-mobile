import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../main.dart';

class OrdersScreen extends StatefulWidget {
  const OrdersScreen({super.key});

  @override
  State<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen> {
  final SupabaseClient _db = Supabase.instance.client;
  late Future<List<Map<String, dynamic>>> _ordersFuture;

  @override
  void initState() {
    super.initState();
    _ordersFuture = _loadOrders();
  }

  Future<List<Map<String, dynamic>>> _loadOrders() async {
    final user = _db.auth.currentUser;
    if (user == null) return [];

    final rows = await _db
        .from('orders')
        .select('*')
        .eq('customer_id', user.id)
        .order('created_at', ascending: false)
        .limit(100);
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<List<Map<String, dynamic>>> _loadItems(dynamic orderId) async {
    final rows = await _db
        .from('order_items')
        .select('*')
        .eq('order_id', orderId);
    return List<Map<String, dynamic>>.from(rows);
  }

  String _statusLabel(String? value) {
    switch ((value ?? '').trim()) {
      case 'جديد': return 'جديد';
      case 'قيد التجهيز': return 'قيد التجهيز';
      case 'تم الشحن': return 'تم الشحن';
      case 'تم التسليم': return 'تم التسليم';
      case 'ملغي': return 'ملغي';
      case 'cancelled': return 'ملغي';
      case 'delivered': return 'تم التسليم';
      case 'shipped': return 'تم الشحن';
      case 'processing': return 'قيد التجهيز';
      case 'pending': return 'جديد';
      default: return (value == null || value.isEmpty) ? 'قيد المراجعة' : value;
    }
  }

  Color _statusColor(String? value) {
    final status = _statusLabel(value);
    if (status == 'تم التسليم') return Colors.green;
    if (status == 'ملغي') return Colors.red;
    if (status == 'تم الشحن') return Colors.indigo;
    if (status == 'قيد التجهيز') return Colors.orange.shade800;
    return astroBlue;
  }

  String _dateText(dynamic value) {
    final date = DateTime.tryParse(value?.toString() ?? '')?.toLocal();
    if (date == null) return '—';
    return '${date.year}/${date.month.toString().padLeft(2, '0')}/${date.day.toString().padLeft(2, '0')}  ${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
  }

  String _money(dynamic value) => '${(value as num?)?.toStringAsFixed(2) ?? value ?? '—'} د.ل';

  @override
  Widget build(BuildContext context) {
    if (_db.auth.currentUser == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('طلباتي')),
        body: const Center(child: Text('سجّل الدخول لمتابعة طلباتك.')),
      );
    }

    return Scaffold(
      backgroundColor: astroBackground,
      appBar: AppBar(
        title: const Text('طلباتي'),
        actions: [
          IconButton(
            tooltip: 'تحديث',
            onPressed: () => setState(() => _ordersFuture = _loadOrders()),
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: _ordersFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return _messageState(
              'تعذر تحميل طلباتك. تأكد من اتصال الإنترنت وصلاحيات القراءة في قاعدة البيانات.',
              retry: true,
            );
          }
          final orders = snapshot.data ?? [];
          if (orders.isEmpty) {
            return _messageState('لا توجد طلبات مرتبطة بحسابك حتى الآن.');
          }
          return RefreshIndicator(
            onRefresh: () async => setState(() => _ordersFuture = _loadOrders()),
            child: ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: orders.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (context, index) => _orderCard(orders[index]),
            ),
          );
        },
      ),
    );
  }

  Widget _messageState(String text, {bool retry = false}) => Center(
    child: Padding(
      padding: const EdgeInsets.all(28),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(retry ? Icons.cloud_off_outlined : Icons.receipt_long_outlined, size: 54, color: astroBlue),
          const SizedBox(height: 12),
          Text(text, textAlign: TextAlign.center),
          if (retry) TextButton(onPressed: () => setState(() => _ordersFuture = _loadOrders()), child: const Text('إعادة المحاولة')),
        ],
      ),
    ),
  );

  Widget _orderCard(Map<String, dynamic> order) {
    final id = order['id'];
    final number = order['order_number'] ?? id;
    final status = order['status']?.toString();
    return Card(
      color: Colors.white,
      elevation: 1,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      child: ExpansionTile(
        tilePadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        leading: CircleAvatar(
          backgroundColor: const Color(0xFFEAF4FF),
          child: const Icon(Icons.receipt_long, color: astroNavy),
        ),
        title: Text('طلب رقم $number', style: const TextStyle(fontWeight: FontWeight.w900, color: astroNavy)),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 5),
          child: Text('التاريخ: ${_dateText(order['created_at'])}'),
        ),
        trailing: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(color: _statusColor(status).withOpacity(.10), borderRadius: BorderRadius.circular(20)),
          child: Text(_statusLabel(status), style: TextStyle(color: _statusColor(status), fontWeight: FontWeight.bold, fontSize: 12)),
        ),
        children: [
          const Divider(),
          _detail('حالة الطلب', _statusLabel(status)),
          _detail('طريقة الاستلام', order['delivery_method'] == 'pickup' ? 'استلام من المتجر' : 'توصيل'),
          if (order['delivery_city'] != null) _detail('مدينة التوصيل', order['delivery_city'].toString()),
          if (order['delivery_fee'] != null) _detail('رسوم التوصيل', _money(order['delivery_fee'])),
          if (order['delivery_estimate'] != null) _detail('مدة الوصول', order['delivery_estimate'].toString()),
          if (order['payment_method'] != null) _detail('طريقة الدفع', order['payment_method'].toString()),
          if (order['customer_address'] != null && order['customer_address'].toString().isNotEmpty) _detail('العنوان', order['customer_address'].toString()),
          _detail('الإجمالي', _money(order['total_price'] ?? order['total'])),
          const SizedBox(height: 8),
          Align(alignment: Alignment.centerRight, child: Text('المنتجات', style: TextStyle(fontWeight: FontWeight.bold, color: astroNavy))),
          FutureBuilder<List<Map<String, dynamic>>>(
            future: _loadItems(id),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) return const Padding(padding: EdgeInsets.all(12), child: LinearProgressIndicator());
              if (snapshot.hasError) return const Padding(padding: EdgeInsets.all(8), child: Text('تعذر تحميل تفاصيل المنتجات.'));
              final items = snapshot.data ?? [];
              if (items.isEmpty) return const Padding(padding: EdgeInsets.all(8), child: Text('لا توجد تفاصيل منتجات لهذا الطلب.'));
              return Column(
                children: items.map((item) => ListTile(
                  contentPadding: EdgeInsets.zero,
                  dense: true,
                  title: Text(item['product_name']?.toString() ?? 'منتج'),
                  subtitle: Text('الكمية: ${item['quantity'] ?? 1}${item['color'] == null ? '' : ' • اللون: ${item['color']}'}'),
                  trailing: Text(_money(item['unit_price'])),
                )).toList(),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _detail(String label, String value) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(width: 112, child: Text('$label:', style: const TextStyle(color: Colors.black54))),
        Expanded(child: Text(value, style: const TextStyle(fontWeight: FontWeight.w600))),
      ],
    ),
  );
}

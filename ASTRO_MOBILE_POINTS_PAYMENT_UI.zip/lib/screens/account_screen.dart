import 'dart:async';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../main.dart';
import 'orders_screen.dart';

class AccountScreen extends StatefulWidget {
  const AccountScreen({super.key});

  @override
  State<AccountScreen> createState() => _AccountScreenState();
}

class _AccountScreenState extends State<AccountScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _isRegister = true;
  bool _busy = false;
  bool _hidePassword = true;
  StreamSubscription<AuthState>? _authSubscription;

  SupabaseClient get _db => Supabase.instance.client;
  User? get _user => _db.auth.currentUser;

  @override
  void initState() {
    super.initState();
    // Supabase Flutter processes the verified email deep link and emits
    // an auth event. Listen here so the account page rebuilds immediately.
    _authSubscription = _db.auth.onAuthStateChange.listen((state) {
      if (!mounted) return;
      switch (state.event) {
        case AuthChangeEvent.initialSession:
        case AuthChangeEvent.signedIn:
        case AuthChangeEvent.signedOut:
        case AuthChangeEvent.tokenRefreshed:
        case AuthChangeEvent.userUpdated:
          setState(() {});
          break;
        default:
          break;
      }
    });
  }

  @override
  void dispose() {
    _authSubscription?.cancel();
    _name.dispose();
    _phone.dispose();
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  void _message(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(text), behavior: SnackBarBehavior.floating),
    );
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _busy = true);
    try {
      if (_isRegister) {
        final response = await _db.auth.signUp(
          email: _email.text.trim(),
          password: _password.text,
          data: {
            'full_name': _name.text.trim(),
            'phone': _phone.text.trim(),
          },
          emailRedirectTo: 'com.astromobile.store://login-callback',
        );
        if (!mounted) return;
        if (response.session == null) {
          _message('تم إنشاء الحساب. تحقق من بريدك الإلكتروني لتأكيد التسجيل ثم سجّل الدخول.');
        } else {
          _message('مرحباً بك في ASTRO MOBILE، تم إنشاء حسابك بنجاح.');
        }
      } else {
        await _db.auth.signInWithPassword(
          email: _email.text.trim(),
          password: _password.text,
        );
        _message('تم تسجيل الدخول بنجاح.');
      }
      if (mounted) setState(() {});
    } on AuthException catch (e) {
      _message(_friendlyAuthError(e.message));
    } catch (e) {
      _message('تعذر إتمام العملية. تحقق من اتصال الإنترنت وحاول مجدداً.');
      debugPrint('ASTRO account error: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  String _friendlyAuthError(String message) {
    final value = message.toLowerCase();
    if (value.contains('already registered') || value.contains('already been registered')) {
      return 'هذا البريد الإلكتروني مسجل من قبل. جرّب تسجيل الدخول.';
    }
    if (value.contains('invalid login credentials')) {
      return 'البريد الإلكتروني أو كلمة المرور غير صحيحة.';
    }
    if (value.contains('password')) return 'كلمة المرور غير مقبولة. استخدم 6 أحرف على الأقل.';
    if (value.contains('email')) return 'تحقق من صحة البريد الإلكتروني.';
    return message;
  }

  Future<void> _signOut() async {
    await _db.auth.signOut();
    if (mounted) {
      setState(() {
        _isRegister = false;
        _password.clear();
      });
      _message('تم تسجيل الخروج.');
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = _user;
    return Scaffold(
      backgroundColor: astroBackground,
      appBar: AppBar(title: const Text('حسابي')),
      body: user == null ? _buildAuthForm() : _buildProfile(user),
    );
  }

  Widget _buildAuthForm() {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 480),
          child: Card(
            color: Colors.white,
            elevation: 1,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
            child: Padding(
              padding: const EdgeInsets.all(22),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Icon(Icons.account_circle_outlined, size: 66, color: astroBlue),
                    const SizedBox(height: 10),
                    Text(
                      _isRegister ? 'إنشاء حساب جديد' : 'تسجيل الدخول',
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: astroNavy),
                    ),
                    const SizedBox(height: 7),
                    const Text('سجّل بياناتك لمتابعة طلباتك والاستفادة من خدمات المتجر', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
                    const SizedBox(height: 22),
                    if (_isRegister) ...[
                      _input(_name, 'الاسم الكامل', Icons.person_outline, validator: (v) => (v == null || v.trim().isEmpty) ? 'أدخل اسمك الكامل' : null),
                      const SizedBox(height: 13),
                      _input(_phone, 'رقم الهاتف', Icons.phone_outlined, keyboard: TextInputType.phone, validator: (v) => (v == null || v.trim().length < 7) ? 'أدخل رقم هاتف صحيحاً' : null),
                      const SizedBox(height: 13),
                    ],
                    _input(_email, 'البريد الإلكتروني', Icons.email_outlined, keyboard: TextInputType.emailAddress, validator: (v) => (v == null || !v.contains('@') || !v.contains('.')) ? 'أدخل بريداً إلكترونياً صحيحاً' : null),
                    const SizedBox(height: 13),
                    TextFormField(
                      controller: _password,
                      obscureText: _hidePassword,
                      validator: (v) => (v == null || v.length < 6) ? 'كلمة المرور يجب ألا تقل عن 6 أحرف' : null,
                      decoration: InputDecoration(
                        labelText: 'كلمة المرور',
                        prefixIcon: const Icon(Icons.lock_outline),
                        suffixIcon: IconButton(
                          onPressed: () => setState(() => _hidePassword = !_hidePassword),
                          icon: Icon(_hidePassword ? Icons.visibility_outlined : Icons.visibility_off_outlined),
                        ),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(13)),
                      ),
                    ),
                    const SizedBox(height: 20),
                    SizedBox(
                      height: 50,
                      child: ElevatedButton(
                        onPressed: _busy ? null : _submit,
                        style: ElevatedButton.styleFrom(backgroundColor: astroNavy, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13))),
                        child: _busy ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : Text(_isRegister ? 'إنشاء الحساب' : 'دخول', style: const TextStyle(fontWeight: FontWeight.bold)),
                      ),
                    ),
                    const SizedBox(height: 10),
                    TextButton(
                      onPressed: _busy ? null : () => setState(() => _isRegister = !_isRegister),
                      child: Text(_isRegister ? 'لديك حساب بالفعل؟ سجّل الدخول' : 'ليس لديك حساب؟ أنشئ حساباً جديداً'),
                    ),
                    const SizedBox(height: 5),
                    const Text('لن نرسل رسائل SMS حالياً. تأكيد الحساب يتم عبر البريد الإلكتروني إذا كان التحقق مفعّلاً في Supabase.', textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: Colors.black45)),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _input(TextEditingController controller, String label, IconData icon, {TextInputType? keyboard, String? Function(String?)? validator}) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboard,
      validator: validator,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(13)),
      ),
    );
  }

  Future<Map<String, dynamic>> _loadRewards(String userId) async {
    final balanceRow = await _db
        .from('customer_points')
        .select('balance')
        .eq('user_id', userId)
        .maybeSingle();

    final historyRows = await _db
        .from('points_transactions')
        .select('transaction_type, points, balance_after, description, created_at, order_id')
        .eq('user_id', userId)
        .order('created_at', ascending: false)
        .limit(20);

    return {
      'balance': (balanceRow?['balance'] as num?)?.toInt() ?? 0,
      'history': List<Map<String, dynamic>>.from(historyRows),
    };
  }

  String _transactionTitle(String type) {
    switch (type) {
      case 'earned':
        return 'نقاط مكتسبة';
      case 'redeemed':
        return 'استخدام نقاط في الشراء';
      case 'refund':
        return 'استرجاع نقاط';
      case 'adjustment':
        return 'تعديل رصيد النقاط';
      default:
        return 'حركة نقاط';
    }
  }

  bool _isDebitTransaction(
    List<Map<String, dynamic>> history,
    int index,
    String type,
    String description,
  ) {
    // Reversing earned points after a cancelled order is a debit, even though
    // the database stores it as an adjustment with a positive points value.
    final normalizedDescription = description.trim();
    if (type == 'adjustment' &&
        (normalizedDescription.contains('عكس مكافأة') ||
         normalizedDescription.contains('خصم مكافأة') ||
         normalizedDescription.contains('استرجاع مكافأة'))) {
      return true;
    }

    // For other adjustments, compare balances when adjacent transactions
    // have different balances. Same-timestamp rows may not have a stable order.
    if (index + 1 < history.length) {
      final currentBalance =
          (history[index]['balance_after'] as num?)?.toInt();
      final previousBalance =
          (history[index + 1]['balance_after'] as num?)?.toInt();
      if (currentBalance != null && previousBalance != null &&
          currentBalance != previousBalance) {
        return currentBalance < previousBalance;
      }
    }

    return type == 'redeemed';
  }

  Widget _buildRewardsSection(User user) {
    return FutureBuilder<Map<String, dynamic>>(
      future: _loadRewards(user.id),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Card(
            child: Padding(
              padding: EdgeInsets.all(22),
              child: Center(child: CircularProgressIndicator()),
            ),
          );
        }

        if (snapshot.hasError) {
          return Card(
            color: Colors.white,
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                children: [
                  const Icon(Icons.stars_outlined, size: 34, color: astroBlue),
                  const SizedBox(height: 8),
                  const Text('نقاط المكافآت', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: astroNavy)),
                  const SizedBox(height: 8),
                  const Text('تعذر تحميل رصيد النقاط حالياً. حاول تحديث الصفحة.'),
                  TextButton(
                    onPressed: () => setState(() {}),
                    child: const Text('إعادة المحاولة'),
                  ),
                ],
              ),
            ),
          );
        }

        final data = snapshot.data ?? {'balance': 0, 'history': <Map<String, dynamic>>[]};
        final balance = data['balance'] as int;
        final history = data['history'] as List<Map<String, dynamic>>;

        return Card(
          color: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Row(
                  children: [
                    Icon(Icons.workspace_premium, color: astroBlue, size: 26),
                    SizedBox(width: 8),
                    Text('نقاط المكافآت', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: astroNavy)),
                  ],
                ),
                const SizedBox(height: 14),
                Container(
                  padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 14),
                  decoration: BoxDecoration(
                    color: const Color(0xFFEAF4FF),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Column(
                    children: [
                      Text('$balance', style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w900, color: astroNavy)),
                      const Text('نقطة متاحة', style: TextStyle(color: astroNavy, fontWeight: FontWeight.w600)),
                      const SizedBox(height: 5),
                      Text('تعادل ${(balance / 10).toStringAsFixed(2)} د.ل', style: const TextStyle(color: Colors.black54)),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                const Text('كل 10 نقاط = 1 دينار ليبي', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54, fontSize: 12)),
                const Divider(height: 28),
                const Text('سجل حركات النقاط', style: TextStyle(fontWeight: FontWeight.bold, color: astroNavy)),
                const SizedBox(height: 8),
                if (history.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 14),
                    child: Text('لا توجد حركات نقاط حتى الآن.', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
                  )
                else
                  ...history.asMap().entries.map((entry) {
                    final index = entry.key;
                    final item = entry.value;
                    final type = (item['transaction_type'] ?? '').toString();
                    final points = (item['points'] as num?)?.toInt() ?? 0;
                    final isSpend = _isDebitTransaction(history, index, type, (item['description'] ?? '').toString());
                    final date = DateTime.tryParse((item['created_at'] ?? '').toString());
                    final dateText = date == null
                        ? ''
                        : '${date.year}/${date.month.toString().padLeft(2, '0')}/${date.day.toString().padLeft(2, '0')}';
                    final description = (item['description'] ?? '').toString();
                    return ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: CircleAvatar(
                        backgroundColor: isSpend ? const Color(0xFFFFEEEE) : const Color(0xFFEAF7EF),
                        child: Icon(
                          isSpend ? Icons.remove : Icons.add,
                          color: isSpend ? Colors.red : Colors.green,
                        ),
                      ),
                      title: Text(_transactionTitle(type), style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                      subtitle: Text(
                        [if (description.isNotEmpty) description, if (dateText.isNotEmpty) dateText].join('\n'),
                        style: const TextStyle(fontSize: 11),
                      ),
                      trailing: Text(
                        '${isSpend ? '-' : '+'}$points',
                        style: TextStyle(fontWeight: FontWeight.bold, color: isSpend ? Colors.red : Colors.green),
                      ),
                    );
                  }),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildProfile(User user) {
    final metadata = user.userMetadata ?? {};
    final name = (metadata['full_name'] ?? 'عميل ASTRO MOBILE').toString();
    final phone = (metadata['phone'] ?? 'لم تتم إضافة رقم الهاتف').toString();
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Card(
          color: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          child: Padding(
            padding: const EdgeInsets.all(22),
            child: Column(
              children: [
                const CircleAvatar(radius: 38, backgroundColor: Color(0xFFE8F3FF), child: Icon(Icons.person, size: 42, color: astroNavy)),
                const SizedBox(height: 12),
                Text(name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: astroNavy)),
                const SizedBox(height: 7),
                _profileRow(Icons.email_outlined, user.email ?? ''),
                _profileRow(Icons.phone_outlined, phone),
                const Divider(height: 28),
                const Text('حسابك مرتبط بمتجر ASTRO MOBILE', style: TextStyle(color: Colors.black54)),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        Card(
          color: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          child: ListTile(
            leading: const CircleAvatar(
              backgroundColor: Color(0xFFEAF4FF),
              child: Icon(Icons.receipt_long_outlined, color: astroNavy),
            ),
            title: const Text('طلباتي', style: TextStyle(fontWeight: FontWeight.w800, color: astroNavy)),
            subtitle: const Text('تابع حالة طلباتك وتفاصيلها'),
            trailing: const Icon(Icons.chevron_left),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const OrdersScreen()),
            ),
          ),
        ),
        const SizedBox(height: 16),
        _buildRewardsSection(user),
        const SizedBox(height: 16),
        OutlinedButton.icon(
          onPressed: _signOut,
          icon: const Icon(Icons.logout),
          label: const Text('تسجيل الخروج'),
          style: OutlinedButton.styleFrom(foregroundColor: Colors.red.shade700, padding: const EdgeInsets.symmetric(vertical: 14)),
        ),
      ],
    );
  }

  Widget _profileRow(IconData icon, String value) => Padding(
        padding: const EdgeInsets.only(top: 8),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [Icon(icon, size: 18, color: astroBlue), const SizedBox(width: 8), Flexible(child: Text(value, textAlign: TextAlign.center))],
        ),
      );
}

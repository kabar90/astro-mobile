import 'dart:async';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

import '../main.dart';
import 'orders_screen.dart';

class AccountScreen extends StatefulWidget {
  const AccountScreen({super.key});

  @override
  State<AccountScreen> createState() => _AccountScreenState();
}

class _AccountScreenState extends State<AccountScreen> {
  final _formKey = GlobalKey<FormState>();
  final GlobalKey _rewardsKey = GlobalKey();
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _password = TextEditingController();
  bool _isRegister = true;
  bool _busy = false;
  bool _hidePassword = true;
  StreamSubscription<AuthState>? _authSubscription;

  SupabaseClient get _db => Supabase.instance.client;
  User? get _user => _db.auth.currentUser;

  @override
  void initState() {
    super.initState();
    // Supabase Flutter processes the verified email deep link and emits
    // an auth event. Listen here so the account page rebuilds immediately.
    _authSubscription = _db.auth.onAuthStateChange.listen((state) {
      if (!mounted) return;
      switch (state.event) {
        case AuthChangeEvent.initialSession:
        case AuthChangeEvent.signedIn:
        case AuthChangeEvent.signedOut:
        case AuthChangeEvent.tokenRefreshed:
        case AuthChangeEvent.userUpdated:
          setState(() {});
          break;
        default:
          break;
      }
    });
  }

  @override
  void dispose() {
    _authSubscription?.cancel();
    _name.dispose();
    _phone.dispose();
    _password.dispose();
    super.dispose();
  }

  void _message(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(text), behavior: SnackBarBehavior.floating),
    );
  }

  String _normalizedPhone() {
    // Canonicalize Libyan mobile numbers so local and international variants
    // always map to the same internal account email.
    var digits = _phone.text.trim().replaceAll(RegExp(r'\D'), '');
    if (digits.startsWith('00')) digits = digits.substring(2);
    if (digits.startsWith('218')) digits = digits.substring(3);
    if (digits.startsWith('0')) digits = digits.substring(1);
    return '+218$digits';
  }

  bool _isValidLibyanMobile() {
    final digits = _normalizedPhone().replaceAll(RegExp(r'\D'), '');
    return RegExp(r'^2189[1-5]\d{7}$').hasMatch(digits);
  }

  String? _phoneValidator(String? value) {
    if (value == null || value.trim().isEmpty) return 'أدخل رقم الهاتف';
    if (!_isValidLibyanMobile()) {
      return 'أدخل رقم هاتف ليبي صحيحاً، مثل 0912345678';
    }
    return null;
  }

  // Supabase Phone Auth is intentionally not used: it requires an SMS provider.
  // A deterministic, non-deliverable email alias lets customers use their
  // phone number as the visible login while Supabase authenticates by email/password.
  String _accountEmailFromPhone() {
    final digits = _normalizedPhone().replaceAll(RegExp(r'\D'), '');
    return '$digits@astro-mobile.invalid';
  }

  Future<void> _contactForPasswordReset() async {
    const phone = '218944005010';
    final message = Uri.encodeComponent(
      'مرحباً ASTRO MOBILE، نسيت كلمة مرور حسابي وأرغب في استعادتها. رقم الهاتف المسجل: ${_phone.text.trim()}',
    );
    final uri = Uri.parse('https://wa.me/$phone?text=$message');
    try {
      final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!opened) _message('تعذر فتح واتساب. تواصل معنا على 0944005010.');
    } catch (_) {
      _message('تعذر فتح واتساب. تواصل معنا على 0944005010.');
    }
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _busy = true);
    try {
      if (_isRegister) {
        final response = await _db.auth.signUp(
          email: _accountEmailFromPhone(),
          password: _password.text,
          data: {
            'full_name': _name.text.trim(),
            'phone': _normalizedPhone(),
          },
        );
        if (!mounted) return;
        if (response.session == null) {
          _message('لم يتم إنشاء جلسة دخول. تأكد أن خيار Confirm email معطّل في Supabase ثم أعد المحاولة.');
        } else {
          _message('مرحباً بك في ASTRO MOBILE، تم إنشاء حسابك بنجاح.');
        }
      } else {
        await _db.auth.signInWithPassword(
          email: _accountEmailFromPhone(),
          password: _password.text,
        );
        _message('تم تسجيل الدخول بنجاح.');
      }
      if (mounted) setState(() {});
    } on AuthException catch (e) {
      _message(_friendlyAuthError(e.message));
    } catch (e) {
      _message('تعذر إتمام العملية. تحقق من اتصال الإنترنت وحاول مجدداً.');
      debugPrint('ASTRO account error: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  String _friendlyAuthError(String message) {
    final value = message.toLowerCase();
    if (value.contains('already registered') || value.contains('already been registered')) {
      return 'رقم الهاتف مسجل من قبل. جرّب تسجيل الدخول.';
    }
    if (value.contains('invalid login credentials')) {
      return 'رقم الهاتف أو كلمة المرور غير صحيحة.';
    }
    if (value.contains('email') && (value.contains('confirm') || value.contains('not confirmed'))) {
      return 'عطّل خيار Confirm email في إعدادات Supabase ثم حاول من جديد.';
    }
    if (value.contains('password')) return 'كلمة المرور غير مقبولة. استخدم 6 أحرف على الأقل.';
    return message;
  }

  Future<void> _signOut() async {
    await _db.auth.signOut();
    if (mounted) {
      setState(() {
        _isRegister = false;
        _password.clear();
      });
      _message('تم تسجيل الخروج.');
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = _user;
    return Scaffold(
      backgroundColor: astroBackground,
      appBar: AppBar(title: const Text('حسابي')),
      body: user == null ? _buildAuthForm() : _buildProfile(user),
    );
  }

  Widget _buildAuthForm() {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 480),
          child: Card(
            color: Colors.white,
            elevation: 1,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
            child: Padding(
              padding: const EdgeInsets.all(22),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Icon(Icons.account_circle_outlined, size: 66, color: astroBlue),
                    const SizedBox(height: 10),
                    Text(
                      _isRegister ? 'إنشاء حساب جديد' : 'تسجيل الدخول',
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: astroNavy),
                    ),
                    const SizedBox(height: 7),
                    const Text('سجّل بياناتك لمتابعة طلباتك والاستفادة من خدمات المتجر', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
                    const SizedBox(height: 22),
                    if (_isRegister) ...[
                      _input(_name, 'الاسم الكامل', Icons.person_outline, validator: (v) => (v == null || v.trim().isEmpty) ? 'أدخل اسمك الكامل' : null),
                      const SizedBox(height: 13),
                      _input(_phone, 'رقم الهاتف', Icons.phone_outlined, keyboard: TextInputType.phone, validator: _phoneValidator),
                      const SizedBox(height: 13),
                    ],
                    if (!_isRegister) ...[
                      _input(_phone, 'رقم الهاتف', Icons.phone_outlined, keyboard: TextInputType.phone, validator: _phoneValidator),
                      const SizedBox(height: 13),
                    ],
                    TextFormField(
                      controller: _password,
                      obscureText: _hidePassword,
                      validator: (v) => (v == null || v.length < 6) ? 'كلمة المرور يجب ألا تقل عن 6 أحرف' : null,
                      decoration: InputDecoration(
                        labelText: 'كلمة المرور',
                        prefixIcon: const Icon(Icons.lock_outline),
                        suffixIcon: IconButton(
                          onPressed: () => setState(() => _hidePassword = !_hidePassword),
                          icon: Icon(_hidePassword ? Icons.visibility_outlined : Icons.visibility_off_outlined),
                        ),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(13)),
                      ),
                    ),
                    const SizedBox(height: 20),
                    SizedBox(
                      height: 50,
                      child: ElevatedButton(
                        onPressed: _busy ? null : _submit,
                        style: ElevatedButton.styleFrom(backgroundColor: astroNavy, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13))),
                        child: _busy ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : Text(_isRegister ? 'إنشاء الحساب' : 'دخول', style: const TextStyle(fontWeight: FontWeight.bold)),
                      ),
                    ),
                    const SizedBox(height: 10),
                    TextButton(
                      onPressed: _busy ? null : () => setState(() => _isRegister = !_isRegister),
                      child: Text(_isRegister ? 'لديك حساب بالفعل؟ سجّل الدخول' : 'ليس لديك حساب؟ أنشئ حساباً جديداً'),
                    ),
                    if (!_isRegister) ...[
                      const SizedBox(height: 2),
                      TextButton.icon(
                        onPressed: _busy ? null : _contactForPasswordReset,
                        icon: const Icon(Icons.chat),
                        label: const Text('نسيت كلمة المرور؟ تواصل معنا عبر واتساب'),
                        style: TextButton.styleFrom(foregroundColor: astroBlue),
                      ),
                      const Text('واتساب المتجر: 0944005010', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Colors.black54)),
                    ],
                    const SizedBox(height: 5),
                    const Text('تسجيل الدخول برقم الهاتف وكلمة المرور دون بريد ظاهر أو رسائل SMS.', textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: Colors.black45)),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _input(TextEditingController controller, String label, IconData icon, {TextInputType? keyboard, String? Function(String?)? validator}) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboard,
      validator: validator,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(13)),
      ),
    );
  }

  Future<Map<String, dynamic>> _loadRewards(String userId) async {
    final balanceRow = await _db
        .from('customer_points')
        .select('balance')
        .eq('user_id', userId)
        .maybeSingle();

    final historyRows = await _db
        .from('points_transactions')
        .select('transaction_type, points, balance_after, description, created_at, order_id')
        .eq('user_id', userId)
        .order('created_at', ascending: false)
        .limit(20);

    return {
      'balance': (balanceRow?['balance'] as num?)?.toInt() ?? 0,
      'history': List<Map<String, dynamic>>.from(historyRows),
    };
  }

  String _transactionTitle(String type) {
    switch (type) {
      case 'earned':
        return 'نقاط مكتسبة';
      case 'redeemed':
        return 'استخدام نقاط في الشراء';
      case 'refund':
        return 'استرجاع نقاط';
      case 'adjustment':
        return 'تعديل رصيد النقاط';
      default:
        return 'حركة نقاط';
    }
  }

  bool _isDebitTransaction(
    List<Map<String, dynamic>> history,
    int index,
    String type,
    String description,
  ) {
    // Reversing earned points after a cancelled order is a debit, even though
    // the database stores it as an adjustment with a positive points value.
    final normalizedDescription = description.trim();
    if (type == 'adjustment' &&
        (normalizedDescription.contains('عكس مكافأة') ||
         normalizedDescription.contains('خصم مكافأة') ||
         normalizedDescription.contains('استرجاع مكافأة'))) {
      return true;
    }

    // For other adjustments, compare balances when adjacent transactions
    // have different balances. Same-timestamp rows may not have a stable order.
    if (index + 1 < history.length) {
      final currentBalance =
          (history[index]['balance_after'] as num?)?.toInt();
      final previousBalance =
          (history[index + 1]['balance_after'] as num?)?.toInt();
      if (currentBalance != null && previousBalance != null &&
          currentBalance != previousBalance) {
        return currentBalance < previousBalance;
      }
    }

    return type == 'redeemed';
  }

  Widget _buildRewardsSection(User user) {
    return FutureBuilder<Map<String, dynamic>>(
      key: _rewardsKey,
      future: _loadRewards(user.id),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Card(
            child: Padding(
              padding: EdgeInsets.all(22),
              child: Center(child: CircularProgressIndicator()),
            ),
          );
        }

        if (snapshot.hasError) {
          return Card(
            color: Colors.white,
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                children: [
                  const Icon(Icons.stars_outlined, size: 34, color: astroBlue),
                  const SizedBox(height: 8),
                  const Text('نقاط المكافآت', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: astroNavy)),
                  const SizedBox(height: 8),
                  const Text('تعذر تحميل رصيد النقاط حالياً. حاول تحديث الصفحة.'),
                  TextButton(
                    onPressed: () => setState(() {}),
                    child: const Text('إعادة المحاولة'),
                  ),
                ],
              ),
            ),
          );
        }

        final data = snapshot.data ?? {'balance': 0, 'history': <Map<String, dynamic>>[]};
        final balance = data['balance'] as int;
        final history = data['history'] as List<Map<String, dynamic>>;

        return Card(
          color: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Row(
                  children: [
                    Icon(Icons.workspace_premium, color: astroBlue, size: 26),
                    SizedBox(width: 8),
                    Text('نقاط المكافآت', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: astroNavy)),
                  ],
                ),
                const SizedBox(height: 14),
                Container(
                  padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 14),
                  decoration: BoxDecoration(
                    color: const Color(0xFFEAF4FF),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Column(
                    children: [
                      Text('$balance', style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w900, color: astroNavy)),
                      const Text('نقطة متاحة', style: TextStyle(color: astroNavy, fontWeight: FontWeight.w600)),
                      const SizedBox(height: 5),
                      Text('تعادل ${(balance / 10).toStringAsFixed(2)} د.ل', style: const TextStyle(color: Colors.black54)),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                const Text('كل 10 نقاط = 1 دينار ليبي', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54, fontSize: 12)),
                const Divider(height: 28),
                const Text('سجل حركات النقاط', style: TextStyle(fontWeight: FontWeight.bold, color: astroNavy)),
                const SizedBox(height: 8),
                if (history.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 14),
                    child: Text('لا توجد حركات نقاط حتى الآن.', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
                  )
                else
                  ...history.asMap().entries.map((entry) {
                    final index = entry.key;
                    final item = entry.value;
                    final type = (item['transaction_type'] ?? '').toString();
                    final points = (item['points'] as num?)?.toInt() ?? 0;
                    final isSpend = _isDebitTransaction(history, index, type, (item['description'] ?? '').toString());
                    final date = DateTime.tryParse((item['created_at'] ?? '').toString());
                    final dateText = date == null
                        ? ''
                        : '${date.year}/${date.month.toString().padLeft(2, '0')}/${date.day.toString().padLeft(2, '0')}';
                    final description = (item['description'] ?? '').toString();
                    return ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: CircleAvatar(
                        backgroundColor: isSpend ? const Color(0xFFFFEEEE) : const Color(0xFFEAF7EF),
                        child: Icon(
                          isSpend ? Icons.remove : Icons.add,
                          color: isSpend ? Colors.red : Colors.green,
                        ),
                      ),
                      title: Text(_transactionTitle(type), style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                      subtitle: Text(
                        [if (description.isNotEmpty) description, if (dateText.isNotEmpty) dateText].join('\n'),
                        style: const TextStyle(fontSize: 11),
                      ),
                      trailing: Text(
                        '${isSpend ? '-' : '+'}$points',
                        style: TextStyle(fontWeight: FontWeight.bold, color: isSpend ? Colors.red : Colors.green),
                      ),
                    );
                  }),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildProfile(User user) {
    final metadata = user.userMetadata ?? {};
    final name = (metadata['full_name'] ?? 'عميل ASTRO MOBILE').toString();
    final phone = (metadata['phone'] ?? 'لم تتم إضافة رقم الهاتف').toString();
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 24),
      children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
              colors: [Color(0xFF0789F5), Color(0xFF0751B8), Color(0xFF082C5C)],
            ),
            borderRadius: BorderRadius.circular(24),
            boxShadow: const [
              BoxShadow(color: Color(0x26085CB8), blurRadius: 20, offset: Offset(0, 8)),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 70,
                height: 70,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(.18),
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white.withOpacity(.45), width: 1.5),
                ),
                child: const Icon(Icons.person_rounded, size: 40, color: Colors.white),
              ),
              const SizedBox(width: 15),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(name, maxLines: 1, overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: Colors.white)),
                    const SizedBox(height: 8),
                    Row(children: [
                      const Icon(Icons.phone_rounded, size: 15, color: Colors.white70),
                      const SizedBox(width: 6),
                      Expanded(child: Text(phone, maxLines: 1, overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600))),
                    ]),
                    const SizedBox(height: 5),
                    Text(user.email ?? '', maxLines: 1, overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: Colors.white70, fontSize: 11)),
                  ],
                ),
              ),
              const SizedBox(width: 6),
              const Icon(Icons.edit_outlined, color: Colors.white70, size: 19),
            ],
          ),
        ),
        const SizedBox(height: 14),
        Row(
          children: [
            Expanded(
              child: _quickAccountAction(
                icon: Icons.receipt_long_rounded,
                title: 'طلباتي',
                subtitle: 'تابع مشترياتك',
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const OrdersScreen()),
                ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _quickAccountAction(
                icon: Icons.workspace_premium_rounded,
                title: 'نقاطي',
                subtitle: 'رصيد المكافآت',
                onTap: () {
                  final target = _rewardsKey.currentContext;
                  if (target != null) {
                    Scrollable.ensureVisible(
                      target,
                      duration: const Duration(milliseconds: 350),
                      curve: Curves.easeInOut,
                    );
                  }
                },
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        _buildRewardsSection(user),
        const SizedBox(height: 16),
        OutlinedButton.icon(
          onPressed: _signOut,
          icon: const Icon(Icons.logout),
          label: const Text('تسجيل الخروج'),
          style: OutlinedButton.styleFrom(foregroundColor: Colors.red.shade700, padding: const EdgeInsets.symmetric(vertical: 14)),
        ),
      ],
    );
  }

  Widget _quickAccountAction({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: const Color(0xFFE1EAF5)),
            boxShadow: const [
              BoxShadow(color: Color(0x08082C5C), blurRadius: 10, offset: Offset(0, 3)),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  color: const Color(0xFFEAF4FF),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: astroBlue, size: 21),
              ),
              const SizedBox(width: 9),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: const TextStyle(color: astroNavy, fontWeight: FontWeight.w900, fontSize: 13)),
                    const SizedBox(height: 3),
                    Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.black45, fontSize: 10)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _profileRow(IconData icon, String value) => Padding(
        padding: const EdgeInsets.only(top: 8),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [Icon(icon, size: 18, color: astroBlue), const SizedBox(width: 8), Flexible(child: Text(value, textAlign: TextAlign.center))],
        ),
      );
}

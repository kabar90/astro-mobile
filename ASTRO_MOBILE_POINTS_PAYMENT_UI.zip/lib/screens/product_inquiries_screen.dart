import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../main.dart';
import '../models/product.dart';
import '../widgets/astro_cached_image.dart';
import 'account_screen.dart';
import 'product_detail_screen.dart';

class ProductInquiriesScreen extends StatefulWidget {
  const ProductInquiriesScreen({super.key});

  @override
  State<ProductInquiriesScreen> createState() => _ProductInquiriesScreenState();
}

class _ProductInquiriesScreenState extends State<ProductInquiriesScreen> {
  final _modelController = TextEditingController();
  final _noteController = TextEditingController();
  final _db = Supabase.instance.client;

  static const _categories = <Map<String, dynamic>>[
    {'id': 17, 'name': 'الكفرات'},
    {'id': 34, 'name': 'لاصقة عدسة الكاميرا'},
    {'id': 40, 'name': 'لاصقة الشاشة'},
  ];

  int _categoryId = 17;
  bool _sending = false;
  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _inquiries = [];

  @override
  void initState() {
    super.initState();
    _loadInquiries();
  }

  @override
  void dispose() {
    _modelController.dispose();
    _noteController.dispose();
    super.dispose();
  }

  Future<void> _loadInquiries() async {
    if (_db.auth.currentUser == null) {
      if (mounted) setState(() {
        _loading = false;
        _inquiries = [];
      });
      return;
    }
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final rows = await _db
          .from('product_inquiries')
          .select()
          .eq('user_id', _db.auth.currentUser!.id)
          .order('created_at', ascending: false);
      if (!mounted) return;
      setState(() {
        _inquiries = List<Map<String, dynamic>>.from(rows);
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = 'تعذر تحميل استفساراتك. تأكد من تفعيل نظام الاستفسارات في المتجر.';
      });
      debugPrint('ASTRO inquiries load error: $e');
    }
  }

  Future<void> _sendInquiry() async {
    if (_db.auth.currentUser == null) {
      _showMessage('يجب تسجيل الدخول أولاً لإرسال استفسار.');
      return;
    }
    final model = _modelController.text.trim();
    if (model.length < 2) {
      _showMessage('اكتب موديل الجهاز أولاً.');
      return;
    }
    setState(() => _sending = true);
    try {
      await _db.from('product_inquiries').insert({
        'user_id': _db.auth.currentUser!.id,
        'category_id': _categoryId,
        'device_model': model,
        'customer_note': _noteController.text.trim().isEmpty
            ? null
            : _noteController.text.trim(),
      });
      _modelController.clear();
      _noteController.clear();
      if (!mounted) return;
      _showMessage('تم إرسال استفسارك بنجاح. سنراجع التوفر ونرسل لك الخيارات.');
      await _loadInquiries();
    } on PostgrestException catch (e) {
      _showMessage(e.message.contains('product_inquiries')
          ? 'نظام الاستفسارات لم يُفعّل بعد. يرجى المحاولة لاحقاً.'
          : 'تعذر إرسال الاستفسار. حاول مرة أخرى.');
      debugPrint('ASTRO inquiry submit error: ${e.message}');
    } catch (e) {
      _showMessage('تعذر إرسال الاستفسار. تحقق من الإنترنت وحاول مجدداً.');
      debugPrint('ASTRO inquiry submit error: $e');
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  void _showMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), behavior: SnackBarBehavior.floating),
    );
  }

  String _statusLabel(String status) {
    switch (status) {
      case 'in_progress':
        return 'قيد المراجعة';
      case 'answered':
        return 'تم الرد';
      case 'closed':
        return 'مغلق';
      default:
        return 'جديد';
    }
  }

  Future<List<Product>> _recommendedProducts(dynamic rawIds) async {
    if (rawIds is! List || rawIds.isEmpty) return [];
    final ids = rawIds.map((e) => e.toString()).where((e) => e.isNotEmpty).toList();
    if (ids.isEmpty) return [];
    try {
      final rows = await _db.from('products').select().inFilter('id', ids);
      return List<Map<String, dynamic>>.from(rows)
          .map((row) => Product.fromMap(row['id'].toString(), row))
          .toList();
    } catch (e) {
      debugPrint('ASTRO inquiry products error: $e');
      return [];
    }
  }

  @override
  Widget build(BuildContext context) {
    final signedIn = _db.auth.currentUser != null;
    return Scaffold(
      appBar: AppBar(
        title: const Text('استفسارات المنتجات'),
        actions: [
          IconButton(
            tooltip: 'تحديث',
            onPressed: _loadInquiries,
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: !signedIn
          ? _loginRequired()
          : RefreshIndicator(
              onRefresh: _loadInquiries,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
                children: [
                  _requestForm(),
                  const SizedBox(height: 22),
                  const Text(
                    'استفساراتي والردود',
                    style: TextStyle(
                      color: astroNavy,
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 10),
                  if (_loading)
                    const Padding(
                      padding: EdgeInsets.all(24),
                      child: Center(child: CircularProgressIndicator()),
                    )
                  else if (_error != null)
                    _emptyMessage(_error!)
                  else if (_inquiries.isEmpty)
                    _emptyMessage('لم ترسل أي استفسار حتى الآن.')
                  else
                    ..._inquiries.map(_inquiryCard),
                ],
              ),
            ),
    );
  }

  Widget _loginRequired() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(26),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.lock_outline_rounded, size: 54, color: astroBlue),
            const SizedBox(height: 14),
            const Text(
              'تسجيل الدخول مطلوب',
              style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: astroNavy),
            ),
            const SizedBox(height: 8),
            const Text(
              'سجّل الدخول إلى حسابك حتى تتمكن من إرسال الاستفسارات ومتابعة ردود الإدارة.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black54, height: 1.6),
            ),
            const SizedBox(height: 18),
            ElevatedButton.icon(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const AccountScreen()),
              ).then((_) => _loadInquiries()),
              icon: const Icon(Icons.login_rounded),
              label: const Text('تسجيل الدخول'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _requestForm() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'اطلب التحقق من التوفر',
              style: TextStyle(color: astroNavy, fontSize: 17, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 6),
            const Text(
              'اختر القسم واكتب موديل جهازك، وسنرسل لك جميع الخيارات المتوافقة والمتوفرة مع الصور والأسعار.',
              style: TextStyle(color: Colors.black54, height: 1.5, fontSize: 12),
            ),
            const SizedBox(height: 14),
            DropdownButtonFormField<int>(
              value: _categoryId,
              decoration: const InputDecoration(labelText: 'القسم'),
              items: _categories.map((item) => DropdownMenuItem<int>(
                value: item['id'] as int,
                child: Text(item['name'] as String),
              )).toList(),
              onChanged: (value) {
                if (value != null) setState(() => _categoryId = value);
              },
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _modelController,
              textInputAction: TextInputAction.next,
              decoration: const InputDecoration(
                labelText: 'موديل الجهاز',
                hintText: 'مثال: iPhone 13 Pro Max',
                prefixIcon: Icon(Icons.phone_iphone_rounded),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _noteController,
              maxLines: 2,
              decoration: const InputDecoration(
                labelText: 'ملاحظة إضافية (اختياري)',
                hintText: 'اكتب أي تفاصيل تساعدنا في تحديد المطلوب',
                alignLabelWithHint: true,
              ),
            ),
            const SizedBox(height: 14),
            ElevatedButton.icon(
              onPressed: _sending ? null : _sendInquiry,
              icon: _sending
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Icon(Icons.send_rounded),
              label: Text(_sending ? 'جارٍ الإرسال...' : 'إرسال الاستفسار'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _inquiryCard(Map<String, dynamic> inquiry) {
    final category = _categories.firstWhere(
      (item) => item['id'].toString() == inquiry['category_id'].toString(),
      orElse: () => {'name': 'منتجات'},
    )['name'];
    final status = (inquiry['status'] ?? 'new').toString();
    final reply = (inquiry['admin_reply'] ?? '').toString().trim();
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text('$category • ${inquiry['device_model'] ?? ''}',
                    style: const TextStyle(color: astroNavy, fontWeight: FontWeight.w900)),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
                  decoration: BoxDecoration(
                    color: status == 'answered' ? const Color(0xFFE6F7ED) : const Color(0xFFEAF3FF),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(_statusLabel(status),
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w800,
                      color: status == 'answered' ? const Color(0xFF16834A) : astroBlue,
                    )),
                ),
              ],
            ),
            if (reply.isNotEmpty) ...[
              const SizedBox(height: 12),
              const Text('رد الإدارة', style: TextStyle(color: astroBlue, fontWeight: FontWeight.w900)),
              const SizedBox(height: 5),
              Text(reply, style: const TextStyle(height: 1.5)),
            ],
            if (status == 'answered' && inquiry['recommended_product_ids'] is List) ...[
              const SizedBox(height: 12),
              FutureBuilder<List<Product>>(
                future: _recommendedProducts(inquiry['recommended_product_ids']),
                builder: (context, snapshot) {
                  final products = snapshot.data ?? [];
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const LinearProgressIndicator();
                  }
                  if (products.isEmpty) return const SizedBox.shrink();
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const Text('الخيارات المتوفرة لك', style: TextStyle(color: astroNavy, fontWeight: FontWeight.w900)),
                      const SizedBox(height: 8),
                      ...products.map(_recommendedProductTile),
                    ],
                  );
                },
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _recommendedProductTile(Product product) {
    return InkWell(
      onTap: () => Navigator.push(context, MaterialPageRoute(
        builder: (_) => ProductDetailScreen(product: product),
      )),
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          border: Border.all(color: const Color(0xFFE5EFFB)),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: SizedBox(
                width: 68,
                height: 68,
                child: product.imageUrl.isEmpty
                    ? const Icon(Icons.image_not_supported_outlined)
                    : AstroCachedImage(imageUrl: product.imageUrl, fit: BoxFit.contain),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(product.name, maxLines: 2, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w800, color: astroNavy)),
                  if (product.colors.isNotEmpty)
                    Text('الألوان: ${product.colors.join('، ')}',
                      style: const TextStyle(fontSize: 11, color: Colors.black54)),
                  Text('${product.price.toStringAsFixed(0)} د.ل',
                    style: const TextStyle(color: astroBlue, fontWeight: FontWeight.w900)),
                ],
              ),
            ),
            const Icon(Icons.chevron_left_rounded, color: astroBlue),
          ],
        ),
      ),
    );
  }

  Widget _emptyMessage(String message) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 22, horizontal: 8),
      child: Text(message, textAlign: TextAlign.center,
        style: const TextStyle(color: Colors.black54, height: 1.5)),
    );
  }
}

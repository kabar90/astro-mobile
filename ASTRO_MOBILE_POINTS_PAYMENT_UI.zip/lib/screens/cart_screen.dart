import 'package:flutter/material.dart';
import '../widgets/astro_cached_image.dart';
import '../main.dart';
import '../services/cart_service.dart';
import 'checkout_screen.dart';

class CartScreen extends StatelessWidget {
  const CartScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: CartService.instance,
      builder: (context, _) {
        final cart = CartService.instance;
        final items = cart.items;
        return Scaffold(
          backgroundColor: astroBackground,
          appBar: AppBar(
            title: const Text('السلة'),
            centerTitle: true,
            actions: [
              if (items.isNotEmpty)
                TextButton.icon(
                  onPressed: () => _confirmClear(context, cart),
                  icon: const Icon(Icons.delete_outline_rounded, size: 18),
                  label: const Text('إفراغ'),
                ),
            ],
          ),
          body: items.isEmpty
              ? _emptyCart(context)
              : Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
                      child: Row(
                        children: [
                          Container(
                            width: 42,
                            height: 42,
                            decoration: BoxDecoration(
                              color: const Color(0xFFE2F0FF),
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: const Icon(Icons.shopping_bag_outlined,
                                color: astroBlue),
                          ),
                          const SizedBox(width: 11),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text('مشترياتك',
                                    style: TextStyle(
                                        color: astroNavy,
                                        fontSize: 18,
                                        fontWeight: FontWeight.w900)),
                                Text('${cart.count} قطعة في السلة',
                                    style: const TextStyle(
                                        color: Color(0xFF718096), fontSize: 12)),
                              ],
                            ),
                          ),
                          const Icon(Icons.lock_outline_rounded,
                              color: Color(0xFF16A36A), size: 17),
                          const SizedBox(width: 4),
                          const Text('تسوق آمن',
                              style: TextStyle(
                                  color: Color(0xFF16A36A),
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700)),
                        ],
                      ),
                    ),
                    Expanded(
                      child: ListView.separated(
                        padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                        itemCount: items.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 11),
                        itemBuilder: (context, index) {
                          final item = items[index];
                          return Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(color: const Color(0xFFE1EAF5)),
                              boxShadow: const [
                                BoxShadow(
                                  color: Color(0x0B082C5C),
                                  blurRadius: 12,
                                  offset: Offset(0, 4),
                                ),
                              ],
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(15),
                                  child: Container(
                                    width: 94,
                                    height: 104,
                                    color: const Color(0xFFF2F7FD),
                                    child: item.product.imageUrl.isNotEmpty
                                        ? AstroCachedImage(
                                            imageUrl: item.product.imageUrl,
                                            fit: BoxFit.contain,
                                            errorWidget: const Icon(Icons.phone_iphone,
                                                size: 38, color: astroBlue),
                                          )
                                        : const Icon(Icons.phone_iphone,
                                            size: 38, color: astroBlue),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Expanded(
                                            child: Text(
                                              item.product.name,
                                              maxLines: 2,
                                              overflow: TextOverflow.ellipsis,
                                              style: const TextStyle(
                                                  color: astroNavy,
                                                  fontSize: 14,
                                                  height: 1.35,
                                                  fontWeight: FontWeight.w900),
                                            ),
                                          ),
                                          IconButton(
                                            visualDensity: VisualDensity.compact,
                                            constraints: const BoxConstraints(
                                                minWidth: 30, minHeight: 30),
                                            padding: EdgeInsets.zero,
                                            onPressed: () => cart.remove(item),
                                            icon: const Icon(
                                                Icons.delete_outline_rounded,
                                                color: Color(0xFFE05252),
                                                size: 20),
                                          ),
                                        ],
                                      ),
                                      if (item.color != null && item.color!.isNotEmpty)
                                        Padding(
                                          padding: const EdgeInsets.only(top: 3),
                                          child: Text('اللون: ${item.color}',
                                              style: const TextStyle(
                                                  color: Color(0xFF718096),
                                                  fontSize: 11)),
                                        ),
                                      const SizedBox(height: 5),
                                      Text(
                                        '${item.product.price.toStringAsFixed(2)} د.ل',
                                        style: const TextStyle(
                                            color: astroBlue,
                                            fontSize: 16,
                                            fontWeight: FontWeight.w900),
                                      ),
                                      const SizedBox(height: 8),
                                      Row(
                                        children: [
                                          _quantityButton(
                                            icon: Icons.remove_rounded,
                                            onTap: () => cart.changeQuantity(item, -1),
                                          ),
                                          SizedBox(
                                            width: 34,
                                            child: Text('${item.quantity}',
                                                textAlign: TextAlign.center,
                                                style: const TextStyle(
                                                    color: astroNavy,
                                                    fontWeight: FontWeight.w900)),
                                          ),
                                          _quantityButton(
                                            icon: Icons.add_rounded,
                                            onTap: () => cart.changeQuantity(item, 1),
                                          ),
                                          const Spacer(),
                                          Text(
                                            '${(item.product.price * item.quantity).toStringAsFixed(2)} د.ل',
                                            style: const TextStyle(
                                                color: astroNavy,
                                                fontWeight: FontWeight.w800,
                                                fontSize: 12),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: const BorderRadius.vertical(
                            top: Radius.circular(26)),
                        boxShadow: [
                          BoxShadow(
                            color: astroNavy.withOpacity(.07),
                            blurRadius: 18,
                            offset: const Offset(0, -5),
                          ),
                        ],
                      ),
                      child: SafeArea(
                        top: false,
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const Text('إجمالي المنتجات',
                                    style: TextStyle(
                                        color: Color(0xFF718096),
                                        fontWeight: FontWeight.w700)),
                                Text('${cart.total.toStringAsFixed(2)} د.ل',
                                    style: const TextStyle(
                                        color: astroNavy,
                                        fontSize: 21,
                                        fontWeight: FontWeight.w900)),
                              ],
                            ),
                            const SizedBox(height: 5),
                            const Align(
                              alignment: Alignment.centerRight,
                              child: Text('رسوم التوصيل تُحسب عند إتمام الطلب',
                                  style: TextStyle(
                                      color: Color(0xFF8A98A9), fontSize: 11)),
                            ),
                            const SizedBox(height: 13),
                            SizedBox(
                              width: double.infinity,
                              child: ElevatedButton.icon(
                                onPressed: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (_) => const CheckoutScreen()),
                                ),
                                icon: const Icon(Icons.arrow_back_rounded),
                                label: const Text('متابعة وإتمام الطلب'),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
        );
      },
    );
  }

  Widget _emptyCart(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 112,
                height: 112,
                decoration: const BoxDecoration(
                    color: Color(0xFFE4F1FF), shape: BoxShape.circle),
                child: const Icon(Icons.shopping_cart_outlined,
                    color: astroBlue, size: 52),
              ),
              const SizedBox(height: 18),
              const Text('سلتك فارغة حالياً',
                  style: TextStyle(
                      color: astroNavy,
                      fontSize: 20,
                      fontWeight: FontWeight.w900)),
              const SizedBox(height: 7),
              const Text('اكتشف المنتجات وأضف ما يعجبك إلى سلتك',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Color(0xFF718096))),
              const SizedBox(height: 18),
              ElevatedButton.icon(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.storefront_outlined),
                label: const Text('متابعة التسوق'),
              ),
            ],
          ),
        ),
      );

  Widget _quantityButton({required IconData icon, required VoidCallback onTap}) =>
      Material(
        color: const Color(0xFFEAF4FF),
        borderRadius: BorderRadius.circular(9),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(9),
          child: SizedBox(
            width: 29,
            height: 29,
            child: Icon(icon, color: astroBlue, size: 18),
          ),
        ),
      );

  Future<void> _confirmClear(BuildContext context, CartService cart) async {
    final clear = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('إفراغ السلة؟'),
        content: const Text('سيتم حذف جميع المنتجات من السلة.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('إلغاء')),
          TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('إفراغ السلة')),
        ],
      ),
    );
    if (clear == true) cart.clear();
  }
}

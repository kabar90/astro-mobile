
import 'package:flutter/material.dart';
import '../main.dart';
import '../models/product.dart';
import '../services/product_repository.dart';
import '../services/cart_service.dart';
import 'cart_screen.dart';
import 'product_detail_screen.dart';
import 'notifications_screen.dart';
import 'account_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final search = TextEditingController();
  final storeSearch = TextEditingController();
  String category = 'الكل';
  int? selectedCategoryId;
  int? selectedSubcategoryId;
  int? categoryPageRootId;
  int? categoryPageSubcategoryId;
  int nav = 0;

  @override
  void dispose() {
    search.dispose();
    storeSearch.dispose();
    super.dispose();
  }

  void message(String value) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(value),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<StoreCategory>>(
      stream: ProductRepository.watchCategories(),
      builder: (context, categorySnapshot) {
        final categories = categorySnapshot.data ?? [];
        final rootCategories = categories
            .where((item) => item.parentId == null && item.isActive)
            .toList()
          ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder));

        StoreCategory? selectedRoot;
        for (final item in categories) {
          if (item.id == selectedCategoryId) {
            selectedRoot = item;
            break;
          }
        }

        final selectedRootId = selectedRoot?.id;
        final selectedRootName = selectedRoot?.name;
        final subcategories = selectedRootId == null
            ? <StoreCategory>[]
            : (categories
                .where((item) =>
                    item.parentId == selectedRootId && item.isActive)
                .toList()
              ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder)));

        return StreamBuilder<List<Product>>(
          stream: ProductRepository.watchProducts(),
          builder: (context, snapshot) {
            final sourceProducts = snapshot.data ?? [];
            final visibleRootCategories = rootCategories.where((item) =>
                sourceProducts.any((product) => product.category == item.name)).toList();
            final q = search.text.trim().toLowerCase();
            final storeQuery = storeSearch.text.trim().toLowerCase();
            final storeProducts = sourceProducts.where((p) =>
                '${p.name} ${p.category} ${p.brand}'.toLowerCase().contains(storeQuery)).toList();

            final products = sourceProducts.where((p) {
              final matchesRoot = selectedRootName == null ||
                  p.category == selectedRootName;
              final matchesSubcategory = selectedSubcategoryId == null ||
                  p.subcategoryId == selectedSubcategoryId;
              final matchesSearch =
                  '${p.name} ${p.category}'.toLowerCase().contains(q);

              return matchesRoot && matchesSubcategory && matchesSearch;
            }).toList();

            return Scaffold(
          appBar: (nav == 2 || nav == 3) ? null : AppBar(
            title: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(9),
                  child: Image.asset(
                    'assets/astro-logo.jpg',
                    width: 42,
                    height: 42,
                    fit: BoxFit.contain,
                    errorBuilder: (_, __, ___) => const Icon(
                      Icons.smartphone_rounded,
                      size: 38,
                      color: astroBlue,
                    ),
                  ),
                ),
                const SizedBox(width: 9),
                const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'ASTRO MOBILE',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        letterSpacing: .5,
                        color: astroNavy,
                      ),
                    ),
                    Text(
                      'كل ما تحتاجه من التقنية',
                      style: TextStyle(fontSize: 10, color: Colors.black45),
                    ),
                  ],
                ),
              ],
            ),
            actions: [
              _action(
                Icons.notifications_none_rounded,
                () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const NotificationsScreen(),
                  ),
                ),
              ),
              const SizedBox(width: 7),
              AnimatedBuilder(
                animation: CartService.instance,
                builder: (context, _) => Stack(
                  clipBehavior: Clip.none,
                  children: [
                    _action(
                      Icons.shopping_bag_outlined,
                      () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const CartScreen()),
                      ),
                    ),
                    if (CartService.instance.count > 0)
                      Positioned(
                        right: 0,
                        top: 0,
                        child: Container(
                          padding: const EdgeInsets.all(4),
                          decoration: const BoxDecoration(
                            color: astroGold,
                            shape: BoxShape.circle,
                          ),
                          child: Text(
                            '${CartService.instance.count}',
                            style: const TextStyle(
                              color: astroNavy,
                              fontSize: 9,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(width: 14),
            ],
          ),

          body: nav == 3
              ? const AccountScreen()
              : nav == 2
                  ? const CartScreen()
                  : nav == 4
                      ? _buildStorePage(storeProducts)
                      : nav == 1
              ? _buildCategoriesPage(
                  rootCategories: visibleRootCategories,
                  categories: categories,
                  products: sourceProducts,
                )
              : CustomScrollView(
            slivers: [
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(18, 8, 18, 16),
                  child: Container(
                    height: 52,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(
                        color: const Color(0xFFE8EBF0),
                      ),
                    ),
                    child: TextField(
                      controller: search,
                      onChanged: (_) => setState(() {}),
                      decoration: const InputDecoration(
                        hintText: 'ابحث عن هاتف أو إكسسوار...',
                        hintStyle: TextStyle(
                          fontSize: 13,
                          color: Colors.black38,
                        ),
                        prefixIcon: Icon(
                          Icons.search,
                          color: astroGold,
                        ),
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(vertical: 15),
                      ),
                    ),
                  ),
                ),
              ),

              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 18),
                  child: Container(
                    height: 174,
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(22),
                      gradient: const LinearGradient(
                        colors: [
                          Color(0xFF082C5C),
                          Color(0xFF087FE5),
                        ],
                        begin: Alignment.topRight,
                        end: Alignment.bottomLeft,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: astroNavy.withOpacity(.15),
                          blurRadius: 16,
                          offset: const Offset(0, 7),
                        ),
                      ],
                    ),
                    child: Stack(
                      children: [
                        Positioned(
                          left: -5,
                          bottom: -20,
                          child: Icon(
                            Icons.phone_iphone_rounded,
                            size: 130,
                            color: Colors.white.withOpacity(.08),
                          ),
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 5,
                              ),
                              decoration: BoxDecoration(
                                color: astroGold.withOpacity(.18),
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(
                                  color: astroGold.withOpacity(.5),
                                ),
                              ),
                              child: const Text(
                                'ASTRO MOBILE',
                                style: TextStyle(
                                  color: Color(0xFFBDEBFF),
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            const SizedBox(height: 12),
                            const Text(
                              'كل ما تحتاجه من التقنية',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 21,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                            const SizedBox(height: 6),
                            const Text(
                              'أحدث الهواتف والإكسسوارات بأسعار مميزة',
                              style: TextStyle(
                                color: Colors.white70,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(18, 18, 18, 4),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Expanded(
                            child: Text(
                              'تصفح الأقسام',
                              style: TextStyle(
                                color: astroNavy,
                                fontSize: 15,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ),
                          if (categorySnapshot.connectionState ==
                              ConnectionState.waiting)
                            const SizedBox(
                              width: 15,
                              height: 15,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: astroBlue,
                              ),
                            ),
                        ],
                      ),
                      const SizedBox(height: 11),
                      if (visibleRootCategories.isEmpty)
                        const Text(
                          'ستظهر الأقسام هنا عند توفر المنتجات',
                          style: TextStyle(color: Colors.black45, fontSize: 11),
                        )
                      else
                        GridView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: visibleRootCategories.length > 4
                              ? 4
                              : visibleRootCategories.length,
                          gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            mainAxisSpacing: 9,
                            crossAxisSpacing: 9,
                            childAspectRatio: 2.7,
                          ),
                          itemBuilder: (context, index) {
                            final item = visibleRootCategories[index];
                            final selected = selectedCategoryId == item.id;
                            return Material(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(15),
                              child: InkWell(
                                borderRadius: BorderRadius.circular(15),
                                onTap: () => setState(() {
                                  category = item.name;
                                  selectedCategoryId = item.id;
                                  selectedSubcategoryId = null;
                                }),
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 11),
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(15),
                                    border: Border.all(
                                      color: selected
                                          ? astroBlue
                                          : const Color(0xFFDCE9F8),
                                      width: selected ? 1.4 : 1,
                                    ),
                                    gradient: LinearGradient(
                                      colors: selected
                                          ? const [Color(0xFFEAF5FF), Color(0xFFDCEEFF)]
                                          : const [Colors.white, Color(0xFFF5FAFF)],
                                    ),
                                  ),
                                  child: Row(
                                    children: [
                                      Icon(_categoryIcon(item.name),
                                          color: astroBlue, size: 25),
                                      const SizedBox(width: 9),
                                      Expanded(
                                        child: Text(
                                          item.name,
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: const TextStyle(
                                            color: astroNavy,
                                            fontSize: 12,
                                            fontWeight: FontWeight.w900,
                                          ),
                                        ),
                                      ),
                                      const Icon(Icons.chevron_left_rounded,
                                          color: astroBlue, size: 19),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                      if (selectedRoot != null && subcategories.isNotEmpty) ...[
                        const SizedBox(height: 12),
                        Text(
                          'الأقسام الفرعية في ${selectedRoot.name}',
                          style: const TextStyle(
                            color: Colors.black54,
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 7),
                        SizedBox(
                          height: 36,
                          child: ListView(
                            scrollDirection: Axis.horizontal,
                            children: [
                              _subcategoryChip(
                                'كل ${selectedRoot.name}',
                                selectedSubcategoryId == null,
                                () => setState(() {
                                  selectedSubcategoryId = null;
                                }),
                              ),
                              ...subcategories.map(
                                (item) => _subcategoryChip(
                                  item.name,
                                  selectedSubcategoryId == item.id,
                                  () => setState(() {
                                    selectedSubcategoryId = item.id;
                                  }),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                      if (categorySnapshot.hasError)
                        Padding(
                          padding: const EdgeInsets.only(top: 8),
                          child: Text(
                            'تعذر تحميل الأقسام: ${categorySnapshot.error}',
                            style: const TextStyle(
                              color: Colors.red,
                              fontSize: 11,
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),

              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(18, 20, 18, 12),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          selectedRoot == null ? 'أحدث المنتجات' : 'منتجات ${selectedRoot.name}',
                          style: TextStyle(
                            fontSize: 19,
                            fontWeight: FontWeight.w900,
                            color: astroNavy,
                          ),
                        ),
                      ),
                      Text(
                        '${products.length} منتجات',
                        style: const TextStyle(
                          fontSize: 12,
                          color: Colors.black45,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              if (snapshot.connectionState == ConnectionState.waiting &&
                  !snapshot.hasData)
                const SliverToBoxAdapter(
                  child: Padding(
                    padding: EdgeInsets.all(45),
                    child: Center(
                      child: CircularProgressIndicator(
                        color: astroGold,
                      ),
                    ),
                  ),
                )
              else if (snapshot.hasError)
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.all(30),
                    child: Center(
                      child: Column(
                        children: [
                          const Icon(
                            Icons.cloud_off_rounded,
                            size: 48,
                            color: Colors.black38,
                          ),
                          const SizedBox(height: 12),
                          const Text(
                            'تعذر الاتصال بالمتجر حالياً',
                            style: TextStyle(
                              color: astroNavy,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 8),
                          const Text(
                            'يرجى التأكد من اتصال الإنترنت والمحاولة مجدداً.',
                            textAlign: TextAlign.center,
                            style: TextStyle(color: Colors.black45),
                          ),
                          TextButton(
                            onPressed: () => setState(() {}),
                            child: const Text('إعادة المحاولة'),
                          ),
                        ],
                      ),
                    ),
                  ),
                )
              else if (products.isEmpty)
                const SliverToBoxAdapter(
                  child: Padding(
                    padding: EdgeInsets.all(35),
                    child: Center(
                      child: Column(
                        children: [
                          Icon(
                            Icons.inventory_2_outlined,
                            size: 48,
                            color: Colors.black38,
                          ),
                          SizedBox(height: 12),
                          Text(
                            'لا توجد منتجات متاحة حالياً',
                            style: TextStyle(
                              color: astroNavy,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                )
              else
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 22),
                  sliver: SliverGrid(
                    delegate: SliverChildBuilderDelegate(
                      (context, index) => _product(products[index]),
                      childCount: products.length,
                    ),
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      mainAxisSpacing: 14,
                      crossAxisSpacing: 14,
                      childAspectRatio: .66,
                    ),
                  ),
                ),
            ],
          ),

          bottomNavigationBar: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(.06),
                  blurRadius: 12,
                  offset: const Offset(0, -3),
                ),
              ],
            ),
            child: SafeArea(
              top: false,
              child: SizedBox(
                height: 64,
                child: Row(
                  children: [
                    _navItem(3, Icons.person_outline_rounded, 'حسابي'),
                    _navItem(2, Icons.shopping_cart_outlined, 'السلة'),
                    _navItem(0, Icons.home_rounded, 'الرئيسية'),
                    _navItem(1, Icons.grid_view_rounded, 'الأقسام'),
                    _navItem(4, Icons.storefront_outlined, 'المتجر'),
                  ],
                ),
              ),
            ),
          ),
        );
          },
        );
      },
    );
  }

  Widget _action(IconData icon, VoidCallback tap) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Material(
        color: Colors.white,
        shape: const CircleBorder(),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: tap,
          child: SizedBox(
            width: 40,
            height: 40,
            child: Icon(icon, color: astroNavy, size: 21),
          ),
        ),
      ),
    );
  }

  Widget _categoryChip(
    String label,
    bool selected,
    VoidCallback onTap,
  ) {
    return Padding(
      padding: const EdgeInsetsDirectional.only(end: 8),
      child: Material(
        color: selected ? astroNavy : Colors.white,
        borderRadius: BorderRadius.circular(22),
        child: InkWell(
          borderRadius: BorderRadius.circular(22),
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 17, vertical: 9),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              border: Border.all(
                color: selected ? astroNavy : const Color(0xFFE1E8F0),
              ),
            ),
            child: Text(
              label,
              style: TextStyle(
                color: selected ? Colors.white : astroNavy,
                fontSize: 12,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _subcategoryChip(
    String label,
    bool selected,
    VoidCallback onTap,
  ) {
    return Padding(
      padding: const EdgeInsetsDirectional.only(end: 7),
      child: Material(
        color: selected ? const Color(0xFFDCEEFF) : Colors.white,
        borderRadius: BorderRadius.circular(18),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                color: selected ? astroBlue : const Color(0xFFE5EBF2),
              ),
            ),
            child: Text(
              label,
              style: TextStyle(
                color: selected ? astroBlue : astroNavy,
                fontSize: 11,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _product(Product p) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(19),
      elevation: 1,
      shadowColor: astroNavy.withOpacity(.07),
      child: InkWell(
        borderRadius: BorderRadius.circular(19),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => ProductDetailScreen(product: p),
            ),
          );
        },
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(19),
            border: Border.all(
              color: const Color(0xFFE0EAF5),
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Stack(
                  children: [
                    ClipRRect(
                      borderRadius: const BorderRadius.vertical(
                        top: Radius.circular(19),
                      ),
                      child: SizedBox(
                        width: double.infinity,
                        child: p.imageUrl.isEmpty
                            ? _placeholder(p.category, false)
                            : Image.network(
                                p.imageUrl,
                                fit: BoxFit.contain,
                                loadingBuilder: (context, child, progress) {
                                  if (progress == null) return child;
                                  return _placeholder(p.category, true);
                                },
                                errorBuilder: (_, __, ___) =>
                                    _placeholder(p.category, false),
                              ),
                      ),
                    ),
                    Positioned(
                      top: 9,
                      right: 9,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 9,
                          vertical: 5,
                        ),
                        decoration: BoxDecoration(
                          color: const Color(0xFFE6F4FF),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          p.category,
                          style: const TextStyle(
                            fontSize: 10,
                            color: astroNavy,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(11, 9, 11, 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      p.name,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 13,
                        height: 1.25,
                        fontWeight: FontWeight.w800,
                        color: astroNavy,
                      ),
                    ),
                    const SizedBox(height: 9),
                    Text(
                      '${p.price.toStringAsFixed(0)} د.ل',
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w900,
                        color: astroNavy,
                      ),
                    ),
                    const SizedBox(height: 7),
                    Row(
                      children: [
                        const Icon(
                          Icons.card_giftcard_rounded,
                          size: 15,
                          color: Color(0xFFD69A22),
                        ),
                        const SizedBox(width: 5),
                        Expanded(
                          child: Text(
                            'نقاط المكافأة: ${p.rewardPoints} نقطة',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w800,
                              color: Color(0xFF8A6416),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _placeholder(String cat, bool loading) {
    return Container(
      color: const Color(0xFFF2F4F7),
      child: Center(
        child: loading
            ? const SizedBox(
                width: 22,
                height: 22,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: astroGold,
                ),
              )
            : Icon(
                cat == 'هواتف'
                    ? Icons.smartphone_rounded
                    : Icons.headphones_rounded,
                size: 55,
                color: astroNavy.withOpacity(.3),
              ),
      ),
    );
  }

  IconData _categoryIcon(String name) {
    final value = name.trim().toLowerCase();

    if (value.contains('هواتف') || value.contains('هاتف') ||
        value.contains('موبايل') || value.contains('جوال') ||
        value.contains('phone')) {
      return Icons.smartphone_rounded;
    }
    if (value.contains('كمال') || value.contains('اكسسوار') ||
        value.contains('إكسسوار') || value.contains('سما') ||
        value.contains('headphone')) {
      return Icons.headphones_rounded;
    }
    if (value.contains('مستعمل') || value.contains('used')) {
      return Icons.recycling_rounded;
    }
    if (value.contains('لوح') || value.contains('تابلت') ||
        value.contains('tablet')) {
      return Icons.tablet_android_rounded;
    }
    if (value.contains('ساع') || value.contains('watch')) {
      return Icons.watch_rounded;
    }
    if (value.contains('كمبيوتر') || value.contains('لابتوب') ||
        value.contains('حاسوب') || value.contains('computer')) {
      return Icons.laptop_chromebook_rounded;
    }
    return Icons.widgets_rounded;
  }

  Widget _buildCategoriesPage({
    required List<StoreCategory> rootCategories,
    required List<StoreCategory> categories,
    required List<Product> products,
  }) {
    StoreCategory? selectedRoot;
    for (final item in rootCategories) {
      if (item.id == categoryPageRootId) {
        selectedRoot = item;
        break;
      }
    }

    final subcategories = selectedRoot == null
        ? <StoreCategory>[]
        : (categories
            .where((item) =>
                item.parentId == selectedRoot!.id && item.isActive)
            .toList()
          ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder)));

    final visibleProducts = selectedRoot == null
        ? <Product>[]
        : products.where((product) {
            final matchesRoot = product.category == selectedRoot!.name;
            final matchesSubcategory = categoryPageSubcategoryId == null ||
                product.subcategoryId == categoryPageSubcategoryId;
            return matchesRoot && matchesSubcategory;
          }).toList();

    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 22, 18, 12),
            child: Row(
              children: [
                if (selectedRoot != null)
                  IconButton(
                    tooltip: 'العودة إلى جميع الأقسام',
                    onPressed: () => setState(() {
                      categoryPageRootId = null;
                      categoryPageSubcategoryId = null;
                    }),
                    icon: const Icon(Icons.arrow_forward_rounded,
                        color: astroNavy),
                  ),
                Expanded(
                  child: Text(
                    selectedRoot == null ? 'جميع الأقسام' : selectedRoot.name,
                    style: const TextStyle(
                      color: astroNavy,
                      fontSize: 21,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
                if (selectedRoot != null)
                  TextButton(
                    onPressed: () => setState(() {
                      categoryPageSubcategoryId = null;
                    }),
                    child: const Text('كل المنتجات'),
                  ),
              ],
            ),
          ),
        ),
        if (selectedRoot == null)
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
            sliver: SliverGrid(
              delegate: SliverChildBuilderDelegate(
                (context, index) {
                  final item = rootCategories[index];
                  final childCount = categories
                      .where((category) =>
                          category.parentId == item.id && category.isActive)
                      .length;
                  final categoryIcon = _categoryIcon(item.name);
                  return Material(
                    color: Colors.transparent,
                    borderRadius: BorderRadius.circular(20),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(20),
                      onTap: () => setState(() {
                        categoryPageRootId = item.id;
                        categoryPageSubcategoryId = null;
                      }),
                      child: Ink(
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            begin: Alignment.topRight,
                            end: Alignment.bottomLeft,
                            colors: [Colors.white, Color(0xFFF0F7FF)],
                          ),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: const Color(0xFFDCE9F6),
                            width: 1.1,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: astroNavy.withOpacity(.055),
                              blurRadius: 13,
                              offset: const Offset(0, 5),
                            ),
                          ],
                        ),
                        padding: const EdgeInsets.fromLTRB(14, 15, 14, 13),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              width: 58,
                              height: 58,
                              decoration: BoxDecoration(
                                gradient: const LinearGradient(
                                  colors: [Color(0xFFE5F3FF), Color(0xFFD4EAFE)],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                ),
                                borderRadius: BorderRadius.circular(18),
                              ),
                              child: Icon(
                                categoryIcon,
                                color: astroBlue,
                                size: 31,
                              ),
                            ),
                            const SizedBox(height: 12),
                            Text(
                              item.name,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                color: astroNavy,
                                fontSize: 16,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                            const SizedBox(height: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 4,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(.9),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Text(
                                childCount == 0
                                    ? 'تصفح المنتجات'
                                    : '$childCount أقسام فرعية',
                                style: const TextStyle(
                                  color: Color(0xFF6B7F93),
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
                childCount: rootCategories.length,
              ),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 1.12,
              ),
            ),
          )
        else ...[
          if (subcategories.isNotEmpty)
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                child: Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _subcategoryChip(
                      'الكل',
                      categoryPageSubcategoryId == null,
                      () => setState(() => categoryPageSubcategoryId = null),
                    ),
                    ...subcategories.map(
                      (item) => _subcategoryChip(
                        item.name,
                        categoryPageSubcategoryId == item.id,
                        () => setState(
                            () => categoryPageSubcategoryId = item.id),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 12, 18, 10),
              child: Row(
                children: [
                  const Expanded(
                    child: Text(
                      'المنتجات',
                      style: TextStyle(
                        color: astroNavy,
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                  Text(
                    '${visibleProducts.length} منتجات',
                    style: const TextStyle(
                        color: Colors.black45, fontSize: 12),
                  ),
                ],
              ),
            ),
          ),
          if (visibleProducts.isEmpty)
            const SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.all(28),
                child: Center(
                  child: Text(
                    'لا توجد منتجات في هذا القسم حالياً',
                    style: TextStyle(color: Colors.black54),
                  ),
                ),
              ),
            )
          else
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              sliver: SliverGrid(
                delegate: SliverChildBuilderDelegate(
                  (context, index) => _product(visibleProducts[index]),
                  childCount: visibleProducts.length,
                ),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 14,
                  crossAxisSpacing: 14,
                  childAspectRatio: .66,
                ),
              ),
            ),
        ],
      ],
    );
  }

  Widget _buildStorePage(List<Product> products) {
    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 18, 18, 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('المتجر', style: TextStyle(color: astroNavy, fontSize: 22, fontWeight: FontWeight.w900)),
                const SizedBox(height: 12),
                TextField(
                  controller: storeSearch,
                  onChanged: (_) => setState(() {}),
                  textInputAction: TextInputAction.search,
                  decoration: InputDecoration(
                    hintText: 'ابحث عن منتج أو قسم أو علامة تجارية...',
                    prefixIcon: const Icon(Icons.search, color: astroBlue),
                    suffixIcon: storeSearch.text.isEmpty ? null : IconButton(
                      icon: const Icon(Icons.close),
                      onPressed: () { storeSearch.clear(); setState(() {}); },
                    ),
                    filled: true, fillColor: Colors.white,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
                  ),
                ),
              ],
            ),
          ),
        ),
        if (products.isEmpty)
          const SliverToBoxAdapter(child: Padding(padding: EdgeInsets.all(30), child: Center(child: Text('لا توجد منتجات مطابقة'))))
        else
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
            sliver: SliverGrid(
              delegate: SliverChildBuilderDelegate((context, index) => _product(products[index]), childCount: products.length),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 14, crossAxisSpacing: 14, childAspectRatio: .66),
            ),
          ),
      ],
    );
  }

  Widget _navItem(int i, IconData icon, String label) {
    final active = nav == i;

    return Expanded(
      child: InkWell(
        onTap: () {
          setState(() {
            nav = i;
            if (i == 1) {
              categoryPageRootId = null;
              categoryPageSubcategoryId = null;
            }
          });
        },
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              width: active ? 38 : 32,
              height: active ? 30 : 27,
              decoration: BoxDecoration(
                color: active ? astroBlue : Colors.transparent,
                borderRadius: BorderRadius.circular(18),
              ),
              child: Icon(
                icon,
                color: active ? Colors.white : const Color(0xFF53657A),
                size: active ? 19 : 21,
              ),
            ),
            const SizedBox(height: 3),
            Text(
              label,
              style: TextStyle(
                fontSize: 10,
                color: active ? astroBlue : const Color(0xFF53657A),
                fontWeight: active ? FontWeight.w900 : FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

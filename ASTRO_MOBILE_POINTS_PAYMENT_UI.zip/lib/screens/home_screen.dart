
import 'package:flutter/material.dart';
import '../widgets/astro_cached_image.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../main.dart';
import '../models/product.dart';
import '../services/product_repository.dart';
import '../services/cart_service.dart';
import 'cart_screen.dart';
import 'product_detail_screen.dart';
import 'notifications_screen.dart';
import 'account_screen.dart';
import 'contact_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final search = TextEditingController();
  final storeSearch = TextEditingController();
  String category = 'الكل';
  int? selectedCategoryId;
  int? selectedSubcategoryId;
  int? categoryPageRootId;
  int? categoryPageSubcategoryId;
  int nav = 0;
  String _categorySort = 'الأحدث';
  String? _activeHomeSectionTitle;
  List<Product>? _activeHomeSectionProducts;
  late final Stream<List<StoreCategory>> _categoriesStream;
  late final Stream<List<Product>> _productsStream;

  @override
  void initState() {
    super.initState();
    // Reuse the same subscriptions when search fields or navigation rebuild.
    _categoriesStream = ProductRepository.watchCategories();
    _productsStream = ProductRepository.watchProducts();
  }

  @override
  void dispose() {
    search.dispose();
    storeSearch.dispose();
    super.dispose();
  }

  void message(String value) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(value),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<StoreCategory>>(
      stream: _categoriesStream,
      builder: (context, categorySnapshot) {
        final categories = categorySnapshot.data ?? [];
        final rootCategories = categories
            .where((item) => item.parentId == null && item.isActive)
            .toList()
          ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder));

        StoreCategory? selectedRoot;
        for (final item in categories) {
          if (item.id == selectedCategoryId) {
            selectedRoot = item;
            break;
          }
        }

        final selectedRootId = selectedRoot?.id;
        final selectedRootName = selectedRoot?.name;
        final subcategories = selectedRootId == null
            ? <StoreCategory>[]
            : (categories
                .where((item) =>
                    item.parentId == selectedRootId && item.isActive)
                .toList()
              ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder)));

        return StreamBuilder<List<Product>>(
          stream: _productsStream,
          builder: (context, snapshot) {
            final sourceProducts = snapshot.data ?? [];
            // الصفحة الرئيسية تعرض الأقسام الرئيسية فقط؛ الأقسام الفرعية
            // تظهر داخل القسم المختار في صفحة الأقسام.
            final homeCategoryTiles = rootCategories;
            final q = search.text.trim().toLowerCase();
            final storeQuery = storeSearch.text.trim().toLowerCase();
            final storeProducts = sourceProducts.where((p) =>
                '${p.name} ${p.category} ${p.brand}'.toLowerCase().contains(storeQuery)).toList();

            final products = sourceProducts.where((p) {
              final matchesRoot = selectedRootName == null ||
                  p.category == selectedRootName;
              final matchesSubcategory = selectedSubcategoryId == null ||
                  p.subcategoryId == selectedSubcategoryId;
              final matchesSearch =
                  '${p.name} ${p.category}'.toLowerCase().contains(q);

              return matchesRoot && matchesSubcategory && matchesSearch;
            }).toList();


            return Scaffold(
          appBar: (_activeHomeSectionTitle != null || nav == 2 || nav == 3) ? null : AppBar(
            centerTitle: true,
            title: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'ASTRO MOBILE',
                      style: TextStyle(
                        fontSize: 19,
                        fontWeight: FontWeight.w900,
                        letterSpacing: .5,
                        color: astroNavy,
                      ),
                    ),
                    Text(
                      'كل ما تحتاجه من التقنية',
                      style: TextStyle(fontSize: 10, color: Colors.black45),
                    ),
                  ],
                ),
                const SizedBox(width: 7),
                ClipRRect(
                  borderRadius: BorderRadius.circular(13),
                  child: Image.asset(
                    'assets/astro-logo.jpg',
                    width: 48,
                    height: 48,
                    fit: BoxFit.contain,
                    errorBuilder: (_, __, ___) => const Icon(
                      Icons.smartphone_rounded,
                      size: 36,
                      color: astroBlue,
                    ),
                  ),
                ),
              ],
            ),
            actions: [
              _action(
                Icons.notifications_none_rounded,
                () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const NotificationsScreen(),
                  ),
                ),
              ),
              const SizedBox(width: 7),
              AnimatedBuilder(
                animation: CartService.instance,
                builder: (context, _) => Stack(
                  clipBehavior: Clip.none,
                  children: [
                    _action(
                      Icons.shopping_bag_outlined,
                      () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const CartScreen()),
                      ),
                    ),
                    if (CartService.instance.count > 0)
                      Positioned(
                        right: 0,
                        top: 0,
                        child: Container(
                          padding: const EdgeInsets.all(4),
                          decoration: const BoxDecoration(
                            color: astroGold,
                            shape: BoxShape.circle,
                          ),
                          child: Text(
                            '${CartService.instance.count}',
                            style: const TextStyle(
                              color: astroNavy,
                              fontSize: 9,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(width: 14),
            ],
          ),

          body: _activeHomeSectionTitle != null && _activeHomeSectionProducts != null
              ? _buildHomeSectionProductsPage(
                  _activeHomeSectionTitle!,
                  _activeHomeSectionProducts!,
                )
              : nav == 3
                  ? const AccountScreen()
                  : nav == 2
                      ? const CartScreen()
                      : nav == 4
                          ? _buildStorePage(storeProducts)
                          : nav == 5
                              ? const ContactScreen()
                          : nav == 1
              ? _buildCategoriesPage(
                  rootCategories: rootCategories,
                  categories: categories,
                  products: sourceProducts,
                )
              : CustomScrollView(
            slivers: [
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(18, 8, 18, 16),
                  child: Container(
                    height: 52,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(
                        color: const Color(0xFFE8EBF0),
                      ),
                    ),
                    child: TextField(
                      controller: search,
                      onChanged: (_) => setState(() {}),
                      decoration: const InputDecoration(
                        hintText: 'ابحث عن هاتف أو إكسسوار...',
                        hintStyle: TextStyle(
                          fontSize: 13,
                          color: Colors.black38,
                        ),
                        prefixIcon: Icon(
                          Icons.search,
                          color: astroGold,
                        ),
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(vertical: 15),
                      ),
                    ),
                  ),
                ),
              ),

              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 18),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(23),
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        onTap: () => setState(() => nav = 4),
                        child: SizedBox(
                          width: double.infinity,
                          height: 158,
                          child: Image.asset(
                            'assets/astro-banner-phones.jpg',
                            fit: BoxFit.cover,
                            alignment: Alignment.center,
                            errorBuilder: (_, __, ___) => Container(
                              decoration: const BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [Color(0xFF0878D8), Color(0xFF061D49)],
                                ),
                              ),
                              child: const Center(
                                child: Text(
                                  'ASTRO MOBILE',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 22,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),

              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(18, 20, 18, 2),
                  child: Row(
                    children: [
                      const Icon(Icons.grid_view_rounded, color: astroBlue, size: 19),
                      const SizedBox(width: 6),
                      const Text(
                        'الأقسام الرئيسية',
                        style: TextStyle(color: astroNavy, fontSize: 17, fontWeight: FontWeight.w900),
                      ),
                      const Spacer(),
                      TextButton(
                        onPressed: () => setState(() => nav = 1),
                        child: const Row(
                          children: [
                            Text('عرض الكل', style: TextStyle(color: astroBlue, fontSize: 11, fontWeight: FontWeight.w800)),
                            Icon(Icons.chevron_left_rounded, size: 18, color: astroBlue),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
                            SliverToBoxAdapter(
                child: SizedBox(
                  height: 176,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: homeCategoryTiles.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 10),
                    itemBuilder: (context, index) {
                      final item = homeCategoryTiles[index];
                      final categoryAsset = _categoryAsset(item.name);
                      final palette = const [
                        Color(0xFFDCEEFF), Color(0xFFDDF5E8), Color(0xFFEFE2FF),
                        Color(0xFFFFE8D5), Color(0xFFFFE1EA), Color(0xFFE3EAFF),
                        Color(0xFFDDF5F7), Color(0xFFFFF1D9),
                      ];
                      return SizedBox(
                        width: 164,
                        child: Material(
                          color: Colors.transparent,
                          child: InkWell(
                            borderRadius: BorderRadius.circular(20),
                            onTap: () => setState(() {
                              category = item.name;
                              selectedCategoryId = item.id;
                              selectedSubcategoryId = null;
                              categoryPageRootId = item.id;
                              categoryPageSubcategoryId = null;
                              nav = 1;
                            }),
                            child: Ink(
                              decoration: BoxDecoration(
                                color: palette[index % palette.length],
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(color: const Color(0xFFD5E4F3)),
                              ),
                              padding: const EdgeInsets.all(9),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Expanded(
                                    child: Image.asset(
                                      categoryAsset,
                                      fit: BoxFit.contain,
                                      errorBuilder: (_, __, ___) => Icon(
                                        _categoryIcon(item.name),
                                        color: astroBlue,
                                        size: 42,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 6),
                                  Text(
                                    item.name,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.center,
                                    style: const TextStyle(
                                      color: astroNavy,
                                      fontSize: 11,
                                      fontWeight: FontWeight.w900,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),


              SliverToBoxAdapter(
                child: StreamBuilder<List<Map<String, dynamic>>>(
                  stream: Supabase.instance.client
                      .from('offers')
                      .stream(primaryKey: ['id']),
                  builder: (context, offerSnapshot) {
                    final now = DateTime.now();
                    final activeOffers = (offerSnapshot.data ?? []).where((offer) {
                      final starts = DateTime.tryParse('${offer['starts_at'] ?? ''}');
                      final ends = DateTime.tryParse('${offer['ends_at'] ?? ''}');
                      return offer['is_active'] == true && starts != null && ends != null &&
                          !now.isBefore(starts) && now.isBefore(ends);
                    }).toList();

                    final offerCards = <Widget>[];
                    final usedProducts = <String>{};
                    for (final offer in activeOffers) {
                      final type = '${offer['offer_type'] ?? ''}';
                      if (type == 'bundle') continue;
                      final discountType = '${offer['discount_type'] ?? ''}';
                      final discountValue = double.tryParse('${offer['discount_value'] ?? ''}') ?? 0;
                      if (discountValue <= 0) continue;

                      for (final product in products) {
                        final matches = type == 'product'
                            ? product.id == '${offer['product_id']}'
                            : type == 'category' && product.category == '${offer['category_name'] ?? ''}';
                        if (!matches || usedProducts.contains(product.id)) continue;
                        final salePrice = discountType == 'percentage'
                            ? product.price * (1 - discountValue / 100)
                            : discountValue;
                        if (salePrice < 0 || salePrice >= product.price) continue;
                        usedProducts.add(product.id);
                        offerCards.add(_offerProductCard(
                          product,
                          salePrice,
                          discountType == 'percentage'
                              ? 'خصم ${discountValue.toStringAsFixed(0)}%'
                              : 'سعر خاص',
                        ));
                      }
                    }

                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Padding(
                          padding: const EdgeInsets.fromLTRB(18, 20, 18, 8),
                          child: Row(
                            children: const [
                              Text('العروض والتخفيضات', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: astroNavy)),
                              Spacer(),
                              Icon(Icons.local_offer_rounded, color: Color(0xFFE44755), size: 20),
                            ],
                          ),
                        ),
                        if (offerCards.isEmpty)
                          Padding(
                            padding: const EdgeInsets.fromLTRB(18, 4, 18, 10),
                            child: Container(
                              height: 76,
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                color: const Color(0xFFFFF0F1),
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(color: const Color(0xFFFFD8DD)),
                              ),
                              child: const Text('ترقبوا عروض ASTRO MOBILE قريباً',
                                style: TextStyle(color: astroNavy, fontWeight: FontWeight.w800)),
                            ),
                          )
                        else
                          SizedBox(
                            height: 164,
                            child: ListView.separated(
                              padding: const EdgeInsets.symmetric(horizontal: 16),
                              scrollDirection: Axis.horizontal,
                              itemCount: offerCards.length,
                              separatorBuilder: (_, __) => const SizedBox(width: 11),
                              itemBuilder: (_, index) => offerCards[index],
                            ),
                          ),
                      ],
                    );
                  },
                ),
              ),

              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(18, 20, 18, 12),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          selectedRoot == null ? 'أحدث المنتجات' : 'منتجات ${selectedRoot.name}',
                          style: TextStyle(
                            fontSize: 19,
                            fontWeight: FontWeight.w900,
                            color: astroNavy,
                          ),
                        ),
                      ),
                      Text(
                        '${products.length} منتجات',
                        style: const TextStyle(
                          fontSize: 12,
                          color: Colors.black45,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              if (snapshot.connectionState == ConnectionState.waiting &&
                  !snapshot.hasData)
                const SliverToBoxAdapter(
                  child: Padding(
                    padding: EdgeInsets.all(45),
                    child: Center(
                      child: CircularProgressIndicator(
                        color: astroGold,
                      ),
                    ),
                  ),
                )
              else if (snapshot.hasError)
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.all(30),
                    child: Center(
                      child: Column(
                        children: [
                          const Icon(
                            Icons.cloud_off_rounded,
                            size: 48,
                            color: Colors.black38,
                          ),
                          const SizedBox(height: 12),
                          const Text(
                            'تعذر الاتصال بالمتجر حالياً',
                            style: TextStyle(
                              color: astroNavy,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 8),
                          const Text(
                            'يرجى التأكد من اتصال الإنترنت والمحاولة مجدداً.',
                            textAlign: TextAlign.center,
                            style: TextStyle(color: Colors.black45),
                          ),
                          TextButton(
                            onPressed: () => setState(() {}),
                            child: const Text('إعادة المحاولة'),
                          ),
                        ],
                      ),
                    ),
                  ),
                )
              else if (products.isEmpty)
                const SliverToBoxAdapter(
                  child: Padding(
                    padding: EdgeInsets.all(35),
                    child: Center(
                      child: Column(
                        children: [
                          Icon(
                            Icons.inventory_2_outlined,
                            size: 48,
                            color: Colors.black38,
                          ),
                          SizedBox(height: 12),
                          Text(
                            'لا توجد منتجات متاحة حالياً',
                            style: TextStyle(
                              color: astroNavy,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                )
              else
                SliverToBoxAdapter(
                  child: SizedBox(
                    height: 258,
                    child: ListView.separated(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 18),
                      scrollDirection: Axis.horizontal,
                      itemCount: products.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 12),
                      itemBuilder: (context, index) => _horizontalProductCard(products[index]),
                    ),
                  ),
                ),

              SliverToBoxAdapter(
                child: _managedHomeSections(sourceProducts),
              ),
            ],
          ),

          bottomNavigationBar: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(.06),
                  blurRadius: 12,
                  offset: const Offset(0, -3),
                ),
              ],
            ),
            child: SafeArea(
              top: false,
              child: SizedBox(
                height: 64,
                child: Row(
                  children: [
                    _navItem(3, Icons.person_outline_rounded, 'حسابي'),
                    _navItem(2, Icons.shopping_cart_outlined, 'السلة'),
                    _navItem(0, Icons.home_rounded, 'الرئيسية'),
                    _navItem(1, Icons.grid_view_rounded, 'الأقسام'),
                    _navItem(4, Icons.storefront_outlined, 'المتجر'),
                    _navItem(5, Icons.headset_mic_outlined, 'تواصل'),
                  ],
                ),
              ),
            ),
          ),
        );
          },
        );
      },
    );
  }

  Widget _action(IconData icon, VoidCallback tap) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Material(
        color: Colors.white,
        shape: const CircleBorder(),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: tap,
          child: SizedBox(
            width: 40,
            height: 40,
            child: Icon(icon, color: astroNavy, size: 21),
          ),
        ),
      ),
    );
  }

  Widget _categoryChip(
    String label,
    bool selected,
    VoidCallback onTap,
  ) {
    return Padding(
      padding: const EdgeInsetsDirectional.only(end: 8),
      child: Material(
        color: selected ? astroNavy : Colors.white,
        borderRadius: BorderRadius.circular(22),
        child: InkWell(
          borderRadius: BorderRadius.circular(22),
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 17, vertical: 9),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              border: Border.all(
                color: selected ? astroNavy : const Color(0xFFE1E8F0),
              ),
            ),
            child: Text(
              label,
              style: TextStyle(
                color: selected ? Colors.white : astroNavy,
                fontSize: 12,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _subcategoryChip(
    String label,
    bool selected,
    VoidCallback onTap,
  ) {
    return Padding(
      padding: const EdgeInsetsDirectional.only(end: 7),
      child: Material(
        color: selected ? const Color(0xFFDCEEFF) : Colors.white,
        borderRadius: BorderRadius.circular(18),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                color: selected ? astroBlue : const Color(0xFFE5EBF2),
              ),
            ),
            child: Text(
              label,
              style: TextStyle(
                color: selected ? astroBlue : astroNavy,
                fontSize: 11,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _offerProductCard(Product product, double salePrice, String label) {
    final discount = product.price > 0
        ? (((product.price - salePrice) / product.price) * 100).round()
        : 0;
    return SizedBox(
      width: 248,
      child: Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(17),
        child: InkWell(
          borderRadius: BorderRadius.circular(17),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProductDetailScreen(product: product))),
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(17),
              border: Border.all(color: const Color(0xFFFFD8DD)),
            ),
            padding: const EdgeInsets.all(8),
            child: Row(
              children: [
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: product.imageUrl.isEmpty
                        ? _placeholder(product.category, false)
                        : AstroCachedImage(imageUrl: product.imageUrl, fit: BoxFit.contain,
                            errorWidget: _placeholder(product.category, false)),
                  ),
                ),
                const SizedBox(width: 9),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                        decoration: BoxDecoration(color: const Color(0xFFFFE8EB), borderRadius: BorderRadius.circular(20)),
                        child: Text(label, style: const TextStyle(color: Color(0xFFC6283D), fontSize: 9, fontWeight: FontWeight.w900)),
                      ),
                      const SizedBox(height: 6),
                      Text(product.name, maxLines: 2, overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: astroNavy, fontSize: 11, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 4),
                      Text('${product.price.toStringAsFixed(0)} د.ل',
                        style: const TextStyle(color: Colors.black38, fontSize: 10, decoration: TextDecoration.lineThrough)),
                      Text('${salePrice.toStringAsFixed(0)} د.ل',
                        style: const TextStyle(color: Color(0xFFD92D42), fontSize: 14, fontWeight: FontWeight.w900)),
                      if (discount > 0)
                        Text('وفّر $discount%', style: const TextStyle(color: Color(0xFFD92D42), fontSize: 9, fontWeight: FontWeight.w800)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }


  Widget _homeProductSection({
    required String title,
    required List<Product> products,
    required String badge,
    required VoidCallback onViewAll,
  }) {
    if (products.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(top: 8, bottom: 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 10),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    title,
                    textAlign: TextAlign.right,
                    style: const TextStyle(
                      color: astroNavy,
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
                TextButton(
                  onPressed: onViewAll,
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text('عرض الكل', style: TextStyle(color: astroBlue, fontSize: 11, fontWeight: FontWeight.w800)),
                      Icon(Icons.chevron_left_rounded, color: astroBlue, size: 18),
                    ],
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 258,
            child: ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              scrollDirection: Axis.horizontal,
              itemCount: products.length,
              separatorBuilder: (_, __) => const SizedBox(width: 12),
              itemBuilder: (context, index) => _horizontalProductCard(
                products[index],
                badge: badge,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _horizontalProductCard(Product p, {String? badge}) {
    return SizedBox(
      width: 174,
      child: Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProductDetailScreen(product: p))),
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: const Color(0xFFDCE8F5)),
              boxShadow: [BoxShadow(color: astroNavy.withOpacity(.045), blurRadius: 8, offset: const Offset(0, 3))],
            ),
            padding: const EdgeInsets.all(9),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Stack(
                    children: [
                      Positioned.fill(
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: p.imageUrl.isEmpty
                              ? _placeholder(p.category, false)
                              : AstroCachedImage(imageUrl: p.imageUrl, fit: BoxFit.contain,
                                  errorWidget: _placeholder(p.category, false)),
                        ),
                      ),
                      if (badge != null)
                        Positioned(
                          top: 5,
                          right: 5,
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
                            decoration: BoxDecoration(
                              color: const Color(0xFFE6F4FF),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Text(
                              badge,
                              style: const TextStyle(color: astroNavy, fontSize: 8, fontWeight: FontWeight.w900),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
                const SizedBox(height: 7),
                Text(p.name, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: astroNavy, fontSize: 11, fontWeight: FontWeight.w800)),
                const SizedBox(height: 3),
                Row(
                  children: [
                    Text('${p.price.toStringAsFixed(0)} د.ل', style: const TextStyle(color: astroBlue, fontSize: 13, fontWeight: FontWeight.w900)),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _product(Product p) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(19),
      elevation: 1,
      shadowColor: astroNavy.withOpacity(.07),
      child: InkWell(
        borderRadius: BorderRadius.circular(19),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => ProductDetailScreen(product: p),
            ),
          );
        },
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(19),
            border: Border.all(
              color: const Color(0xFFE0EAF5),
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Stack(
                  children: [
                    ClipRRect(
                      borderRadius: const BorderRadius.vertical(
                        top: Radius.circular(19),
                      ),
                      child: SizedBox(
                        width: double.infinity,
                        child: p.imageUrl.isEmpty
                            ? _placeholder(p.category, false)
                            : AstroCachedImage(
                                imageUrl: p.imageUrl,
                                fit: BoxFit.contain,
                                placeholder: _placeholder(p.category, true),
                                errorWidget: _placeholder(p.category, false),
                              ),
                      ),
                    ),
                    Positioned(
                      top: 9,
                      right: 9,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 9,
                          vertical: 5,
                        ),
                        decoration: BoxDecoration(
                          color: const Color(0xFFE6F4FF),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          p.category,
                          style: const TextStyle(
                            fontSize: 10,
                            color: astroNavy,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(11, 9, 11, 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      p.name,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 13,
                        height: 1.25,
                        fontWeight: FontWeight.w800,
                        color: astroNavy,
                      ),
                    ),
                    const SizedBox(height: 9),
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            '${p.price.toStringAsFixed(0)} د.ل',
                            style: const TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w900,
                              color: astroNavy,
                            ),
                          ),
                        ),
                        Material(
                          color: astroBlue,
                          borderRadius: BorderRadius.circular(10),
                          child: InkWell(
                            borderRadius: BorderRadius.circular(10),
                            onTap: () {
                              if (p.colors.isNotEmpty) {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (_) => ProductDetailScreen(product: p)),
                                );
                              } else {
                                CartService.instance.add(p, null);
                                message('تمت إضافة ${p.name} إلى السلة');
                              }
                            },
                            child: const SizedBox(
                              width: 32,
                              height: 30,
                              child: Icon(Icons.shopping_cart_outlined, color: Colors.white, size: 17),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 7),
                    Row(
                      children: [
                        const Icon(
                          Icons.card_giftcard_rounded,
                          size: 15,
                          color: Color(0xFFD69A22),
                        ),
                        const SizedBox(width: 5),
                        Expanded(
                          child: Text(
                            'نقاط المكافأة: ${p.rewardPoints} نقطة',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w800,
                              color: Color(0xFF8A6416),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _placeholder(String cat, bool loading) {
    return Container(
      color: const Color(0xFFF2F4F7),
      child: Center(
        child: loading
            ? const SizedBox(
                width: 22,
                height: 22,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: astroGold,
                ),
              )
            : Icon(
                cat == 'هواتف'
                    ? Icons.smartphone_rounded
                    : Icons.headphones_rounded,
                size: 55,
                color: astroNavy.withOpacity(.3),
              ),
      ),
    );
  }

  String _categoryAsset(String name) {
    final value = name.trim().toLowerCase();
    if (value.contains('هواتف') || value.contains('هاتف') ||
        value.contains('موبايل') || value.contains('جوال') || value.contains('phone')) {
      return 'assets/category_phones.jpg';
    }
    if (value.contains('كمال') || value.contains('اكسسوار') ||
        value.contains('إكسسوار') || value.contains('سما') ||
        value.contains('aux') || value.contains('وصلا') || value.contains('كفر')) {
      return 'assets/category_accessories.jpg';
    }
    if (value.contains('مستعمل') || value.contains('used')) {
      return 'assets/category_used.jpg';
    }
    if (value.contains('لوح') || value.contains('تابلت') || value.contains('tablet')) {
      return 'assets/category_tablets.jpg';
    }
    if (value.contains('ساع') || value.contains('watch')) {
      return 'assets/category_watches.jpg';
    }
    if (value.contains('شبك') || value.contains('راوتر') || value.contains('router') || value.contains('رينج')) {
      return 'assets/category_network.jpg';
    }
    if (value.contains('عرض') || value.contains('خصم') || value.contains('offer')) {
      return 'assets/category_offers.jpg';
    }
    return 'assets/category_other.jpg';
  }

  IconData _categoryIcon(String name) {
    final value = name.trim().toLowerCase();

    if (value.contains('هواتف') || value.contains('هاتف') ||
        value.contains('موبايل') || value.contains('جوال') ||
        value.contains('phone')) {
      return Icons.smartphone_rounded;
    }
    if (value.contains('كمال') || value.contains('اكسسوار') ||
        value.contains('إكسسوار') || value.contains('سما') ||
        value.contains('headphone')) {
      return Icons.headphones_rounded;
    }
    if (value.contains('مستعمل') || value.contains('used')) {
      return Icons.recycling_rounded;
    }
    if (value.contains('لوح') || value.contains('تابلت') ||
        value.contains('tablet')) {
      return Icons.tablet_android_rounded;
    }
    if (value.contains('ساع') || value.contains('watch')) {
      return Icons.watch_rounded;
    }
    if (value.contains('كمبيوتر') || value.contains('لابتوب') ||
        value.contains('حاسوب') || value.contains('computer')) {
      return Icons.laptop_chromebook_rounded;
    }
    return Icons.widgets_rounded;
  }

  bool _isAccessoriesOrOther(String name) {
    final value = name.trim().toLowerCase();
    return value.contains('كمال') || value.contains('اكسسوار') ||
        value.contains('إكسسوار') || value == 'أخرى' || value == 'اخرى' ||
        value.contains('other');
  }

  bool _isUsedCategory(String name) {
    final value = name.trim().toLowerCase();
    return value.contains('مستعمل') || value.contains('used');
  }

  IconData _subcategoryIcon(String name) {
    final value = name.trim().toLowerCase();
    if (value.contains('شاحن') || value.contains('شحن')) return Icons.charging_station_rounded;
    if (value.contains('باور')) return Icons.battery_charging_full_rounded;
    if (value.contains('رينج')) return Icons.light_rounded;
    if (value.contains('ساع')) return Icons.watch_rounded;
    if (value.contains('سبيكر') || value.contains('راديو')) return Icons.speaker_rounded;
    if (value.contains('سما')) return Icons.headphones_rounded;
    if (value.contains('سيارة') || value.contains('قواعد')) return Icons.directions_car_rounded;
    if (value.contains('كفر') || value.contains('لاصقة')) return Icons.phone_android_rounded;
    if (value.contains('فلاش') || value.contains('otg')) return Icons.usb_rounded;
    if (value.contains('عدسة') || value.contains('كاميرا')) return Icons.camera_alt_rounded;
    if (value.contains('مبرد')) return Icons.ac_unit_rounded;
    if (value.contains('مودم') || value.contains('wifi') || value.contains('واي')) return Icons.router_rounded;
    if (value.contains('وصلة') || value.contains('aux') || value.contains('pd')) return Icons.cable_rounded;
    if (value.contains('mp3')) return Icons.music_note_rounded;
    if (value.contains('بخارة')) return Icons.spa_rounded;
    if (value.contains('بروجكتر')) return Icons.videocam_rounded;
    if (value.contains('حلاقة')) return Icons.electric_bolt_rounded;
    if (value.contains('بيجي') || value.contains('gaming')) return Icons.sports_esports_rounded;
    if (value.contains('أوروبي') || value.contains('محلي')) return Icons.smartphone_rounded;
    if (value.contains('ipad') || value.contains('تابلت') || value.contains('لوحي')) return Icons.tablet_android_rounded;
    return Icons.devices_other_rounded;
  }

  String? _subcategoryPhotoAsset(String name) {
    // Normalize Arabic spacing, diacritics, tatweel and invisible direction marks.
    // This prevents visually identical category names from selecting the wrong photo.
    final value = name.toLowerCase().replaceAll(
      RegExp(r'[\u064B-\u065F\u0670\u0640\u200B-\u200F\u202A-\u202E\u2066-\u2069\s]'),
      '',
    );

    String file;
    final isBluetoothEarbuds =
        (value.contains('سماعات') && !value.contains('خيط')) ||
        value.contains('بلوت') ||
        value.contains('bluetooth');

    if (isBluetoothEarbuds) {
      file = 'bluetooth_earbuds_wireless_v3';
    } else if (value.contains('بخارة') || value.contains('مبخرة')) file = 'incense_electronic';
    else if (value.contains('otg') || value.contains('تحويلة') || value.contains('او تي جي') || value.contains('أو تي جي')) file = 'otg_adapter';
    else if (value.contains('بروجكتر') || value.contains('بروجيكتور')) file = 'projector';
    else if (value.contains('راديو')) file = 'radio';
    else if (value.contains('حلاقة')) file = 'electric_shaver';
    else if (value.contains('بيجي') || value.contains('gaming')) file = 'pubg_gaming_accessories';
    else if (value.contains('باور')) file = 'power_bank';
    else if (value.contains('رينج')) file = 'ring_light';
    else if (value.contains('ساع')) file = 'watches';
    else if (value.contains('سبيكر')) file = 'speakers';
    else if (value.contains('سما') || value.contains('خيط')) file = 'wired_earphones';
    else if (value.contains('سيارة') && (value.contains('شاحن') || value.contains('شواحن'))) file = 'car_charger';
    else if ((value.contains('شاحن') || value.contains('شواحن')) && value.contains('pd')) file = 'pd_wall_charger';
    else if (value.contains('شاحن') || value.contains('شواحن') || value.contains('لقمة')) file = 'chargers';
    else if (value.contains('فلاش') || value.contains('ميموري') || value.contains('ذاكرة')) file = 'flash_memory';
    else if (value.contains('قاعدة') || value.contains('قواعد')) file = 'car_phone_mount';
    else if (value.contains('كفر')) file = 'phone_case';
    else if (value.contains('عدسة')) file = 'camera_lens_protector';
    else if (value.contains('لصقة') || value.contains('حماية')) file = 'screen_protector';
    else if (value.contains('مبرد')) file = 'phone_cooler';
    else if (value.contains('مودم') || value.contains('wifi') || value.contains('واي')) file = 'wifi_router';
    else if (value.contains('aux')) file = 'aux_cable';
    else if (value.contains('mp3')) file = 'radio';
    else if ((value.contains('وصلة') || value.contains('وصلات') || value.contains('وصالات')) && value.contains('pd')) file = 'pd_cables';
    else if (value.contains('وصلة') || value.contains('وصلات') || value.contains('وصل') || value.contains('كابل') || value.contains('وصالات')) file = 'charging_cable';
    else if (value.contains('ipad') || value.contains('تابلت') || value.contains('لوحي')) return 'assets/category_tablets.jpg';
    else if (value.contains('أوروبي') || value.contains('europe')) return 'assets/category_used.jpg';
    else if (value.contains('محلي') || value.contains('ليبي')) return 'assets/category_used.jpg';
    else return null;

    return 'assets/category_subcategories/$file.jpg';
  }

  String? _phoneBrandKey(String name) {
    final value = name.toLowerCase().replaceAll(
      RegExp(r'[\u064B-\u065F\u0670\u0640\u200B-\u200F\u202A-\u202E\u2066-\u2069\s]'),
      '',
    );
    if (value.contains('xiaomi') || value.contains('شاومي')) return 'xiaomi';
    if (value.contains('honor') || value.contains('هونر')) return 'honor';
    if (value.contains('samsung') || value.contains('سامسونج')) return 'samsung';
    if (value.contains('apple') || value.contains('iphone') || value.contains('أبل') || value.contains('ايفون') || value.contains('آيفون')) return 'apple';
    if (value.contains('oppo') || value.contains('اوبو') || value.contains('أوبو')) return 'oppo';
    if (value.contains('tecno') || value.contains('تكنو')) return 'tecno';
    if (value.contains('infinix') || value.contains('انفينيكس') || value.contains('إنفينيكس')) return 'infinix';
    if (value.contains('itel') || value.contains('ايتل') || value.contains('آيتل')) return 'itel';
    if (value.contains('realme') || value.contains('ريلمي')) return 'realme';
    if (value.contains('vivo') || value.contains('فيفو')) return 'vivo';
    if (value.contains('redmi') || value.contains('ريدمي')) return 'redmi';
    if (value.contains('huawei') || value.contains('هواوي')) return 'huawei';
    if (value.contains('motorola') || value.contains('موتورولا')) return 'motorola';
    if (value.contains('nokia') || value.contains('نوكيا')) return 'nokia';
    if (value.contains('oneplus') || value.contains('ون بلس')) return 'oneplus';
    if (value.contains('zte') || value.contains('زد تي اي')) return 'zte';
    if (value.contains('nothing')) return 'nothing';
    return null;
  }

  Widget _phoneBrandLogo(String name) {
    final key = _phoneBrandKey(name);
    if (key == null) {
      final initials = name.trim().isEmpty ? '?' : name.trim().substring(0, 1).toUpperCase();
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 48,
              height: 48,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: const Color(0xFFE8F3FF),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: astroBlue.withOpacity(.22)),
              ),
              child: Text(initials, style: const TextStyle(color: astroBlue, fontSize: 25, fontWeight: FontWeight.w900)),
            ),
            const SizedBox(height: 4),
            Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: astroNavy, fontSize: 12, fontWeight: FontWeight.w900)),
          ],
        ),
      );
    }

    Color color;
    String wordmark;
    String? monogram;
    switch (key) {
      case 'xiaomi': color = const Color(0xFFFF6900); wordmark = 'Xiaomi'; monogram = 'mi'; break;
      case 'honor': color = const Color(0xFF111827); wordmark = 'HONOR'; break;
      case 'samsung': color = const Color(0xFF1428A0); wordmark = 'SAMSUNG'; break;
      case 'apple': color = const Color(0xFF202124); wordmark = 'APPLE'; monogram = '●'; break;
      case 'oppo': color = const Color(0xFF168B58); wordmark = 'oppo'; break;
      case 'tecno': color = const Color(0xFF0066B3); wordmark = 'TECNO'; break;
      case 'infinix': color = const Color(0xFF151515); wordmark = 'Infinix'; break;
      case 'itel': color = const Color(0xFF1685D8); wordmark = 'itel'; break;
      case 'realme': color = const Color(0xFFFFC400); wordmark = 'realme'; break;
      case 'vivo': color = const Color(0xFF1769AA); wordmark = 'vivo'; break;
      case 'redmi': color = const Color(0xFFFF4D36); wordmark = 'Redmi'; break;
      case 'huawei': color = const Color(0xFFC8102E); wordmark = 'HUAWEI'; break;
      case 'motorola': color = const Color(0xFF202124); wordmark = 'motorola'; monogram = 'M'; break;
      case 'nokia': color = const Color(0xFF124191); wordmark = 'NOKIA'; break;
      case 'oneplus': color = const Color(0xFFEB0029); wordmark = 'OnePlus'; monogram = '1+'; break;
      case 'zte': color = const Color(0xFF1769AA); wordmark = 'ZTE'; break;
      default: color = const Color(0xFF202124); wordmark = 'NOTHING'; break;
    }

    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (key == 'xiaomi' || key == 'motorola' || key == 'oneplus')
            Container(
              width: 48,
              height: 48,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: key == 'xiaomi' ? color : Colors.white,
                borderRadius: BorderRadius.circular(key == 'xiaomi' ? 11 : 24),
                border: key == 'xiaomi' ? null : Border.all(color: color, width: 2.5),
              ),
              child: Text(
                monogram ?? '',
                style: TextStyle(
                  color: key == 'xiaomi' ? Colors.white : color,
                  fontSize: key == 'oneplus' ? 21 : 25,
                  fontWeight: FontWeight.w900,
                  height: 1,
                ),
              ),
            )
          else if (key == 'apple')
            Icon(Icons.phone_iphone_rounded, size: 42, color: color)
          else if (key == 'huawei')
            Icon(Icons.local_florist_rounded, size: 43, color: color)
          else if (key == 'samsung')
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
              decoration: BoxDecoration(
                border: Border.all(color: color, width: 2),
                borderRadius: BorderRadius.circular(30),
              ),
              child: Text(wordmark, style: TextStyle(color: color, fontSize: 15, fontWeight: FontWeight.w900, fontStyle: FontStyle.italic)),
            )
          else
            Text(
              wordmark,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: color,
                fontSize: key == 'honor' ? 25 : 27,
                fontWeight: FontWeight.w900,
                letterSpacing: key == 'oppo' ? 1.5 : .2,
                fontStyle: key == 'vivo' ? FontStyle.italic : FontStyle.normal,
              ),
            ),
        ],
      ),
    );
  }

  Widget _subcategoryImageCard({
    required StoreCategory item,
    required List<Product> products,
    required bool selected,
    bool used = false,
    bool phoneBrand = false,
    required VoidCallback onTap,
  }) {
    // Dedicated category photography: never borrow a customer's product image.
    final name = item.name.trim();
    final brandKey = _phoneBrandKey(name);
    final showBrandLogo = brandKey != null || phoneBrand;
    final photoAsset = showBrandLogo ? null : _subcategoryPhotoAsset(name);
    final isEuropean = name.contains('أوروبي') || name.toLowerCase().contains('europe');
    final isLocal = name.contains('محلي') || name.contains('ليبي');

    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Ink(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: selected ? astroBlue : const Color(0xFFE0EAF5),
              width: selected ? 2 : 1,
            ),
            boxShadow: [
              BoxShadow(
                color: astroNavy.withOpacity(.045),
                blurRadius: 9,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          padding: const EdgeInsets.fromLTRB(7, 8, 7, 7),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Expanded(
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    if (item.imageUrl.isNotEmpty)
                      Positioned.fill(
                        child: Padding(
                          padding: const EdgeInsets.all(8),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(12),
                            child: AstroCachedImage(
                              imageUrl: item.imageUrl,
                              fit: BoxFit.contain,
                              errorWidget: showBrandLogo
                                  ? _phoneBrandLogo(name)
                                  : (photoAsset != null
                                      ? Image.asset(photoAsset, fit: BoxFit.contain)
                                      : Icon(_subcategoryIcon(name), color: astroBlue, size: 40)),
                            ),
                          ),
                        ),
                      )
                    else if (showBrandLogo)
                      _phoneBrandLogo(name)
                    else if (photoAsset != null)
                      Positioned.fill(
                        child: Padding(
                          padding: const EdgeInsets.all(8),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(12),
                            child: Image.asset(
                              photoAsset,
                              fit: BoxFit.contain,
                              errorBuilder: (_, __, ___) => Icon(
                                _subcategoryIcon(name),
                                color: astroBlue,
                                size: 38,
                              ),
                            ),
                          ),
                        ),
                      )
                    else
                      Icon(_subcategoryIcon(name), color: astroBlue, size: 40),
                    if (used && (isEuropean || isLocal))
                      Positioned(
                        bottom: 1,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(.94),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            isEuropean ? '🇨🇳 🇪🇺 🇺🇸' : '🇱🇾',
                            style: const TextStyle(fontSize: 12),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 6),
              Text(
                item.name,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: astroNavy,
                  fontSize: 11,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _allSubcategoriesCard({
    required bool selected,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Ink(
          decoration: BoxDecoration(
            color: const Color(0xFFE8F3FF),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: selected ? astroBlue : const Color(0xFFD5E7F8),
              width: selected ? 2 : 1,
            ),
          ),
          padding: const EdgeInsets.all(8),
          child: const Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.grid_view_rounded, color: astroBlue, size: 36),
              SizedBox(height: 7),
              Text('الكل', style: TextStyle(color: astroNavy, fontSize: 12, fontWeight: FontWeight.w900)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _tabletCategoryBanner() {
    return Container(
      height: 132,
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 14),
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: const LinearGradient(
          colors: [Color(0xFF8CCBFF), Color(0xFF07509B), Color(0xFF082B62)],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
      ),
      child: Row(
        children: [
          Expanded(
            flex: 5,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 15),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: const [
                  Text('الأجهزة اللوحية', style: TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w900)),
                  SizedBox(height: 7),
                  Text('تابلت للعمل، الدراسة والترفيه', textAlign: TextAlign.right, style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600)),
                ],
              ),
            ),
          ),
          Expanded(
            flex: 4,
            child: Padding(
              padding: const EdgeInsets.all(6),
              child: Image.asset('assets/category_tablets.jpg', fit: BoxFit.contain),
            ),
          ),
        ],
      ),
    );
  }

  void _showCategoryFilters(List<StoreCategory> subcategories) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      builder: (sheetContext) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          padding: const EdgeInsets.fromLTRB(18, 14, 18, 22),
          children: [
            const Text('تصفية حسب القسم الفرعي', style: TextStyle(color: astroNavy, fontSize: 17, fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('الكل'),
              trailing: categoryPageSubcategoryId == null ? const Icon(Icons.check_circle, color: astroBlue) : null,
              onTap: () {
                Navigator.pop(sheetContext);
                setState(() => categoryPageSubcategoryId = null);
              },
            ),
            ...subcategories.map((item) => ListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(item.name),
              trailing: categoryPageSubcategoryId == item.id ? const Icon(Icons.check_circle, color: astroBlue) : null,
              onTap: () {
                Navigator.pop(sheetContext);
                setState(() => categoryPageSubcategoryId = item.id);
              },
            )),
          ],
        ),
      ),
    );
  }

  Widget _buildCategoriesPage({
    required List<StoreCategory> rootCategories,
    required List<StoreCategory> categories,
    required List<Product> products,
  }) {
    StoreCategory? selectedRoot;
    for (final item in rootCategories) {
      if (item.id == categoryPageRootId) {
        selectedRoot = item;
        break;
      }
    }

    final subcategories = selectedRoot == null
        ? <StoreCategory>[]
        : (categories
            .where((item) =>
                item.parentId == selectedRoot!.id && item.isActive)
            .toList()
          ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder)));

    StoreCategory? selectedSubcategory;
    if (categoryPageSubcategoryId != null) {
      for (final item in subcategories) {
        if (item.id == categoryPageSubcategoryId) {
          selectedSubcategory = item;
          break;
        }
      }
    }

    final visibleProducts = selectedRoot == null
        ? <Product>[]
        : (products.where((product) {
            final matchesRoot = product.category == selectedRoot!.name;
            final matchesSubcategory = categoryPageSubcategoryId == null ||
                product.subcategoryId == categoryPageSubcategoryId;
            return matchesRoot && matchesSubcategory;
          }).toList()
          ..sort((a, b) {
            switch (_categorySort) {
              case 'الأقل سعراً':
                return a.price.compareTo(b.price);
              case 'الأعلى سعراً':
                return b.price.compareTo(a.price);
              case 'الأكثر مبيعاً':
                return b.salesCount.compareTo(a.salesCount);
              default:
                return 0;
            }
          }));

    if (selectedRoot != null && selectedSubcategory != null) {
      return _buildSubcategoryProductsPage(
        title: selectedSubcategory.name,
        products: visibleProducts,
        subcategories: subcategories,
      );
    }

      Widget buildRootCategoryCard(int index) {
                      final item = rootCategories[index];
                      final childCount = categories
                          .where((category) =>
                              category.parentId == item.id && category.isActive)
                          .length;
                      final categoryIcon = _categoryIcon(item.name);
                      final categoryAsset = _categoryAsset(item.name);
                      return Material(
                        color: Colors.transparent,
                        borderRadius: BorderRadius.circular(20),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(20),
                          onTap: () => setState(() {
                            categoryPageRootId = item.id;
                            categoryPageSubcategoryId = null;
                          }),
                          child: Ink(
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                begin: Alignment.topRight,
                                end: Alignment.bottomLeft,
                                colors: [Colors.white, Color(0xFFF0F7FF)],
                              ),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(
                                color: const Color(0xFFDCE9F6),
                                width: 1.1,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: astroNavy.withOpacity(.055),
                                  blurRadius: 13,
                                  offset: const Offset(0, 5),
                                ),
                              ],
                            ),
                            padding: const EdgeInsets.fromLTRB(14, 15, 14, 13),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  width: 76,
                                  height: 76,
                                  padding: const EdgeInsets.all(7),
                                  decoration: BoxDecoration(
                                    gradient: const LinearGradient(
                                      colors: [Color(0xFFEAF4FF), Color(0xFFDCEEFF)],
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                    ),
                                    borderRadius: BorderRadius.circular(19),
                                  ),
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(13),
                                    child: item.imageUrl.isNotEmpty
                                        ? AstroCachedImage(
                                            imageUrl: item.imageUrl,
                                            fit: BoxFit.cover,
                                            errorWidget: Image.asset(
                                              categoryAsset,
                                              fit: BoxFit.cover,
                                              errorBuilder: (_, __, ___) => Icon(categoryIcon, color: astroBlue, size: 34),
                                            ),
                                          )
                                        : Image.asset(
                                            categoryAsset,
                                            fit: BoxFit.cover,
                                            errorBuilder: (_, __, ___) => Icon(categoryIcon, color: astroBlue, size: 34),
                                          ),
                                  ),
                                ),
                                const SizedBox(height: 12),
                                Text(
                                  item.name,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(
                                    color: astroNavy,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 10,
                                    vertical: 4,
                                  ),
                                  decoration: BoxDecoration(
                                    color: Colors.white.withOpacity(.9),
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  child: Text(
                                    childCount == 0
                                        ? 'تصفح المنتجات'
                                        : '$childCount أقسام فرعية',
                                    style: const TextStyle(
                                      color: Color(0xFF6B7F93),
                                      fontSize: 11,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
      }

    return StreamBuilder<CategoryDisplaySettings>(
      stream: ProductRepository.watchCategoryDisplaySettings(),
      builder: (context, settingsSnapshot) {
        final displaySettings =
            settingsSnapshot.data ?? const CategoryDisplaySettings();
        return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 22, 18, 12),
            child: Row(
              children: [
                if (selectedRoot != null)
                  IconButton(
                    tooltip: 'العودة إلى جميع الأقسام',
                    onPressed: () => setState(() {
                      categoryPageRootId = null;
                      categoryPageSubcategoryId = null;
                    }),
                    icon: const Icon(Icons.arrow_forward_rounded,
                        color: astroNavy),
                  ),
                Expanded(
                  child: Text(
                    selectedRoot == null ? 'جميع الأقسام' : selectedRoot.name,
                    style: const TextStyle(
                      color: astroNavy,
                      fontSize: 21,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
                if (selectedRoot != null)
                  TextButton(
                    onPressed: () => setState(() {
                      categoryPageSubcategoryId = null;
                    }),
                    child: const Text('كل المنتجات'),
                  ),
              ],
            ),
          ),
        ),
        if (selectedRoot == null) ...[
          if (displaySettings.mainLayout == 'horizontal')
            SliverToBoxAdapter(
              child: SizedBox(
                height: 174,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                  itemCount: rootCategories.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 12),
                  itemBuilder: (context, index) => SizedBox(
                    width: 154,
                    child: buildRootCategoryCard(index),
                  ),
                ),
              ),
            )
          else
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
              sliver: SliverGrid(
                delegate: SliverChildBuilderDelegate(
                  (context, index) => buildRootCategoryCard(index),
                  childCount: rootCategories.length,
                ),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: displaySettings.mainLayout == 'grid_3' ? 3 : 2,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: displaySettings.mainLayout == 'grid_3' ? .88 : 1.12,
                ),
              ),
            ),
          if (products.isNotEmpty) ...[
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(18, 2, 18, 12),
                child: Row(
                  children: [
                    const Expanded(
                      child: Text(
                        'منتجات مختارة',
                        style: TextStyle(color: astroNavy, fontSize: 18, fontWeight: FontWeight.w900),
                      ),
                    ),
                    Text('${products.length} منتج', style: const TextStyle(color: Colors.black45, fontSize: 12)),
                  ],
                ),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              sliver: SliverGrid(
                delegate: SliverChildBuilderDelegate(
                  (context, index) => _product(products[index]),
                  childCount: products.length > 4 ? 4 : products.length,
                ),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 14,
                  crossAxisSpacing: 14,
                  childAspectRatio: .72,
                ),
              ),
            ),
          ],
        ] else ...[
          if (selectedRoot != null &&
              (selectedRoot.name.contains('لوحي') || selectedRoot.name.contains('تابلت'))) ...[
            SliverToBoxAdapter(child: _tabletCategoryBanner()),
          ],
          if (subcategories.isNotEmpty) ...[
            if (displaySettings.subcategoryLayout == 'horizontal')
              SliverToBoxAdapter(
                child: SizedBox(
                  height: _isUsedCategory(selectedRoot!.name) ? 148 : 144,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: subcategories.length + 1,
                    separatorBuilder: (_, __) => const SizedBox(width: 10),
                    itemBuilder: (context, index) {
                      if (index == 0) {
                        return SizedBox(
                          width: 112,
                          child: _allSubcategoriesCard(
                            selected: categoryPageSubcategoryId == null,
                            onTap: () => setState(() => categoryPageSubcategoryId = null),
                          ),
                        );
                      }
                      final item = subcategories[index - 1];
                      return SizedBox(
                        width: _isUsedCategory(selectedRoot!.name) ? 150 : 120,
                        child: _subcategoryImageCard(
                          item: item,
                          products: products,
                          selected: categoryPageSubcategoryId == item.id,
                          used: _isUsedCategory(selectedRoot.name),
                          phoneBrand: selectedRoot.name.contains('هواتف') ||
                              selectedRoot.name.contains('هاتف') ||
                              selectedRoot.name.contains('موبايل') ||
                              selectedRoot.name.contains('جوال') ||
                              selectedRoot.name.toLowerCase().contains('phone'),
                          onTap: () => setState(() => categoryPageSubcategoryId = item.id),
                        ),
                      );
                    },
                  ),
                ),
              )
            else
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
                sliver: SliverGrid(
                  delegate: SliverChildBuilderDelegate(
                    (context, index) {
                      if (index == 0) {
                        return _allSubcategoriesCard(
                          selected: categoryPageSubcategoryId == null,
                          onTap: () => setState(() => categoryPageSubcategoryId = null),
                        );
                      }
                      final item = subcategories[index - 1];
                      return _subcategoryImageCard(
                        item: item,
                        products: products,
                        selected: categoryPageSubcategoryId == item.id,
                        used: _isUsedCategory(selectedRoot!.name),
                        phoneBrand: selectedRoot.name.contains('هواتف') ||
                            selectedRoot.name.contains('هاتف') ||
                            selectedRoot.name.contains('موبايل') ||
                            selectedRoot.name.contains('جوال') ||
                            selectedRoot.name.toLowerCase().contains('phone'),
                        onTap: () => setState(() => categoryPageSubcategoryId = item.id),
                      );
                    },
                    childCount: subcategories.length + 1,
                  ),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    mainAxisSpacing: 9,
                    crossAxisSpacing: 9,
                    childAspectRatio: .88,
                  ),
                ),
              ),
          ],
          if (selectedRoot != null)
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 2),
                child: Row(
                  children: [
                    OutlinedButton.icon(
                      onPressed: () => _showCategoryFilters(subcategories),
                      icon: const Icon(Icons.filter_list_rounded, size: 18),
                      label: const Text('تصفية'),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: astroNavy,
                        backgroundColor: Colors.white,
                        side: const BorderSide(color: Color(0xFFE0EAF5)),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      ),
                    ),
                    const Spacer(),
                    PopupMenuButton<String>(
                      initialValue: _categorySort,
                      onSelected: (value) => setState(() => _categorySort = value),
                      itemBuilder: (_) => const [
                        PopupMenuItem(value: 'الأحدث', child: Text('الأحدث')),
                        PopupMenuItem(value: 'الأقل سعراً', child: Text('الأقل سعراً')),
                        PopupMenuItem(value: 'الأعلى سعراً', child: Text('الأعلى سعراً')),
                        PopupMenuItem(value: 'الأكثر مبيعاً', child: Text('الأكثر مبيعاً')),
                      ],
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 10),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: const Color(0xFFE0EAF5)),
                        ),
                        child: Row(
                          children: [
                            Text('الترتيب: $_categorySort', style: const TextStyle(color: astroNavy, fontSize: 12, fontWeight: FontWeight.w700)),
                            const SizedBox(width: 5),
                            const Icon(Icons.keyboard_arrow_down_rounded, color: astroNavy, size: 19),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 12, 18, 10),
              child: Row(
                children: [
                  const Expanded(
                    child: Text(
                      'المنتجات',
                      style: TextStyle(
                        color: astroNavy,
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                  Text(
                    '${visibleProducts.length} منتجات',
                    style: const TextStyle(
                        color: Colors.black45, fontSize: 12),
                  ),
                ],
              ),
            ),
          ),
          if (visibleProducts.isEmpty)
            const SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.all(28),
                child: Center(
                  child: Text(
                    'لا توجد منتجات في هذا القسم حالياً',
                    style: TextStyle(color: Colors.black54),
                  ),
                ),
              ),
            )
          else
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              sliver: SliverGrid(
                delegate: SliverChildBuilderDelegate(
                  (context, index) => _product(visibleProducts[index]),
                  childCount: visibleProducts.length,
                ),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 14,
                  crossAxisSpacing: 14,
                  childAspectRatio: .72,
                ),
              ),
            ),
        ],
      ],
        );
      },
    );
  }


  Widget _buildSubcategoryProductsPage({
    required String title,
    required List<Product> products,
    required List<StoreCategory> subcategories,
  }) {
    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 18, 16, 12),
            child: Row(
              children: [
                IconButton(
                  tooltip: 'العودة إلى الأقسام الفرعية',
                  onPressed: () => setState(() {
                    categoryPageSubcategoryId = null;
                  }),
                  icon: const Icon(Icons.arrow_forward_rounded, color: astroNavy),
                ),
                Expanded(
                  child: Text(
                    title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: astroNavy,
                      fontSize: 21,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
                Text(
                  '${products.length} منتج',
                  style: const TextStyle(color: Colors.black45, fontSize: 12),
                ),
              ],
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
            child: Row(
              children: [
                OutlinedButton.icon(
                  onPressed: () => _showCategoryFilters(subcategories),
                  icon: const Icon(Icons.filter_list_rounded, size: 18),
                  label: const Text('تغيير القسم'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: astroNavy,
                    backgroundColor: Colors.white,
                    side: const BorderSide(color: Color(0xFFE0EAF5)),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                ),
                const Spacer(),
                PopupMenuButton<String>(
                  initialValue: _categorySort,
                  onSelected: (value) => setState(() => _categorySort = value),
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: 'الأحدث', child: Text('الأحدث')),
                    PopupMenuItem(value: 'الأقل سعراً', child: Text('الأقل سعراً')),
                    PopupMenuItem(value: 'الأعلى سعراً', child: Text('الأعلى سعراً')),
                    PopupMenuItem(value: 'الأكثر مبيعاً', child: Text('الأكثر مبيعاً')),
                  ],
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 10),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: const Color(0xFFE0EAF5)),
                    ),
                    child: Row(
                      children: [
                        Text(
                          'الترتيب: $_categorySort',
                          style: const TextStyle(
                            color: astroNavy,
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(width: 5),
                        const Icon(
                          Icons.keyboard_arrow_down_rounded,
                          color: astroNavy,
                          size: 19,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        if (products.isEmpty)
          const SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.all(28),
              child: Center(
                child: Text(
                  'لا توجد منتجات في هذا القسم حالياً',
                  style: TextStyle(color: Colors.black54),
                ),
              ),
            ),
          )
        else
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
            sliver: SliverGrid(
              delegate: SliverChildBuilderDelegate(
                (context, index) => _product(products[index]),
                childCount: products.length,
              ),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 14,
                crossAxisSpacing: 14,
                childAspectRatio: .72,
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildStorePage(List<Product> products) {
    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 18, 18, 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('المتجر', style: TextStyle(color: astroNavy, fontSize: 22, fontWeight: FontWeight.w900)),
                const SizedBox(height: 12),
                TextField(
                  controller: storeSearch,
                  onChanged: (_) => setState(() {}),
                  textInputAction: TextInputAction.search,
                  decoration: InputDecoration(
                    hintText: 'ابحث عن منتج أو قسم أو علامة تجارية...',
                    prefixIcon: const Icon(Icons.search, color: astroBlue),
                    suffixIcon: storeSearch.text.isEmpty ? null : IconButton(
                      icon: const Icon(Icons.close),
                      onPressed: () { storeSearch.clear(); setState(() {}); },
                    ),
                    filled: true, fillColor: Colors.white,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
                  ),
                ),
              ],
            ),
          ),
        ),
        if (products.isEmpty)
          const SliverToBoxAdapter(child: Padding(padding: EdgeInsets.all(30), child: Center(child: Text('لا توجد منتجات مطابقة'))))
        else
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
            sliver: SliverGrid(
              delegate: SliverChildBuilderDelegate((context, index) => _product(products[index]), childCount: products.length),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 14, crossAxisSpacing: 14, childAspectRatio: .66),
            ),
          ),
      ],
    );
  }

  Widget _buildHomeSectionProductsPage(String title, List<Product> products) {
    // This page is rendered without the main AppBar, so keep its header below
    // the Android status bar and separate the back control from long Arabic titles.
    return SafeArea(
      top: true,
      bottom: false,
      child: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsetsDirectional.fromSTEB(12, 8, 16, 14),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(
                    width: 44,
                    height: 44,
                    child: IconButton(
                      padding: EdgeInsets.zero,
                      tooltip: 'رجوع',
                      onPressed: () => setState(() {
                        _activeHomeSectionTitle = null;
                        _activeHomeSectionProducts = null;
                      }),
                      icon: const Icon(Icons.arrow_forward_rounded, color: astroNavy),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      title,
                      textAlign: TextAlign.right,
                      maxLines: 2,
                      softWrap: true,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: astroNavy,
                        fontSize: 20,
                        height: 1.25,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        if (products.isEmpty)
          const SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.all(30),
              child: Center(child: Text('لا توجد منتجات في هذا القسم حالياً')),
            ),
          )
        else
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
            sliver: SliverGrid(
              delegate: SliverChildBuilderDelegate(
                (context, index) => _product(products[index]),
                childCount: products.length,
              ),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 14,
                crossAxisSpacing: 14,
                childAspectRatio: .66,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _managedHomeSections(List<Product> sourceProducts) {
    return StreamBuilder<List<Map<String, dynamic>>>(
      stream: Supabase.instance.client
          .from('home_page_sections')
          .stream(primaryKey: ['section_key']),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const SizedBox.shrink();
        final rows = [...snapshot.data!]
          ..sort((a, b) => (a['sort_order'] as num? ?? 0)
              .compareTo(b['sort_order'] as num? ?? 0));
        final sections = <Widget>[];
        for (final row in rows) {
          if (row['is_enabled'] == false) continue;
          final rawIds = row['product_ids'];
          if (rawIds is! List || rawIds.isEmpty) continue;
          // Preserve the exact product order selected by the administrator.
          final ids = rawIds.map((value) => value.toString()).toList();
          final productsById = <String, Product>{
            for (final product in sourceProducts) product.id: product,
          };
          final selected = ids
              .map((id) => productsById[id])
              .whereType<Product>()
              .toList();
          if (selected.isEmpty) continue;
          final key = '${row['section_key'] ?? ''}';
          final badge = switch (key) {
            'best_selling' => 'الأكثر طلباً',
            'used' => 'مستعمل',
            'accessories' => 'كماليات',
            'budget' => 'سعر مناسب',
            _ => 'اختيارات ASTRO',
          };
          sections.add(_homeProductSection(
            title: '${row['title'] ?? 'منتجات مختارة'}',
            products: selected,
            badge: badge,
            onViewAll: () {
              setState(() {
                _activeHomeSectionTitle = '${row['title'] ?? 'منتجات مختارة'}';
                _activeHomeSectionProducts = List<Product>.unmodifiable(selected);
              });
            },
          ));
        }
        if (sections.isEmpty) return const SizedBox.shrink();
        return Column(children: sections);
      },
    );
  }

  Widget _navItem(int i, IconData icon, String label) {
    final active = nav == i;

    return Expanded(
      child: InkWell(
        onTap: () {
          setState(() {
            _activeHomeSectionTitle = null;
            _activeHomeSectionProducts = null;
            nav = i;
            if (i == 1) {
              categoryPageRootId = null;
              categoryPageSubcategoryId = null;
            }
          });
        },
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              width: active ? 38 : 32,
              height: active ? 30 : 27,
              decoration: BoxDecoration(
                color: active ? astroBlue : Colors.transparent,
                borderRadius: BorderRadius.circular(18),
              ),
              child: Icon(
                icon,
                color: active ? Colors.white : const Color(0xFF53657A),
                size: active ? 19 : 21,
              ),
            ),
            const SizedBox(height: 3),
            Text(
              label,
              style: TextStyle(
                fontSize: 10,
                color: active ? astroBlue : const Color(0xFF53657A),
                fontWeight: active ? FontWeight.w900 : FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

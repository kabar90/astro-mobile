import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/product.dart';

class StoreCategory {
  final int id;
  final String name;
  final int? parentId;
  final int sortOrder;
  final bool isActive;
  final String imageUrl;

  const StoreCategory({
    required this.id,
    required this.name,
    required this.parentId,
    required this.sortOrder,
    required this.isActive,
    this.imageUrl = '',
  });

  factory StoreCategory.fromMap(Map<String, dynamic> row) {
    int? asInt(dynamic value) {
      if (value is int) return value;
      return int.tryParse('${value ?? ''}');
    }

    return StoreCategory(
      id: asInt(row['id']) ?? 0,
      name: (row['name'] ?? '').toString(),
      parentId: asInt(row['parent_id']),
      sortOrder: asInt(row['sort_order']) ?? 0,
      isActive: row['is_active'] is bool ? row['is_active'] as bool : true,
      imageUrl: (row['image_url'] ?? '').toString().trim(),
    );
  }
}


class CategoryDisplaySettings {
  final String mainLayout;
  final String subcategoryLayout;

  const CategoryDisplaySettings({
    this.mainLayout = 'grid_2',
    this.subcategoryLayout = 'grid',
  });

  factory CategoryDisplaySettings.fromMap(Map<String, dynamic> row) {
    final main = (row['main_layout'] ?? 'grid_2').toString();
    final sub = (row['subcategory_layout'] ?? 'grid').toString();
    return CategoryDisplaySettings(
      mainLayout: const ['grid_2', 'grid_3', 'horizontal'].contains(main)
          ? main
          : 'grid_2',
      subcategoryLayout: const ['grid', 'horizontal'].contains(sub)
          ? sub
          : 'grid',
    );
  }
}

class ProductRepository {
  ProductRepository._();

  static final SupabaseClient _db = Supabase.instance.client;
  static const String _productsCacheKey = 'astro_products_cache_v1';
  static const String _categoriesCacheKey = 'astro_categories_cache_v1';

  // Cached public catalogue data is shown immediately, then refreshed from Supabase.
  static Future<List<Product>?> _readCachedProducts() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_productsCacheKey);
      if (raw == null || raw.isEmpty) return null;
      final decoded = jsonDecode(raw);
      if (decoded is! List) return null;
      return decoded
          .whereType<Map>()
          .map((row) => Product.fromMap(
                (row['id'] ?? '').toString(),
                Map<String, dynamic>.from(row),
              ))
          .where((product) => product.id.isNotEmpty && product.name.isNotEmpty)
          .toList();
    } catch (_) {
      return null;
    }
  }

  static Future<void> _saveCachedProducts(List<Product> products) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final rows = products.map((product) => <String, dynamic>{
        'id': product.id,
        'name': product.name,
        'category': product.category,
        'subcategory_id': product.subcategoryId,
        'price': product.price,
        'image_url': product.imageUrl,
        'images': product.images,
        'description': product.description,
        'is_active': product.isActive,
        'colors': product.colors,
        'brand': product.brand,
        'rating': product.rating,
        'review_count': product.reviewCount,
        'stock_quantity': product.stockQuantity,
        'is_new': product.isNew,
        'reward_points': product.rewardPoints,
        'sales_count': product.salesCount,
        'allow_points_payment': product.allowPointsPayment,
        'specifications': product.specifications,
      }).toList();
      await prefs.setString(_productsCacheKey, jsonEncode(rows));
    } catch (_) {
      // Cache failures must never prevent the live catalogue from loading.
    }
  }

  static Future<List<StoreCategory>?> _readCachedCategories() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_categoriesCacheKey);
      if (raw == null || raw.isEmpty) return null;
      final decoded = jsonDecode(raw);
      if (decoded is! List) return null;
      return decoded
          .whereType<Map>()
          .map((row) => StoreCategory.fromMap(Map<String, dynamic>.from(row)))
          .where((category) => category.id > 0 && category.name.isNotEmpty)
          .toList()
        ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder));
    } catch (_) {
      return null;
    }
  }

  static Future<void> _saveCachedCategories(List<StoreCategory> categories) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final rows = categories.map((category) => <String, dynamic>{
        'id': category.id,
        'name': category.name,
        'parent_id': category.parentId,
        'sort_order': category.sortOrder,
        'is_active': category.isActive,
        'image_url': category.imageUrl,
      }).toList();
      await prefs.setString(_categoriesCacheKey, jsonEncode(rows));
    } catch (_) {
      // Cache failures must never prevent live categories from loading.
    }
  }

  static Stream<CategoryDisplaySettings> watchCategoryDisplaySettings() {
    return _db
        .from('category_display_settings')
        .stream(primaryKey: ['id'])
        .eq('id', 1)
        .map((rows) => rows.isEmpty
            ? const CategoryDisplaySettings()
            : CategoryDisplaySettings.fromMap(rows.first));
  }

  static Stream<List<StoreCategory>> watchCategories() async* {
    final cached = await _readCachedCategories();
    if (cached != null) yield cached;

    yield* _db
        .from('categories')
        .stream(primaryKey: ['id'])
        .asyncMap((rows) async {
          final categories = rows
              .map(StoreCategory.fromMap)
              .where((category) => category.id > 0 && category.name.isNotEmpty)
              .toList()
            ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder));
          await _saveCachedCategories(categories);
          return categories;
        });
  }

  static List<Product> _productsFromRows(List<Map<String, dynamic>> rows) {
    return rows
        .map((row) => Product.fromMap(row['id'].toString(), row))
        .where((product) => product.name.isNotEmpty)
        .toList();
  }

  static Stream<List<Product>> watchProducts() async* {
    // 1) Show the last successful catalogue immediately, including offline.
    final cached = await _readCachedProducts();
    if (cached != null) yield cached;

    // 2) Make a normal REST request first so the latest catalogue is fetched
    //    directly before listening for realtime changes.
    try {
      final response = await _db
          .from('products')
          .select()
          .eq('is_active', true);
      final fresh = _productsFromRows(
        List<Map<String, dynamic>>.from(response),
      );
      await _saveCachedProducts(fresh);
      yield fresh;
    } catch (_) {
      // A temporary REST failure must not erase or replace the cached list.
      // Continue to the realtime subscription; the UI keeps the last data.
      if (cached == null) rethrow;
    }

    // 3) Subscribe to realtime changes and persist only successful snapshots.
    yield* _db
        .from('products')
        .stream(primaryKey: ['id'])
        .eq('is_active', true)
        .asyncMap((rows) async {
          final products = _productsFromRows(rows);
          await _saveCachedProducts(products);
          return products;
        });
  }
}

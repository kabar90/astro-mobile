import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

/// تحميل موحد لصور المتجر مع تخزين مؤقت على القرص وإعادة استخدام الذاكرة.
class AstroCachedImage extends StatelessWidget {
  const AstroCachedImage({
    super.key,
    required this.imageUrl,
    this.fit = BoxFit.contain,
    this.placeholder,
    this.errorWidget,
  });

  final String imageUrl;
  final BoxFit fit;
  final Widget? placeholder;
  final Widget? errorWidget;

  @override
  Widget build(BuildContext context) {
    final uri = Uri.tryParse(imageUrl.trim());
    if (uri == null || !uri.hasScheme || imageUrl.trim().isEmpty) {
      return errorWidget ?? const Icon(Icons.image_not_supported_outlined, color: Colors.black26);
    }
    return CachedNetworkImage(
      imageUrl: imageUrl.trim(),
      fit: fit,
      memCacheWidth: 900,
      maxWidthDiskCache: 1200,
      fadeInDuration: const Duration(milliseconds: 120),
      placeholder: (context, url) => placeholder ?? const Center(
        child: SizedBox(width: 22, height: 22,
          child: CircularProgressIndicator(strokeWidth: 2)),
      ),
      errorWidget: (context, url, error) => errorWidget ?? const Icon(
        Icons.image_not_supported_outlined, color: Colors.black26,
      ),
    );
  }
}

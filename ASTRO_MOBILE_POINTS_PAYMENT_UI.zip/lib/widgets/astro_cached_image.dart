import 'package:flutter/material.dart';

/// Temporary reliable network image loader.
/// Keeps product-data caching separate while bypassing the disk image cache
/// to verify that the original Supabase image URLs are still reachable.
class AstroCachedImage extends StatelessWidget {
  const AstroCachedImage({
    super.key,
    required this.imageUrl,
    this.fit = BoxFit.contain,
    this.placeholder,
    this.errorWidget,
  });

  final String imageUrl;
  final BoxFit fit;
  final Widget? placeholder;
  final Widget? errorWidget;

  @override
  Widget build(BuildContext context) {
    final url = imageUrl.trim();
    final uri = Uri.tryParse(url);
    if (uri == null ||
        (uri.scheme != 'https' && uri.scheme != 'http') ||
        uri.host.isEmpty) {
      return errorWidget ?? const Icon(
        Icons.image_not_supported_outlined,
        color: Colors.black26,
      );
    }

    return Image.network(
      url,
      fit: fit,
      width: double.infinity,
      height: double.infinity,
      cacheWidth: 1200,
      gaplessPlayback: true,
      loadingBuilder: (context, child, progress) {
        if (progress == null) return child;
        return placeholder ?? const Center(
          child: SizedBox(
            width: 22,
            height: 22,
            child: CircularProgressIndicator(strokeWidth: 2),
          ),
        );
      },
      errorBuilder: (context, error, stackTrace) => errorWidget ?? const Icon(
        Icons.image_not_supported_outlined,
        color: Colors.black26,
      ),
    );
  }
}

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

/// Product image loader with memory + disk caching.
/// A versioned cache key avoids reusing stale/broken entries from the earlier
/// experimental loader while keeping each original image URL as its source.
class AstroCachedImage extends StatelessWidget {
  const AstroCachedImage({
    super.key,
    required this.imageUrl,
    this.fit = BoxFit.contain,
    this.placeholder,
    this.errorWidget,
  });

  final String imageUrl;
  final BoxFit fit;
  final Widget? placeholder;
  final Widget? errorWidget;

  @override
  Widget build(BuildContext context) {
    final url = imageUrl.trim();
    final uri = Uri.tryParse(url);
    if (uri == null ||
        (uri.scheme != 'https' && uri.scheme != 'http') ||
        uri.host.isEmpty) {
      return errorWidget ?? const Icon(
        Icons.image_not_supported_outlined,
        color: Colors.black26,
      );
    }

    return CachedNetworkImage(
      imageUrl: url,
      // New namespace bypasses any stale/corrupt entries from the old test.
      cacheKey: 'astro-mobile-image-v2:$url',
      fit: fit,
      width: double.infinity,
      height: double.infinity,
      memCacheWidth: 900,
      maxWidthDiskCache: 1200,
      useOldImageOnUrlChange: true,
      fadeInDuration: const Duration(milliseconds: 120),
      placeholder: (context, imageUrl) => placeholder ?? const Center(
        child: SizedBox(
          width: 22,
          height: 22,
          child: CircularProgressIndicator(strokeWidth: 2),
        ),
      ),
      errorWidget: (context, imageUrl, error) => errorWidget ?? const Icon(
        Icons.image_not_supported_outlined,
        color: Colors.black26,
      ),
    );
  }
}

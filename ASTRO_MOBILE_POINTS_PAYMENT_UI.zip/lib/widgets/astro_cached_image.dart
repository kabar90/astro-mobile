import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';

/// Durable image cache that never blocks the known-working network renderer.
///
/// Cache hit: display the saved file immediately.
/// Cache miss: display Image.network immediately and warm the durable cache
/// in the background. A cache failure never prevents the network image.
class AstroCachedImage extends StatefulWidget {
  const AstroCachedImage({
    super.key,
    required this.imageUrl,
    this.fit = BoxFit.contain,
    this.placeholder,
    this.errorWidget,
  });

  final String imageUrl;
  final BoxFit fit;
  final Widget? placeholder;
  final Widget? errorWidget;

  @override
  State<AstroCachedImage> createState() => _AstroCachedImageState();
}

class _AstroCachedImageState extends State<AstroCachedImage> {
  static const Duration _timeout = Duration(seconds: 35);
  static const int _maxCacheFiles = 500;

  static Directory? _cacheDirectory;
  static Future<Directory>? _cacheDirectoryFuture;
  static final Map<String, Future<File?>> _inFlight = {};

  File? _cachedFile;
  late String _url;
  int _requestId = 0;
  bool _cacheLookupFinished = false;

  @override
  void initState() {
    super.initState();
    _url = widget.imageUrl.trim();
    _prepareImage();
  }

  @override
  void didUpdateWidget(covariant AstroCachedImage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.imageUrl.trim() != widget.imageUrl.trim()) {
      _url = widget.imageUrl.trim();
      _cachedFile = null;
      _cacheLookupFinished = false;
      _prepareImage();
    }
  }

  static Future<Directory> _getCacheDirectory() {
    if (_cacheDirectory != null) {
      return Future.value(_cacheDirectory!);
    }
    return _cacheDirectoryFuture ??= () async {
      final support = await getApplicationSupportDirectory();
      final directory = Directory(
        '${support.path}${Platform.pathSeparator}astro_product_images_v1',
      );
      await directory.create(recursive: true);
      _cacheDirectory = directory;
      return directory;
    }();
  }

  static String _stableKey(String value) {
    const int mask = 0xFFFFFFFFFFFFFFFF;
    var hash = 0xCBF29CE484222325;
    // Hash UTF-8 bytes so filenames are deterministic for all URL characters.
    for (final byte in utf8.encode(value)) {
      hash ^= byte;
      hash = (hash * 0x100000001B3) & mask;
    }
    return hash.toRadixString(16).padLeft(16, '0');
  }

  bool _isValidUrl(String value) {
    final uri = Uri.tryParse(value);
    return uri != null &&
        (uri.scheme == 'https' || uri.scheme == 'http') &&
        uri.host.isNotEmpty;
  }

  Future<void> _prepareImage() async {
    final requestId = ++_requestId;
    final url = _url;

    if (!_isValidUrl(url)) {
      if (mounted && requestId == _requestId) {
        setState(() => _cacheLookupFinished = true);
      }
      return;
    }

    // IMPORTANT: on a cache miss the UI must use Image.network immediately.
    // Never wait for a network download before showing the image.
    try {
      final directory = await _getCacheDirectory();
      final key = _stableKey(url);
      final file = File(
        '${directory.path}${Platform.pathSeparator}$key.img',
      );

      if (await file.exists()) {
        final length = await file.length();
        if (length > 0) {
          try {
            await file.setLastModified(DateTime.now());
          } catch (_) {}
          if (!mounted || requestId != _requestId) return;
          setState(() {
            _cachedFile = file;
            _cacheLookupFinished = true;
          });
          return;
        }
        try {
          await file.delete();
        } catch (_) {}
      }

      if (!mounted || requestId != _requestId) return;
      setState(() => _cacheLookupFinished = true);

      // Warm the permanent disk cache in the background. The network image
      // remains visible while this independent operation runs.
      _warmCache(url, file, key, requestId);
    } catch (_) {
      if (!mounted || requestId != _requestId) return;
      setState(() => _cacheLookupFinished = true);
      // The direct Image.network fallback remains active.
    }
  }

  Future<void> _warmCache(
    String url,
    File destination,
    String key,
    int requestId,
  ) async {
    final existing = _inFlight[key];
    if (existing != null) {
      final file = await existing;
      if (file != null && mounted && requestId == _requestId) {
        setState(() => _cachedFile = file);
      }
      return;
    }

    final future = _downloadAndSave(url, destination);
    _inFlight[key] = future;
    File? saved;
    try {
      saved = await future;
    } finally {
      if (identical(_inFlight[key], future)) {
        _inFlight.remove(key);
      }
    }

    if (saved != null && mounted && requestId == _requestId) {
      // Use the local copy after it is fully written. If saving fails,
      // Image.network continues to work without interruption.
      setState(() => _cachedFile = saved);
    }
  }

  Future<File?> _downloadAndSave(String url, File destination) async {
    final client = HttpClient()
      ..connectionTimeout = _timeout
      ..userAgent = 'ASTRO MOBILE';

    final temporary = File('${destination.path}.part');
    try {
      final request = await client
          .getUrl(Uri.parse(url))
          .timeout(_timeout);
      final response = await request.close().timeout(_timeout);

      if (response.statusCode != HttpStatus.ok) {
        await response.drain<void>();
        return null;
      }

      final mimeType = response.headers.contentType?.mimeType;
      if (mimeType != null && !mimeType.startsWith('image/')) {
        await response.drain<void>();
        return null;
      }

      final bytes = await response
          .fold<List<int>>(
            <int>[],
            (buffer, chunk) => buffer..addAll(chunk),
          )
          .timeout(_timeout);

      if (bytes.isEmpty) return null;

      await temporary.writeAsBytes(bytes, flush: true);
      if (await destination.exists()) {
        await destination.delete();
      }
      final saved = await temporary.rename(destination.path);
      _pruneOldFiles(destination.parent);
      return saved;
    } catch (_) {
      try {
        if (await temporary.exists()) await temporary.delete();
      } catch (_) {}
      return null;
    } finally {
      client.close(force: true);
    }
  }

  static Future<void> _pruneOldFiles(Directory directory) async {
    try {
      final files = <File>[];
      await for (final entity in directory.list()) {
        if (entity is File && entity.path.endsWith('.img')) {
          files.add(entity);
        }
      }
      if (files.length <= _maxCacheFiles) return;

      final dated = <({File file, DateTime modified})>[];
      for (final file in files) {
        try {
          dated.add((file: file, modified: await file.lastModified()));
        } catch (_) {}
      }
      dated.sort((a, b) => a.modified.compareTo(b.modified));
      final removeCount = dated.length - _maxCacheFiles;
      for (var i = 0; i < removeCount; i++) {
        try {
          await dated[i].file.delete();
        } catch (_) {}
      }
    } catch (_) {
      // Cache cleanup must never affect image display.
    }
  }

  Widget _placeholder() => widget.placeholder ?? const Center(
        child: SizedBox(
          width: 22,
          height: 22,
          child: CircularProgressIndicator(strokeWidth: 2),
        ),
      );

  Widget _error() => widget.errorWidget ?? const Icon(
        Icons.image_not_supported_outlined,
        color: Colors.black26,
      );

  Widget _networkImage() => Image.network(
        _url,
        fit: widget.fit,
        width: double.infinity,
        height: double.infinity,
        cacheWidth: 1200,
        gaplessPlayback: true,
        loadingBuilder: (context, child, progress) {
          if (progress == null) return child;
          return _placeholder();
        },
        errorBuilder: (context, error, stackTrace) => _error(),
      );

  @override
  Widget build(BuildContext context) {
    if (!_isValidUrl(_url)) return _error();

    final file = _cachedFile;
    if (file != null) {
      return Image.file(
        file,
        fit: widget.fit,
        width: double.infinity,
        height: double.infinity,
        cacheWidth: 1200,
        gaplessPlayback: true,
        errorBuilder: (context, error, stackTrace) => _networkImage(),
      );
    }

    // Cache lookup is allowed to be asynchronous, but network rendering is
    // never held behind the cache lookup/download.
    return _networkImage();
  }
}

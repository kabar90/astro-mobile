import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';

/// Persistent image cache with a direct-network fallback.
///
/// The image URL remains the source of truth. Cache Manager stores successful
/// downloads on disk; if cache lookup/download fails, Image.network is used so
/// a cache problem can never hide an otherwise reachable product image.
class AstroCachedImage extends StatefulWidget {
  const AstroCachedImage({
    super.key,
    required this.imageUrl,
    this.fit = BoxFit.contain,
    this.placeholder,
    this.errorWidget,
  });

  final String imageUrl;
  final BoxFit fit;
  final Widget? placeholder;
  final Widget? errorWidget;

  @override
  State<AstroCachedImage> createState() => _AstroCachedImageState();
}

class _AstroCachedImageState extends State<AstroCachedImage> {
  Stream<FileResponse>? _fileStream;
  String _activeUrl = '';

  @override
  void initState() {
    super.initState();
    _prepareStream();
  }

  @override
  void didUpdateWidget(covariant AstroCachedImage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.imageUrl.trim() != widget.imageUrl.trim()) {
      _prepareStream();
    }
  }

  void _prepareStream() {
    final url = widget.imageUrl.trim();
    _activeUrl = url;
    final uri = Uri.tryParse(url);
    if (uri == null ||
        (uri.scheme != 'https' && uri.scheme != 'http') ||
        uri.host.isEmpty) {
      _fileStream = null;
      return;
    }

    // Use the exact source URL as the stable cache key. Do not rewrite the URL
    // or append cache-busting query parameters to Supabase Storage links.
    _fileStream = DefaultCacheManager().getFileStream(
      url,
      key: url,
      withProgress: true,
    );
  }

  Widget _placeholder() {
    return widget.placeholder ?? const Center(
      child: SizedBox(
        width: 22,
        height: 22,
        child: CircularProgressIndicator(strokeWidth: 2),
      ),
    );
  }

  Widget _error() {
    return widget.errorWidget ?? const Icon(
      Icons.image_not_supported_outlined,
      color: Colors.black26,
    );
  }

  Widget _networkFallback() {
    return Image.network(
      _activeUrl,
      fit: widget.fit,
      width: double.infinity,
      height: double.infinity,
      cacheWidth: 1200,
      gaplessPlayback: true,
      loadingBuilder: (context, child, progress) {
        if (progress == null) return child;
        return _placeholder();
      },
      errorBuilder: (context, error, stackTrace) => _error(),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_fileStream == null) return _error();

    return StreamBuilder<FileResponse>(
      stream: _fileStream,
      builder: (context, snapshot) {
        if (snapshot.hasError) return _networkFallback();

        final response = snapshot.data;
        if (response is FileInfo) {
          return Image.file(
            File(response.file.path),
            fit: widget.fit,
            width: double.infinity,
            height: double.infinity,
            cacheWidth: 1200,
            gaplessPlayback: true,
            errorBuilder: (context, error, stackTrace) => _networkFallback(),
          );
        }

        return _placeholder();
      },
    );
  }
}

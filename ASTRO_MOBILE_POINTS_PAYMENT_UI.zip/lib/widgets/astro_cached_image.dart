import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';

/// Persistent product-image cache.
///
/// A successful first download is written to the app's Application Support
/// directory before it is displayed. This directory survives normal app
/// restarts and app updates (unlike the OS temporary cache directory).
/// Subsequent visits read the saved file first and do not need the network.
class AstroCachedImage extends StatefulWidget {
  const AstroCachedImage({
    super.key,
    required this.imageUrl,
    this.fit = BoxFit.contain,
    this.placeholder,
    this.errorWidget,
  });

  final String imageUrl;
  final BoxFit fit;
  final Widget? placeholder;
  final Widget? errorWidget;

  @override
  State<AstroCachedImage> createState() => _AstroCachedImageState();
}

class _AstroCachedImageState extends State<AstroCachedImage> {
  static const Duration _networkTimeout = Duration(seconds: 45);
  static const int _maxCacheFiles = 500;

  static Directory? _cacheDirectory;
  static Future<Directory>? _cacheDirectoryFuture;
  static final Map<String, Future<File?>> _inFlight = {};

  File? _cachedFile;
  String _url = '';
  int _requestId = 0;
  bool _loading = true;
  bool _useNetworkFallback = false;

  @override
  void initState() {
    super.initState();
    _loadImage();
  }

  @override
  void didUpdateWidget(covariant AstroCachedImage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.imageUrl.trim() != widget.imageUrl.trim()) {
      _loadImage();
    }
  }

  static Future<Directory> _getCacheDirectory() {
    if (_cacheDirectory != null) {
      return Future.value(_cacheDirectory);
    }
    return _cacheDirectoryFuture ??= () async {
      final support = await getApplicationSupportDirectory();
      final directory = Directory(
        '${support.path}${Platform.pathSeparator}astro_product_images_v1',
      );
      await directory.create(recursive: true);
      _cacheDirectory = directory;
      return directory;
    }();
  }

  // Stable FNV-1a 64-bit filename. It is deterministic across app launches
  // and does not depend on Dart's process-randomized String.hashCode.
  static String _stableKey(String value) {
    const int mask = 0xFFFFFFFFFFFFFFFF;
    var hash = 0xCBF29CE484222325;
    for (final byte in value.codeUnits) {
      hash ^= byte;
      hash = (hash * 0x100000001B3) & mask;
    }
    return hash.toRadixString(16).padLeft(16, '0');
  }

  Future<void> _loadImage() async {
    final requestId = ++_requestId;
    _url = widget.imageUrl.trim();
    _cachedFile = null;
    _loading = true;
    _useNetworkFallback = false;

    final uri = Uri.tryParse(_url);
    if (uri == null ||
        (uri.scheme != 'https' && uri.scheme != 'http') ||
        uri.host.isEmpty) {
      if (mounted && requestId == _requestId) {
        setState(() => _loading = false);
      }
      return;
    }

    try {
      final file = await _getOrDownload(_url);
      if (!mounted || requestId != _requestId) return;

      if (file != null && await file.exists() && await file.length() > 0) {
        // Update access time so old, unused files can be pruned safely.
        try {
          await file.setLastModified(DateTime.now());
        } catch (_) {}
        if (!mounted || requestId != _requestId) return;
        setState(() {
          _cachedFile = file;
          _loading = false;
        });
      } else {
        setState(() {
          _useNetworkFallback = true;
          _loading = false;
        });
      }
    } catch (_) {
      if (!mounted || requestId != _requestId) return;
      setState(() {
        _useNetworkFallback = true;
        _loading = false;
      });
    }
  }

  Future<File?> _getOrDownload(String url) async {
    final directory = await _getCacheDirectory();
    final key = _stableKey(url);
    final file = File(
      '${directory.path}${Platform.pathSeparator}$key.img',
    );

    if (await file.exists()) {
      try {
        if (await file.length() > 0) return file;
      } catch (_) {}
      try {
        await file.delete();
      } catch (_) {}
    }

    // Multiple product cards may use the same URL; share one download.
    final existing = _inFlight[key];
    if (existing != null) return existing;

    final future = _downloadAndSave(url, file, key);
    _inFlight[key] = future;
    try {
      return await future;
    } finally {
      if (identical(_inFlight[key], future)) {
        _inFlight.remove(key);
      }
    }
  }

  Future<File?> _downloadAndSave(
    String url,
    File destination,
    String key,
  ) async {
    final client = HttpClient()
      ..connectionTimeout = _networkTimeout
      ..userAgent = 'ASTRO MOBILE';

    final temporary = File('${destination.path}.part');
    try {
      final request = await client
          .getUrl(Uri.parse(url))
          .timeout(_networkTimeout);
      final response = await request.close().timeout(_networkTimeout);

      if (response.statusCode != HttpStatus.ok) {
        await response.drain<void>();
        return null;
      }

      final mimeType = response.headers.contentType?.mimeType;
      if (mimeType != null && !mimeType.startsWith('image/')) {
        await response.drain<void>();
        return null;
      }

      final bytes = await response
          .fold<List<int>>(
            <int>[],
            (buffer, chunk) => buffer..addAll(chunk),
          )
          .timeout(_networkTimeout);

      if (bytes.isEmpty) return null;

      await temporary.writeAsBytes(bytes, flush: true);
      if (await destination.exists()) {
        await destination.delete();
      }
      final saved = await temporary.rename(destination.path);
      // Prune in the background; never block showing this image.
      _pruneOldFiles(destination.parent);
      return saved;
    } catch (_) {
      try {
        if (await temporary.exists()) await temporary.delete();
      } catch (_) {}
      return null;
    } finally {
      client.close(force: true);
    }
  }

  static Future<void> _pruneOldFiles(Directory directory) async {
    try {
      final files = <File>[];
      await for (final entity in directory.list()) {
        if (entity is File && entity.path.endsWith('.img')) {
          files.add(entity);
        }
      }
      if (files.length <= _maxCacheFiles) return;

      final dated = <({File file, DateTime modified})>[];
      for (final file in files) {
        try {
          dated.add((file: file, modified: await file.lastModified()));
        } catch (_) {}
      }
      dated.sort((a, b) => a.modified.compareTo(b.modified));
      final removeCount = dated.length - _maxCacheFiles;
      for (var i = 0; i < removeCount; i++) {
        try {
          await dated[i].file.delete();
        } catch (_) {}
      }
    } catch (_) {
      // Cache cleanup must never affect image display.
    }
  }

  Widget _placeholder() => widget.placeholder ?? const Center(
        child: SizedBox(
          width: 22,
          height: 22,
          child: CircularProgressIndicator(strokeWidth: 2),
        ),
      );

  Widget _error() => widget.errorWidget ?? const Icon(
        Icons.image_not_supported_outlined,
        color: Colors.black26,
      );

  Widget _networkImage() => Image.network(
        _url,
        fit: widget.fit,
        width: double.infinity,
        height: double.infinity,
        cacheWidth: 1200,
        gaplessPlayback: true,
        loadingBuilder: (context, child, progress) {
          if (progress == null) return child;
          return _placeholder();
        },
        errorBuilder: (context, error, stackTrace) => _error(),
      );

  @override
  Widget build(BuildContext context) {
    if (_loading) return _placeholder();

    final file = _cachedFile;
    if (file != null) {
      return Image.file(
        file,
        fit: widget.fit,
        width: double.infinity,
        height: double.infinity,
        cacheWidth: 1200,
        gaplessPlayback: true,
        errorBuilder: (context, error, stackTrace) => _networkImage(),
      );
    }

    if (_useNetworkFallback) return _networkImage();
    return _error();
  }
}

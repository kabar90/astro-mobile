import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';

/// Shows the image through Flutter's verified network loader on a cache miss,
/// while warming a separate disk cache for the next visit.
/// A cache lookup/download can never block the first network display.
class AstroCachedImage extends StatefulWidget {
  const AstroCachedImage({
    super.key,
    required this.imageUrl,
    this.fit = BoxFit.contain,
    this.placeholder,
    this.errorWidget,
  });

  final String imageUrl;
  final BoxFit fit;
  final Widget? placeholder;
  final Widget? errorWidget;

  @override
  State<AstroCachedImage> createState() => _AstroCachedImageState();
}

class _AstroCachedImageState extends State<AstroCachedImage> {
  static final CacheManager _cacheManager = CacheManager(
    Config(
      'astro_mobile_product_images_v4',
      stalePeriod: const Duration(days: 30),
      maxNrOfCacheObjects: 500,
    ),
  );

  File? _cachedFile;
  String _url = '';
  int _requestId = 0;

  @override
  void initState() {
    super.initState();
    _startForUrl();
  }

  @override
  void didUpdateWidget(covariant AstroCachedImage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.imageUrl.trim() != widget.imageUrl.trim()) {
      _startForUrl();
    }
  }

  void _startForUrl() {
    _url = widget.imageUrl.trim();
    _cachedFile = null;
    final requestId = ++_requestId;
    final uri = Uri.tryParse(_url);
    if (uri == null ||
        (uri.scheme != 'https' && uri.scheme != 'http') ||
        uri.host.isEmpty) {
      return;
    }
    _loadDiskCache(requestId, _url);
  }

  Future<void> _loadDiskCache(int requestId, String url) async {
    try {
      // This is a local-cache-only lookup; it does not wait for a download.
      final cached = await _cacheManager.getFileFromCache(url);
      if (!mounted || requestId != _requestId) return;
      if (cached != null && await cached.file.exists()) {
        setState(() => _cachedFile = cached.file);
        return;
      }
    } catch (_) {
      // A cache read failure must not prevent the direct network image.
    }

    // Warm disk cache in the background. The UI continues using Image.network
    // immediately, so a slow cache manager cannot leave a permanent spinner.
    try {
      final downloaded = await _cacheManager
          .downloadFile(url, key: url)
          .timeout(const Duration(seconds: 25));
      if (!mounted || requestId != _requestId) return;
      if (await downloaded.file.exists()) {
        setState(() => _cachedFile = downloaded.file);
      }
    } catch (_) {
      // Keep the direct network loader visible; it owns its own error state.
    }
  }

  Widget _placeholder() => widget.placeholder ?? const Center(
        child: SizedBox(
          width: 22,
          height: 22,
          child: CircularProgressIndicator(strokeWidth: 2),
        ),
      );

  Widget _error() => widget.errorWidget ?? const Icon(
        Icons.image_not_supported_outlined,
        color: Colors.black26,
      );

  @override
  Widget build(BuildContext context) {
    final uri = Uri.tryParse(_url);
    if (uri == null ||
        (uri.scheme != 'https' && uri.scheme != 'http') ||
        uri.host.isEmpty) {
      return _error();
    }

    final cached = _cachedFile;
    if (cached != null) {
      return Image.file(
        cached,
        fit: widget.fit,
        width: double.infinity,
        height: double.infinity,
        cacheWidth: 1200,
        gaplessPlayback: true,
        errorBuilder: (context, error, stackTrace) => _networkImage(),
      );
    }

    // Crucial: first-time display uses the known-working Image.network path.
    return _networkImage();
  }

  Widget _networkImage() => Image.network(
        _url,
        fit: widget.fit,
        width: double.infinity,
        height: double.infinity,
        cacheWidth: 1200,
        gaplessPlayback: true,
        loadingBuilder: (context, child, progress) {
          if (progress == null) return child;
          return _placeholder();
        },
        errorBuilder: (context, error, stackTrace) => _error(),
      );
}

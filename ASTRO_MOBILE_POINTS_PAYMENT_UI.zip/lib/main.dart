
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'screens/home_screen.dart';
import 'services/notification_service.dart';

const Color astroNavy = Color(0xFF082C5C);
const Color astroBlue = Color(0xFF087FE5);
const Color astroSky = Color(0xFF39BDF5);
const Color astroGold = astroBlue;
const Color astroBackground = Color(0xFFF3F8FD);

const String supabaseUrl =
    'https://exkhbenfbwrbqprtyqas.supabase.co';

const String supabasePublishableKey =
    'sb_publishable_9vmr76LVfpfmC_-M_w7p2g_odwDRN16';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url: supabaseUrl,
    publishableKey: supabasePublishableKey,
  );

  try {
    await NotificationService.instance.initialize();
  } catch (e) {
    debugPrint('ASTRO notifications initialization failed: $e');
  }

  runApp(const AstroMobileApp());
}

class AstroMobileApp extends StatelessWidget {
  const AstroMobileApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'ASTRO MOBILE',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          scaffoldBackgroundColor: astroBackground,
          colorScheme: ColorScheme.fromSeed(
            seedColor: astroBlue,
            primary: astroBlue,
            secondary: astroSky,
            surface: Colors.white,
            error: const Color(0xFFD92D20),
          ),
          appBarTheme: const AppBarTheme(
            backgroundColor: astroBackground,
            foregroundColor: astroNavy,
            elevation: 0,
            scrolledUnderElevation: 0,
            centerTitle: false,
            titleTextStyle: TextStyle(
              color: astroNavy,
              fontSize: 19,
              fontWeight: FontWeight.w900,
            ),
            iconTheme: IconThemeData(color: astroNavy),
          ),
          cardTheme: CardThemeData(
            color: Colors.white,
            elevation: 1.5,
            shadowColor: const Color(0x18082C5C),
            margin: EdgeInsets.zero,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
              side: const BorderSide(color: Color(0xFFE5EFFB)),
            ),
          ),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: Colors.white,
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 15,
            ),
            labelStyle: const TextStyle(color: Color(0xFF64748B)),
            hintStyle: const TextStyle(color: Color(0xFF94A3B8)),
            prefixIconColor: astroBlue,
            suffixIconColor: astroBlue,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: const BorderSide(color: Color(0xFFDCE8F6)),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: const BorderSide(color: Color(0xFFDCE8F6)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: const BorderSide(color: astroBlue, width: 1.6),
            ),
            errorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: const BorderSide(color: Color(0xFFD92D20)),
            ),
          ),
          elevatedButtonTheme: ElevatedButtonThemeData(
            style: ElevatedButton.styleFrom(
              backgroundColor: astroBlue,
              foregroundColor: Colors.white,
              elevation: 0,
              minimumSize: const Size(48, 50),
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 13),
              textStyle: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
            ),
          ),
          outlinedButtonTheme: OutlinedButtonThemeData(
            style: OutlinedButton.styleFrom(
              foregroundColor: astroBlue,
              minimumSize: const Size(44, 48),
              side: const BorderSide(color: Color(0xFFB8D7FA)),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
            ),
          ),
          snackBarTheme: SnackBarThemeData(
            behavior: SnackBarBehavior.floating,
            backgroundColor: astroNavy,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
            ),
          ),
          dividerTheme: const DividerThemeData(
            color: Color(0xFFE8EFF8),
            thickness: 1,
            space: 1,
          ),
        ),
        home: const Directionality(
          textDirection: TextDirection.rtl,
          child: HomeScreen(),
        ),
      );
}

-- ASTRO MOBILE: Store contact settings
-- Run once in Supabase SQL Editor.

create table if not exists public.store_contact_settings (
  id integer primary key default 1 check (id = 1),
  address text not null default 'طرابلس، أبوسليم، شارع أم درمان الرئيسي، بالقرب من شارع السلام',
  phone text not null default '',
  whatsapp text not null default '',
  facebook_url text not null default '',
  instagram_url text not null default '',
  tiktok_url text not null default '',
  working_hours text not null default '',
  updated_at timestamptz not null default now()
);

insert into public.store_contact_settings (id)
values (1)
on conflict (id) do nothing;

alter table public.store_contact_settings enable row level security;

grant select on public.store_contact_settings to anon, authenticated;
grant insert, update, delete on public.store_contact_settings to authenticated;

drop policy if exists "Public can read store contact settings"
on public.store_contact_settings;

create policy "Public can read store contact settings"
on public.store_contact_settings
for select to anon, authenticated
using (true);

drop policy if exists "Authenticated admins can update store contact settings"
on public.store_contact_settings;

create policy "Authenticated admins can update store contact settings"
on public.store_contact_settings
for all to authenticated
using ((auth.jwt() ->> 'email') = 'ahmedkabar.ak@gmail.com')
with check ((auth.jwt() ->> 'email') = 'ahmedkabar.ak@gmail.com');

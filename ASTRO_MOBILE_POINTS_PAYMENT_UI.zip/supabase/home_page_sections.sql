-- ASTRO MOBILE: أقسام الصفحة الرئيسية القابلة للإدارة من لوحة التحكم
create table if not exists public.home_page_sections (
  section_key text primary key,
  title text not null,
  product_ids jsonb not null default '[]'::jsonb,
  is_enabled boolean not null default true,
  sort_order integer not null default 0,
  updated_at timestamptz not null default now(),
  constraint home_page_sections_product_ids_array check (jsonb_typeof(product_ids) = 'array')
);

alter table public.home_page_sections enable row level security;

-- قراءة الأقسام متاحة لتطبيق المتجر، والكتابة للمدير المسجل فقط عبر سياسة البريد المعتمد.
drop policy if exists "home sections are readable" on public.home_page_sections;
create policy "home sections are readable"
on public.home_page_sections for select
using (true);

drop policy if exists "admin manages home sections" on public.home_page_sections;
create policy "admin manages home sections"
on public.home_page_sections for all
to authenticated
using (lower(coalesce(auth.jwt() ->> 'email', '')) = 'ahmedkabar.ak@gmail.com')
with check (lower(coalesce(auth.jwt() ->> 'email', '')) = 'ahmedkabar.ak@gmail.com');

grant select on public.home_page_sections to anon, authenticated;
grant insert, update, delete on public.home_page_sections to authenticated;

-- قيم افتراضية: لا تُختار منتجات تلقائياً؛ المدير يحددها بنفسه من لوحة الإدارة.
insert into public.home_page_sections (section_key, title, product_ids, is_enabled, sort_order)
values
 ('best_selling', 'الأكثر مبيعاً', '[]'::jsonb, true, 10),
 ('used', 'مستعمل بحالة ممتازة', '[]'::jsonb, true, 20),
 ('accessories', 'كماليات لا غنى عنها', '[]'::jsonb, true, 30),
 ('budget', 'خيارات تناسب ميزانيتك', '[]'::jsonb, true, 40),
 ('astro_picks', 'اختيارات ASTRO', '[]'::jsonb, true, 50)
on conflict (section_key) do nothing;

-- تفعيل Realtime إن لم يكن الجدول ضمن publication الحالية
DO $$
BEGIN
  ALTER PUBLICATION supabase_realtime ADD TABLE public.home_page_sections;
EXCEPTION WHEN duplicate_object THEN NULL;
WHEN undefined_object THEN NULL;
END $$;

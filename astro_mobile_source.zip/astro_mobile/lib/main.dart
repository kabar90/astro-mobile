import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(const AstroMobileApp());
}

class AstroMobileApp extends StatelessWidget {
  const AstroMobileApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ASTRO MOBILE',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF1A1A2E),
          primary: const Color(0xFF16213E),
          secondary: const Color(0xFF0F3460),
        ),
        scaffoldBackgroundColor: const Color(0xFFF8F9FA),
      ),
      home: const Directionality(
        textDirection: TextDirection.rtl,
        child: HomeScreen(),
      ),
    );
  }
}

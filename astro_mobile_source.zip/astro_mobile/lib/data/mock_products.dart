import '../models/product.dart';

class MockProducts {
  static const List<Product> list = [
    Product(
      id: '1',
      name: 'iPhone 15 Pro Max',
      category: 'هواتف ذكية',
      price: 1199.00,
      imageUrl: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=500',
      description: 'هاتف أبل بتصميم من التيتانيوم وكاميرا متقدمة.',
    ),
    Product(
      id: '2',
      name: 'Samsung Galaxy S24 Ultra',
      category: 'هواتف ذكية',
      price: 1299.00,
      imageUrl: 'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?w=500',
      description: 'هاتف سامسونج الرائد مع مزايا الذكاء الاصطناعي.',
    ),
    Product(
      id: '3',
      name: 'AirPods Pro 2nd Gen',
      category: 'كماليات',
      price: 249.00,
      imageUrl: 'https://images.unsplash.com/photo-1600294037681-c80b4cb5b434?w=500',
      description: 'سماعات لاسلكية مع خاصية إلغاء الضوضاء.',
    ),
    Product(
      id: '4',
      name: 'Anker Fast Charger 65W',
      category: 'كماليات',
      price: 45.00,
      imageUrl: 'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?w=500',
      description: 'شاحن سريع بتقنية GaN.',
    ),
  ];
}

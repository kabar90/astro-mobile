import { initializeApp } from "https://www.gstatic.com/firebasejs/11.10.0/firebase-app.js";
import {
  getAuth, onAuthStateChanged, signInWithEmailAndPassword, signOut
} from "https://www.gstatic.com/firebasejs/11.10.0/firebase-auth.js";
import {
  getFirestore, collection, addDoc, updateDoc, deleteDoc, doc,
  onSnapshot, getDocs, serverTimestamp
} from "https://www.gstatic.com/firebasejs/11.10.0/firebase-firestore.js";
import {
  getStorage, ref, uploadBytes, getDownloadURL
} from "https://www.gstatic.com/firebasejs/11.10.0/firebase-storage.js";
import { firebaseConfig, ADMIN_EMAIL } from "./firebase-config.js";

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);

const $ = (id) => document.getElementById(id);
const loginView = $("loginView");
const appView = $("appView");
const dialog = $("productDialog");
let productsCache = [];
let unsubscribeProducts = null;
let unsubscribeOrders = null;

function toast(message) {
  const el = $("toast");
  el.textContent = message;
  el.classList.add("show");
  setTimeout(() => el.classList.remove("show"), 2800);
}
function money(value) {
  return `${Number(value || 0).toLocaleString("en-US")} د.ل`;
}
function safe(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
  }[c]));
}
function showApp(user) {
  loginView.classList.add("hidden");
  appView.classList.remove("hidden");
  $("adminEmail").textContent = user.email || "";
  startProducts();
  startOrders();
}
function showLogin() {
  appView.classList.add("hidden");
  loginView.classList.remove("hidden");
  if (unsubscribeProducts) unsubscribeProducts();
  if (unsubscribeOrders) unsubscribeOrders();
}
onAuthStateChanged(auth, async user => {
  if (!user) return showLogin();
  if (ADMIN_EMAIL.includes("ضع_بريد") || user.email?.toLowerCase() !== ADMIN_EMAIL.toLowerCase()) {
    await signOut(auth);
    $("loginError").textContent = "هذا الحساب غير مصرح له بلوحة الإدارة. تحقق من بريد المدير في firebase-config.js.";
    return;
  }
  showApp(user);
});

$("loginForm").addEventListener("submit", async e => {
  e.preventDefault();
  $("loginError").textContent = "";
  try {
    await signInWithEmailAndPassword(auth, $("email").value.trim(), $("password").value);
  } catch (err) {
    $("loginError").textContent = "تعذر تسجيل الدخول. تحقق من البريد وكلمة المرور وتفعيل Email/Password في Firebase.";
  }
});
$("logoutBtn").addEventListener("click", () => signOut(auth));
$("productSearch").addEventListener("input", renderProducts);

document.querySelectorAll(".nav").forEach(btn => btn.addEventListener("click", () => {
  document.querySelectorAll(".nav").forEach(x => x.classList.toggle("active", x === btn));
  const page = btn.dataset.page;
  $("productsPage").classList.toggle("hidden", page !== "products");
  $("ordersPage").classList.toggle("hidden", page !== "orders");
  $("pageTitle").textContent = page === "products" ? "إدارة المنتجات" : "طلبات العملاء";
}));

function startProducts() {
  if (unsubscribeProducts) unsubscribeProducts();
  unsubscribeProducts = onSnapshot(collection(db, "products"), snap => {
    productsCache = snap.docs.map(d => ({ id:d.id, ...d.data() }));
    renderProducts();
    $("productsMessage").textContent = `${productsCache.length} منتج`;
  }, err => {
    $("productsMessage").textContent = "تعذر قراءة المنتجات";
    toast("تحقق من إنشاء Firestore وقواعد الأمان.");
    console.error(err);
  });
}
function renderProducts() {
  const q = $("productSearch").value.trim().toLowerCase();
  const list = productsCache.filter(p => `${p.name || ""} ${p.category || ""}`.toLowerCase().includes(q));
  $("productCount").textContent = productsCache.length;
  $("activeCount").textContent = productsCache.filter(p => p.isActive !== false).length;
  $("productsTable").innerHTML = list.length ? list.map(p => `
    <tr>
      <td><div class="product-cell">${p.imageUrl ? `<img class="thumb" src="${safe(p.imageUrl)}" alt="">` : `<div class="thumb"></div>`}<strong>${safe(p.name || "بدون اسم")}</strong></div></td>
      <td>${safe(p.category || "هواتف")}</td>
      <td>${money(p.price)}</td>
      <td>${Number(p.stock ?? 0)}</td>
      <td><span class="badge ${p.isActive === false ? "off" : "on"}">${p.isActive === false ? "مخفي" : "نشط"}</span></td>
      <td><button class="table-btn" data-edit="${p.id}">تعديل</button><button class="table-btn danger" data-delete="${p.id}">حذف</button></td>
    </tr>`).join("") : `<tr><td colspan="6" class="empty">لا توجد منتجات. اضغط «إضافة منتج» للبدء.</td></tr>`;
  document.querySelectorAll("[data-edit]").forEach(b => b.addEventListener("click", () => editProduct(b.dataset.edit)));
  document.querySelectorAll("[data-delete]").forEach(b => b.addEventListener("click", () => removeProduct(b.dataset.delete)));
}
function resetForm() {
  $("productForm").reset();
  $("productId").value = "";
  $("stock").value = "1";
  $("isActive").checked = true;
  $("imageUrl").value = "";
  $("imageFile").value = "";
  $("formError").textContent = "";
}
function openNewProduct() {
  resetForm();
  $("dialogTitle").textContent = "إضافة منتج جديد";
  dialog.showModal();
}
function editProduct(id) {
  const p = productsCache.find(x => x.id === id);
  if (!p) return;
  resetForm();
  $("dialogTitle").textContent = "تعديل المنتج";
  $("productId").value = p.id;
  $("name").value = p.name || "";
  $("category").value = p.category || "هواتف";
  $("price").value = p.price ?? 0;
  $("stock").value = p.stock ?? 0;
  $("description").value = p.description || "";
  $("imageUrl").value = p.imageUrl || "";
  $("isActive").checked = p.isActive !== false;
  dialog.showModal();
}
async function removeProduct(id) {
  const p = productsCache.find(x => x.id === id);
  if (!p || !confirm(`هل تريد حذف المنتج "${p.name}"؟`)) return;
  try {
    await deleteDoc(doc(db, "products", id));
    toast("تم حذف المنتج.");
  } catch (e) { console.error(e); toast("لم يتم الحذف. تحقق من صلاحيات Firestore."); }
}
$("addProductBtn").addEventListener("click", openNewProduct);
$("closeDialog").addEventListener("click", () => dialog.close());
$("cancelDialog").addEventListener("click", () => dialog.close());

$("productForm").addEventListener("submit", async e => {
  e.preventDefault();
  const save = $("saveProductBtn");
  save.disabled = true;
  save.textContent = "جارٍ الحفظ...";
  $("formError").textContent = "";
  try {
    let imageUrl = $("imageUrl").value.trim();
    const file = $("imageFile").files[0];
    if (file) {
      const cleanName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
      const imageRef = ref(storage, `products/${Date.now()}-${cleanName}`);
      await uploadBytes(imageRef, file);
      imageUrl = await getDownloadURL(imageRef);
    }
    const payload = {
      name: $("name").value.trim(),
      category: $("category").value,
      price: Number($("price").value),
      stock: Number($("stock").value || 0),
      description: $("description").value.trim(),
      imageUrl,
      isActive: $("isActive").checked,
      updatedAt: serverTimestamp()
    };
    const id = $("productId").value;
    if (id) {
      await updateDoc(doc(db, "products", id), payload);
      toast("تم تحديث المنتج.");
    } else {
      payload.createdAt = serverTimestamp();
      await addDoc(collection(db, "products"), payload);
      toast("تمت إضافة المنتج.");
    }
    dialog.close();
  } catch (err) {
    console.error(err);
    $("formError").textContent = "تعذر الحفظ. تأكد من تفعيل Firestore وStorage ومن قواعد الأمان.";
  } finally {
    save.disabled = false;
    save.textContent = "حفظ المنتج";
  }
});

function startOrders() {
  if (unsubscribeOrders) unsubscribeOrders();
  unsubscribeOrders = onSnapshot(collection(db, "orders"), snap => {
    const orders = snap.docs.map(d => ({id:d.id,...d.data()}));
    orders.sort((a,b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0));
    renderOrders(orders);
  }, err => {
    $("ordersTable").innerHTML = `<tr><td colspan="7" class="empty">تعذر قراءة الطلبات. تأكد من قواعد Firestore.</td></tr>`;
    console.error(err);
  });
}
function renderOrders(orders) {
  $("ordersTable").innerHTML = orders.length ? orders.map(o => {
    const customer = o.customer || {};
    const status = o.status || "جديد";
    return `<tr>
      <td>${safe(o.orderNumber || o.id.slice(0,8))}</td>
      <td>${safe(o.customerName || customer.name || "—")}</td>
      <td>${safe(o.phone || customer.phone || "—")}</td>
      <td>${money(o.total)}</td>
      <td>${safe(o.paymentMethod || "—")}</td>
      <td><span class="badge">${safe(status)}</span></td>
      <td><select class="order-status" data-order="${o.id}">
        ${["جديد","قيد التجهيز","جاهز للاستلام","خرج للتوصيل","مكتمل","ملغي"].map(s=>`<option ${s===status?"selected":""}>${s}</option>`).join("")}
      </select></td>
    </tr>`;
  }).join("") : `<tr><td colspan="7" class="empty">لا توجد طلبات حتى الآن. ستظهر هنا بعد ربط إتمام الطلب في تطبيق الزبائن.</td></tr>`;
  document.querySelectorAll(".order-status").forEach(sel => sel.addEventListener("change", async () => {
    try {
      await updateDoc(doc(db,"orders",sel.dataset.order),{status:sel.value,updatedAt:serverTimestamp()});
      toast("تم تحديث حالة الطلب.");
    } catch(e) { console.error(e); toast("تعذر تحديث الطلب. تحقق من الصلاحيات."); }
  }));
}

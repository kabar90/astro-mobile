// إعدادات مشروع Firebase الخاص بمتجر ASTRO MOBILE.
// هذه القيم مأخوذة من إعدادات مشروع Android الحالي. لا تضع كلمة مرور Firebase هنا.
export const firebaseConfig = {
  apiKey: "AIzaSyAT4Kl3MI21TVuhBu8oO94paF91AnIFQD8",
  authDomain: "astro-mobile-store-2026.firebaseapp.com",
  projectId: "astro-mobile-store-2026",
  storageBucket: "astro-mobile-store-2026.firebasestorage.app",
  messagingSenderId: "406900305693"
};

// استبدل هذا النص بالبريد الذي ستنشئ به حساب المدير في Firebase Authentication.
export const ADMIN_EMAIL = "ضع_بريد_المدير_هنا";

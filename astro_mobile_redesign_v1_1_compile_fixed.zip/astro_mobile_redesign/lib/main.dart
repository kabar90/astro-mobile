import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

const Color astroNavy = Color(0xFF14233F);
const Color astroGold = Color(0xFFC8A45D);
const Color astroBackground = Color(0xFFF6F7FA);

void main() => runApp(const AstroMobileApp());

class AstroMobileApp extends StatelessWidget {
  const AstroMobileApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'ASTRO MOBILE',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: astroBackground,
      colorScheme: ColorScheme.fromSeed(seedColor: astroNavy, primary: astroNavy, secondary: astroGold),
      appBarTheme: const AppBarTheme(backgroundColor: astroBackground, foregroundColor: astroNavy, elevation: 0),
    ),
    home: const Directionality(textDirection: TextDirection.rtl, child: HomeScreen()),
  );
}

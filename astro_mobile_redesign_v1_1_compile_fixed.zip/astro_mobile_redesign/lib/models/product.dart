class Product {
  final String id, name, category, imageUrl, description;
  final double price;
  const Product({required this.id, required this.name, required this.category, required this.price, required this.imageUrl, required this.description});
}

import 'package:flutter/material.dart';

import '../data/mock_products.dart';
import '../main.dart';
import '../models/product.dart';
import 'product_detail_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController _searchController = TextEditingController();
  String _selectedCategory = 'الكل';
  int _selectedNav = 0;

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), behavior: SnackBarBehavior.floating),
    );
  }

  @override
  Widget build(BuildContext context) {
    final query = _searchController.text.trim().toLowerCase();
    final List<Product> products = MockProducts.list.where((product) {
      final categoryMatches = _selectedCategory == 'الكل' ||
          product.category == _selectedCategory;
      final searchMatches =
          '${product.name} ${product.category}'.toLowerCase().contains(query);
      return categoryMatches && searchMatches;
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'ASTRO MOBILE',
              style: TextStyle(
                fontSize: 19,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.1,
              ),
            ),
            SizedBox(height: 2),
            Text(
              'كل ما تحتاجه من التقنية',
              style: TextStyle(fontSize: 11, color: Colors.black54),
            ),
          ],
        ),
        actions: [
          _actionButton(
            Icons.notifications_none_rounded,
            () => _showMessage('لا توجد إشعارات جديدة حالياً'),
          ),
          const SizedBox(width: 8),
          _actionButton(
            Icons.shopping_bag_outlined,
            () => _showMessage('سلة المشتريات ستُفعّل في المرحلة التالية'),
          ),
          const SizedBox(width: 14),
        ],
      ),
      body: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(child: _buildSearchField()),
          SliverToBoxAdapter(child: _buildHeroBanner()),
          SliverToBoxAdapter(child: _buildCategories()),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 22, 18, 12),
              child: Row(
                children: [
                  const Expanded(
                    child: Text(
                      'اختيارات ASTRO',
                      style: TextStyle(
                        fontSize: 19,
                        fontWeight: FontWeight.w900,
                        color: astroNavy,
                      ),
                    ),
                  ),
                  Text(
                    '${products.length} منتجات',
                    style: const TextStyle(fontSize: 12, color: Colors.black45),
                  ),
                ],
              ),
            ),
          ),
          if (products.isEmpty)
            const SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.all(30),
                child: Center(child: Text('لا توجد منتجات تطابق بحثك')),
              ),
            )
          else
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 22),
              sliver: SliverGrid(
                delegate: SliverChildBuilderDelegate(
                  (context, index) => _buildProductCard(products[index]),
                  childCount: products.length,
                ),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 14,
                  crossAxisSpacing: 14,
                  childAspectRatio: 0.66,
                ),
              ),
            ),
        ],
      ),
      bottomNavigationBar: _buildBottomNavigationBar(),
    );
  }

  Widget _actionButton(IconData icon, VoidCallback onPressed) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Material(
        color: Colors.white,
        shape: const CircleBorder(),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: onPressed,
          child: SizedBox(
            width: 40,
            height: 40,
            child: Icon(icon, color: astroNavy, size: 21),
          ),
        ),
      ),
    );
  }

  Widget _buildSearchField() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 8, 18, 16),
      child: Container(
        height: 52,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(15),
          border: Border.all(color: const Color(0xFFE8EBF0)),
        ),
        child: TextField(
          controller: _searchController,
          onChanged: (_) => setState(() {}),
          decoration: const InputDecoration(
            hintText: 'ابحث عن هاتف أو إكسسوار...',
            hintStyle: TextStyle(fontSize: 13, color: Colors.black38),
            prefixIcon: Icon(Icons.search_rounded, color: astroGold),
            border: InputBorder.none,
            contentPadding: EdgeInsets.symmetric(vertical: 15),
          ),
        ),
      ),
    );
  }

  Widget _buildHeroBanner() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18),
      child: Container(
        height: 174,
        width: double.infinity,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: const LinearGradient(
            colors: [Color(0xFF101D35), Color(0xFF24466F)],
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
          ),
          boxShadow: [
            BoxShadow(
              color: astroNavy.withOpacity(0.15),
              blurRadius: 16,
              offset: const Offset(0, 7),
            ),
          ],
        ),
        child: Stack(
          children: [
            Positioned(
              left: -5,
              bottom: -20,
              child: Icon(
                Icons.phone_iphone_rounded,
                size: 130,
                color: Colors.white.withOpacity(0.08),
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: astroGold.withOpacity(0.18),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: astroGold.withOpacity(0.5)),
                  ),
                  child: const Text(
                    'ASTRO MOBILE',
                    style: TextStyle(
                      color: Color(0xFFE8D4A8),
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                const Text(
                  'تقنيتك تبدأ من هنا',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 6),
                const Text(
                  'هواتف وإكسسوارات مختارة بعناية',
                  style: TextStyle(color: Colors.white70, fontSize: 12),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCategories() {
    return SizedBox(
      height: 94,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.fromLTRB(18, 18, 18, 8),
        children: [
          _categoryButton('الكل', Icons.grid_view_rounded),
          _categoryButton('هواتف', Icons.smartphone_rounded),
          _categoryButton('كماليات', Icons.headphones_rounded),
          InkWell(
            onTap: () => _showMessage('قسم المستعمل سيُضاف عند تجهيز منتجاته'),
            child: _categoryTile('مستعمل', Icons.phone_android_rounded, false),
          ),
        ],
      ),
    );
  }

  Widget _categoryButton(String label, IconData icon) {
    return Padding(
      padding: const EdgeInsets.only(left: 9),
      child: _categoryTile(label, icon, _selectedCategory == label),
    );
  }

  Widget _categoryTile(String label, IconData icon, bool selected) {
    return InkWell(
      borderRadius: BorderRadius.circular(15),
      onTap: () => setState(() => _selectedCategory = label),
      child: Container(
        width: 76,
        decoration: BoxDecoration(
          color: selected ? astroNavy : Colors.white,
          borderRadius: BorderRadius.circular(15),
          border: Border.all(
            color: selected ? astroNavy : const Color(0xFFE8EBF0),
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 21, color: selected ? astroGold : astroNavy),
            const SizedBox(height: 6),
            Text(
              label,
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.bold,
                color: selected ? Colors.white : astroNavy,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProductCard(Product product) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => ProductDetailScreen(product: product),
            ),
          );
        },
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: const Color(0xFFEDEFF3)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Stack(
                  children: [
                    ClipRRect(
                      borderRadius: const BorderRadius.vertical(
                        top: Radius.circular(18),
                      ),
                      child: SizedBox(
                        width: double.infinity,
                        child: Image.network(
                          product.imageUrl,
                          fit: BoxFit.contain,
                          loadingBuilder: (context, child, progress) {
                            if (progress == null) return child;
                            return _imagePlaceholder(product.category, true);
                          },
                          errorBuilder: (_, __, ___) =>
                              _imagePlaceholder(product.category, false),
                        ),
                      ),
                    ),
                    Positioned(
                      top: 9,
                      right: 9,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF5EBD7),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          product.category,
                          style: const TextStyle(
                            fontSize: 10,
                            color: astroNavy,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(11, 9, 11, 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      product.name,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 13,
                        height: 1.25,
                        fontWeight: FontWeight.w800,
                        color: astroNavy,
                      ),
                    ),
                    const SizedBox(height: 9),
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            '${product.price.toStringAsFixed(0)} د.ل',
                            style: const TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w900,
                              color: astroNavy,
                            ),
                          ),
                        ),
                        Container(
                          width: 28,
                          height: 28,
                          decoration: BoxDecoration(
                            color: astroNavy,
                            borderRadius: BorderRadius.circular(9),
                          ),
                          child: const Icon(
                            Icons.arrow_back_rounded,
                            size: 17,
                            color: astroGold,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _imagePlaceholder(String category, bool loading) {
    return Container(
      color: const Color(0xFFF2F4F7),
      child: Center(
        child: loading
            ? const SizedBox(
                width: 22,
                height: 22,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: astroGold,
                ),
              )
            : Icon(
                category == 'هواتف'
                    ? Icons.smartphone_rounded
                    : Icons.headphones_rounded,
                size: 55,
                color: astroNavy.withOpacity(0.3),
              ),
      ),
    );
  }

  Widget _buildBottomNavigationBar() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 12,
            offset: const Offset(0, -3),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: 64,
          child: Row(
            children: [
              _navItem(0, Icons.storefront_rounded, 'المتجر'),
              _navItem(1, Icons.category_rounded, 'الأقسام'),
              _navItem(2, Icons.shopping_cart_outlined, 'السلة'),
              _navItem(3, Icons.person_outline_rounded, 'حسابي'),
            ],
          ),
        ),
      ),
    );
  }

  Widget _navItem(int index, IconData icon, String label) {
    final bool active = _selectedNav == index;
    return Expanded(
      child: InkWell(
        onTap: () {
          setState(() => _selectedNav = index);
          if (index != 0) {
            _showMessage(
              index == 1
                  ? 'الأقسام تظهر في أعلى المتجر'
                  : index == 2
                      ? 'السلة ستُفعّل في المرحلة التالية'
                      : 'حساب العميل سيُضاف في المرحلة التالية',
            );
          }
        },
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: active ? astroGold : Colors.black38, size: 22),
            const SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(
                fontSize: 10,
                color: active ? astroNavy : Colors.black45,
                fontWeight: active ? FontWeight.bold : FontWeight.normal,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

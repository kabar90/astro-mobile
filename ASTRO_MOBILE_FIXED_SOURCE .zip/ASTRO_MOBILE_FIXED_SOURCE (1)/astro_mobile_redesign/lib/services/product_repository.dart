import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/product.dart';

class ProductRepository {
  ProductRepository._();

  static final FirebaseFirestore _db = FirebaseFirestore.instance;

  /// Reads the public product catalogue from Firestore in real time.
  /// Firestore collection: products
  static Stream<List<Product>> watchProducts() {
    try {
      return FirebaseFirestore.instance.collection('products').snapshots().map((snapshot) {
      final products = snapshot.docs
          .map((doc) => Product.fromMap(doc.id, doc.data()))
          .where((product) => product.isActive && product.name.isNotEmpty)
          .toList();
        return products;
      });
    } catch (error) {
      // Firebase may not be configured yet. HomeScreen will show sample items.
      return Stream<List<Product>>.value(const []);
    }
  }
}

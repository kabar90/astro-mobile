
import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/product.dart';

class ProductRepository {
  ProductRepository._();

  static final SupabaseClient _db = Supabase.instance.client;

  /// قراءة المنتجات النشطة مباشرة من Supabase
  static Stream<List<Product>> watchProducts() {
    return _db
        .from('products')
        .stream(primaryKey: ['id'])
        .eq('is_active', true)
        .map((rows) {
          return rows
              .map((row) => Product.fromMap(
                    row['id'].toString(),
                    row,
                  ))
              .where((product) => product.name.isNotEmpty)
              .toList();
        });
  }
}

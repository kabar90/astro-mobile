
class Product {
  final String id;
  final String name;
  final String category;
  final double price;
  final String imageUrl;
  final String description;
  final bool isActive;

  const Product({
    required this.id,
    required this.name,
    required this.category,
    required this.price,
    required this.imageUrl,
    required this.description,
    this.isActive = true,
  });

  factory Product.fromMap(String id, Map<String, dynamic> data) {
    final rawPrice = data['price'];

    return Product(
      id: id,
      name: (data['name'] ?? '').toString(),
      category: (data['category'] ?? 'هواتف').toString(),
      price: rawPrice is num
          ? rawPrice.toDouble()
          : double.tryParse('$rawPrice') ?? 0,
      imageUrl: (data['image_url'] ?? data['imageUrl'] ?? '').toString(),
      description: (data['description'] ?? '').toString(),
      isActive: data['is_active'] is bool
          ? data['is_active'] as bool
          : data['isActive'] is bool
              ? data['isActive'] as bool
              : true,
    );
  }
}

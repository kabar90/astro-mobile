import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/product.dart';

class ProductRepository {
  ProductRepository._();

  static final FirebaseFirestore _db = FirebaseFirestore.instance;

  /// Reads the public product catalogue from Firestore in real time.
  /// Firestore collection: products
  static Stream<List<Product>> watchProducts() {
    return _db.collection('products').snapshots().map((snapshot) {
      final products = snapshot.docs
          .map((doc) => Product.fromMap(doc.id, doc.data()))
          .where((product) => product.isActive && product.name.isNotEmpty)
          .toList();
      return products;
    });
  }
}

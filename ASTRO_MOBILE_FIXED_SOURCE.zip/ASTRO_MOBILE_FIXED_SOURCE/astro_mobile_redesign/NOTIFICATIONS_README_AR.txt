ASTRO MOBILE - إشعارات FCM + Supabase
=====================================

تمت إضافة:
- Firebase Messaging لاستلام Push على Android.
- إشعارات محلية عند وصول إشعار والتطبيق مفتوح.
- صفحة سجل إشعارات محلية عبر زر الجرس.
- ربط رمز الجهاز برقم هاتف العميل بعد نجاح إنشاء الطلب.
- حذف حزم Firebase غير المستخدمة (Firestore/Auth/Storage) والإبقاء على Firebase Core وMessaging فقط.

مهم:
1) هذا المصدر يحتاج ملف google-services.json الصحيح داخل android/app عند البناء.
2) مشروع Android يجب أن يحمل package name المطابق لتسجيل Firebase.
3) يجب نشر Supabase Edge Function المسماة fcm-notifications وتطبيق SQL المرفق في حزمة Backend.
4) حتى الآن لا تُرسل إشعارات الطلبات أو العروض تلقائياً قبل نشر Edge Function وربط لوحة الإدارة بها.
5) سجل الإشعارات داخل التطبيق يحتفظ بالإشعارات التي وصلت لهذا الجهاز فقط.

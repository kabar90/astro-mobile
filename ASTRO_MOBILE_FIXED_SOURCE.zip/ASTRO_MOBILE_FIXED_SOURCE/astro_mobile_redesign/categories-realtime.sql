-- ASTRO MOBILE: تفعيل التحديث الفوري للأقسام في تطبيق Flutter
-- نفّذ هذا مرة واحدة في Supabase SQL Editor إذا لم تكن categories مضافة إلى Realtime.

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime'
      AND schemaname = 'public'
      AND tablename = 'categories'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.categories;
  END IF;
END $$;

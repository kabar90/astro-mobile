import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/product.dart';

class StoreCategory {
  final int id;
  final String name;
  final int? parentId;
  final int sortOrder;
  final bool isActive;

  const StoreCategory({
    required this.id,
    required this.name,
    required this.parentId,
    required this.sortOrder,
    required this.isActive,
  });

  factory StoreCategory.fromMap(Map<String, dynamic> row) {
    int? asInt(dynamic value) {
      if (value is int) return value;
      return int.tryParse('${value ?? ''}');
    }

    return StoreCategory(
      id: asInt(row['id']) ?? 0,
      name: (row['name'] ?? '').toString(),
      parentId: asInt(row['parent_id']),
      sortOrder: asInt(row['sort_order']) ?? 0,
      isActive: row['is_active'] is bool ? row['is_active'] as bool : true,
    );
  }
}

class ProductRepository {
  ProductRepository._();

  static final SupabaseClient _db = Supabase.instance.client;

  static Stream<List<StoreCategory>> watchCategories() {
    return _db
        .from('categories')
        .stream(primaryKey: ['id'])
        .map((rows) => rows
            .map(StoreCategory.fromMap)
            .where((category) => category.id > 0 && category.name.isNotEmpty)
            .toList()
          ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder)));
  }

  static Stream<List<Product>> watchProducts() {
    return _db
        .from('products')
        .stream(primaryKey: ['id'])
        .eq('is_active', true)
        .map((rows) {
          return rows
              .map((row) => Product.fromMap(
                    row['id'].toString(),
                    row,
                  ))
              .where((product) => product.name.isNotEmpty)
              .toList();
        });
  }
}

import 'package:flutter/foundation.dart';
import '../models/product.dart';

class CartLine {
  final Product product;
  final String? color;
  int quantity;

  CartLine({
    required this.product,
    required this.color,
    this.quantity = 1,
  });

  double get total => product.price * quantity;
}

class CartService extends ChangeNotifier {
  CartService._();

  static final CartService instance = CartService._();

  final List<CartLine> _items = [];

  List<CartLine> get items => List.unmodifiable(_items);

  int get count =>
      _items.fold(0, (sum, item) => sum + item.quantity);

  double get total =>
      _items.fold(0, (sum, item) => sum + item.total);

  void add(Product product, String? color) {
    final index = _items.indexWhere(
      (item) => item.product.id == product.id && item.color == color,
    );

    if (index >= 0) {
      _items[index].quantity++;
    } else {
      _items.add(CartLine(product: product, color: color));
    }

    notifyListeners();
  }

  void changeQuantity(CartLine line, int delta) {
    line.quantity += delta;
    if (line.quantity <= 0) {
      _items.remove(line);
    }
    notifyListeners();
  }

  void remove(CartLine line) {
    _items.remove(line);
    notifyListeners();
  }

  void clear() {
    _items.clear();
    notifyListeners();
  }
}

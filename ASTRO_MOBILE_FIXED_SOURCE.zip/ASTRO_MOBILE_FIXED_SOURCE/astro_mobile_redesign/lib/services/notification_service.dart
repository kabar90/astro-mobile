import 'dart:convert';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

const AndroidNotificationChannel _channel = AndroidNotificationChannel(
  'astro_mobile_notifications',
  'ASTRO MOBILE',
  description: 'إشعارات الطلبات والعروض من ASTRO MOBILE',
  importance: Importance.high,
);

@pragma('vm:entry-point')
Future<void> astroFirebaseBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
}

class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();

  final FlutterLocalNotificationsPlugin _local =
      FlutterLocalNotificationsPlugin();

  static const _historyKey = 'astro_notification_history';
  static const _phoneKey = 'astro_notification_phone';
  bool _ready = false;
  String? _lastPhone;

  Future<void> initialize() async {
    if (_ready) return;

    await Firebase.initializeApp();
    FirebaseMessaging.onBackgroundMessage(astroFirebaseBackgroundHandler);

    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const settings = InitializationSettings(android: android);
    await _local.initialize(settings);

    final androidPlugin = _local.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    await androidPlugin?.createNotificationChannel(_channel);

    await FirebaseMessaging.instance.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );

    FirebaseMessaging.onMessage.listen(_showForeground);
    FirebaseMessaging.onMessageOpenedApp.listen(_recordMessage);

    final prefs = await SharedPreferences.getInstance();
    _lastPhone = prefs.getString(_phoneKey);

    FirebaseMessaging.instance.onTokenRefresh.listen((token) async {
      final phone = _lastPhone;
      if (phone != null && phone.isNotEmpty) {
        await _registerToken(token, phone);
      }
    });

    final initial = await FirebaseMessaging.instance.getInitialMessage();
    if (initial != null) await _recordMessage(initial);

    _ready = true;
  }

  Future<void> bindCurrentCustomerPhone(String phone) async {
    final normalized = phone.trim();
    if (normalized.isEmpty) return;

    _lastPhone = normalized;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_phoneKey, normalized);

    final token = await FirebaseMessaging.instance.getToken();
    if (token != null && token.isNotEmpty) {
      await _registerToken(token, normalized);
    }
  }

  Future<void> _registerToken(String token, String phone) async {
    try {
      await Supabase.instance.client.functions.invoke(
        'fcm-notifications',
        body: {
          'action': 'register',
          'phone': phone,
          'token': token,
          'platform': defaultTargetPlatform.name,
        },
      );
    } catch (e) {
      debugPrint('ASTRO notification registration failed: $e');
    }
  }

  Future<void> _showForeground(RemoteMessage message) async {
    await _recordMessage(message);
    final title = message.notification?.title ??
        message.data['title']?.toString() ??
        'ASTRO MOBILE';
    final body = message.notification?.body ??
        message.data['body']?.toString() ??
        'لديك إشعار جديد';

    await _local.show(
      message.messageId.hashCode,
      title,
      body,
      NotificationDetails(
        android: AndroidNotificationDetails(
          _channel.id,
          _channel.name,
          channelDescription: _channel.description,
          importance: Importance.high,
          priority: Priority.high,
          icon: '@mipmap/ic_launcher',
        ),
      ),
    );
  }

  Future<void> _recordMessage(RemoteMessage message) async {
    final prefs = await SharedPreferences.getInstance();
    final rows = prefs.getStringList(_historyKey) ?? <String>[];
    final item = {
      'title': message.notification?.title ??
          message.data['title']?.toString() ??
          'ASTRO MOBILE',
      'body': message.notification?.body ??
          message.data['body']?.toString() ??
          '',
      'date': DateTime.now().toIso8601String(),
    };
    rows.insert(0, jsonEncode(item));
    if (rows.length > 50) rows.removeRange(50, rows.length);
    await prefs.setStringList(_historyKey, rows);
  }

  Future<List<Map<String, dynamic>>> history() async {
    final prefs = await SharedPreferences.getInstance();
    final rows = prefs.getStringList(_historyKey) ?? <String>[];
    return rows.map((e) => jsonDecode(e) as Map<String, dynamic>).toList();
  }
}

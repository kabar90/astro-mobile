
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'screens/home_screen.dart';
import 'services/notification_service.dart';

const Color astroNavy = Color(0xFF14233F);
const Color astroGold = Color(0xFFC8A45D);
const Color astroBackground = Color(0xFFF6F7FA);

const String supabaseUrl =
    'https://exkhbenfbwrbqprtyqas.supabase.co';

const String supabasePublishableKey =
    'sb_publishable_9vmr76LVfpfmC_-M_w7p2g_odwDRN16';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url: supabaseUrl,
    publishableKey: supabasePublishableKey,
  );

  try {
    await NotificationService.instance.initialize();
  } catch (e) {
    debugPrint('ASTRO notifications initialization failed: $e');
  }

  runApp(const AstroMobileApp());
}

class AstroMobileApp extends StatelessWidget {
  const AstroMobileApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'ASTRO MOBILE',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          scaffoldBackgroundColor: astroBackground,
          colorScheme: ColorScheme.fromSeed(
            seedColor: astroNavy,
            primary: astroNavy,
            secondary: astroGold,
          ),
          appBarTheme: const AppBarTheme(
            backgroundColor: astroBackground,
            foregroundColor: astroNavy,
            elevation: 0,
          ),
        ),
        home: const Directionality(
          textDirection: TextDirection.rtl,
          child: HomeScreen(),
        ),
      );
}

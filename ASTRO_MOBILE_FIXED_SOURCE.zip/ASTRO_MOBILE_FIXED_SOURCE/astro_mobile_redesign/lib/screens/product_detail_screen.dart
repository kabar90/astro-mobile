import 'package:flutter/material.dart';
import '../main.dart';
import '../models/product.dart';
import '../services/cart_service.dart';
import 'cart_screen.dart';

class ProductDetailScreen extends StatefulWidget {
  final Product product;

  const ProductDetailScreen({
    super.key,
    required this.product,
  });

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  String? selectedColor;
  int quantity = 1;

  @override
  void initState() {
    super.initState();
    if (widget.product.colors.length == 1) {
      selectedColor = widget.product.colors.first;
    }
  }

  Color colorValue(String name) {
    final value = name.trim().toLowerCase();
    const colors = {
      'أسود': Color(0xFF222222),
      'اسود': Color(0xFF222222),
      'black': Color(0xFF222222),
      'أبيض': Color(0xFFF5F5F5),
      'ابيض': Color(0xFFF5F5F5),
      'white': Color(0xFFF5F5F5),
      'أزرق': Color(0xFF2865B5),
      'ازرق': Color(0xFF2865B5),
      'blue': Color(0xFF2865B5),
      'أخضر': Color(0xFF39845A),
      'اخضر': Color(0xFF39845A),
      'green': Color(0xFF39845A),
      'أحمر': Color(0xFFD83C3C),
      'احمر': Color(0xFFD83C3C),
      'red': Color(0xFFD83C3C),
      'ذهبي': Color(0xFFD6AE55),
      'gold': Color(0xFFD6AE55),
      'بنفسجي': Color(0xFF9470B8),
      'فضي': Color(0xFFC0C0C0),
      'رمادي': Color(0xFF888888),
      'وردي': Color(0xFFE99AB5),
    };
    return colors[value] ?? const Color(0xFFB8B8B8);
  }

  void _addToCart() {
    final product = widget.product;
    if (product.colors.isNotEmpty && selectedColor == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('يرجى اختيار لون المنتج أولاً')),
      );
      return;
    }

    CartService.instance.add(
      product,
      selectedColor,
      quantity: quantity,
    );

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('تمت إضافة $quantity من ${product.name} إلى السلة'),
        action: SnackBarAction(
          label: 'عرض السلة',
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const CartScreen()),
            );
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final product = widget.product;

    return Scaffold(
      backgroundColor: const Color(0xFFF2F6FC),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF2F6FC),
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        title: const Text(
          'تفاصيل المنتج',
          style: TextStyle(
            color: astroNavy,
            fontWeight: FontWeight.w900,
            fontSize: 19,
          ),
        ),
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.arrow_back_rounded, color: astroNavy),
        ),
        actions: [
          IconButton(
            tooltip: 'المفضلة',
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('قائمة المفضلة ستتوفر قريباً')),
              );
            },
            icon: const Icon(Icons.favorite_border_rounded, color: astroNavy),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(14, 4, 14, 20),
              children: [
                _buildHero(product),
                const SizedBox(height: 14),
                Container(
                  padding: const EdgeInsets.fromLTRB(17, 17, 17, 20),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: const Color(0xFFE7EEF7)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 7,
                            ),
                            decoration: BoxDecoration(
                              color: const Color(0xFFE7F3FF),
                              borderRadius: BorderRadius.circular(18),
                            ),
                            child: Text(
                              product.category,
                              style: const TextStyle(
                                color: astroNavy,
                                fontSize: 12,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                          const Spacer(),
                          const Text(
                            'ASTRO MOBILE',
                            style: TextStyle(
                              color: astroBlue,
                              fontSize: 13,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Text(
                        product.name,
                        textAlign: TextAlign.start,
                        style: const TextStyle(
                          color: astroNavy,
                          fontSize: 25,
                          fontWeight: FontWeight.w900,
                          height: 1.2,
                        ),
                      ),
                      const SizedBox(height: 7),
                      if (product.description.trim().isNotEmpty)
                        Text(
                          product.description.split('\n').first,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Color(0xFF75849A),
                            fontSize: 13,
                            height: 1.5,
                          ),
                        ),
                      const SizedBox(height: 15),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 15,
                          vertical: 12,
                        ),
                        decoration: BoxDecoration(
                          color: const Color(0xFFEAF4FF),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Row(
                          children: [
                            const Text(
                              'السعر',
                              style: TextStyle(
                                color: astroNavy,
                                fontSize: 14,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            const Spacer(),
                            Text(
                              '${product.price.toStringAsFixed(0)} د.ل',
                              style: const TextStyle(
                                color: astroNavy,
                                fontSize: 27,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ],
                        ),
                      ),
                      if (product.colors.isNotEmpty) ...[
                        const SizedBox(height: 23),
                        _sectionTitle(
                          'اختر لون المنتج',
                          Icons.layers_rounded,
                        ),
                        const SizedBox(height: 12),
                        Wrap(
                          spacing: 9,
                          runSpacing: 10,
                          children: product.colors.map((color) {
                            final selected = selectedColor == color;
                            return InkWell(
                              borderRadius: BorderRadius.circular(15),
                              onTap: () => setState(() {
                                selectedColor = color;
                              }),
                              child: AnimatedContainer(
                                duration: const Duration(milliseconds: 160),
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 13,
                                  vertical: 10,
                                ),
                                decoration: BoxDecoration(
                                  color: selected
                                      ? const Color(0xFFEAF4FF)
                                      : Colors.white,
                                  borderRadius: BorderRadius.circular(15),
                                  border: Border.all(
                                    color: selected
                                        ? astroBlue
                                        : const Color(0xFFDDE5EF),
                                    width: selected ? 1.8 : 1,
                                  ),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Container(
                                      width: 25,
                                      height: 25,
                                      decoration: BoxDecoration(
                                        color: colorValue(color),
                                        shape: BoxShape.circle,
                                        border: Border.all(
                                          color: const Color(0xFFD1D8E1),
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    Text(
                                      color,
                                      style: const TextStyle(
                                        color: astroNavy,
                                        fontSize: 13,
                                        fontWeight: FontWeight.w800,
                                      ),
                                    ),
                                    if (selected) ...[
                                      const SizedBox(width: 5),
                                      const Icon(
                                        Icons.check_circle_rounded,
                                        color: astroBlue,
                                        size: 17,
                                      ),
                                    ],
                                  ],
                                ),
                              ),
                            );
                          }).toList(),
                        ),
                      ],
                      const SizedBox(height: 23),
                      _sectionTitle(
                        'وصف المنتج',
                        Icons.description_outlined,
                      ),
                      const SizedBox(height: 10),
                      Text(
                        product.description.trim().isEmpty
                            ? 'لا يوجد وصف متاح لهذا المنتج حالياً.'
                            : product.description,
                        textAlign: TextAlign.start,
                        style: const TextStyle(
                          color: Color(0xFF66758A),
                          fontSize: 14,
                          height: 1.85,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          _buildBottomBar(),
        ],
      ),
    );
  }

  Widget _buildHero(Product product) {
    return Container(
      height: 330,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: const Color(0xFFE7EEF7)),
      ),
      child: Stack(
        children: [
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFFF8FBFF), Color(0xFFEAF3FF)],
                ),
                borderRadius: BorderRadius.circular(20),
              ),
            ),
          ),
          Positioned(
            top: 12,
            right: 12,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              decoration: BoxDecoration(
                color: const Color(0xFFE0F0FF),
                borderRadius: BorderRadius.circular(18),
              ),
              child: Text(
                product.category,
                style: const TextStyle(
                  color: astroNavy,
                  fontWeight: FontWeight.w800,
                  fontSize: 11,
                ),
              ),
            ),
          ),
          Positioned.fill(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 35, 18, 20),
              child: product.imageUrl.trim().isEmpty
                  ? Center(
                      child: Icon(
                        _placeholderIcon(product.category),
                        size: 105,
                        color: astroNavy.withOpacity(.25),
                      ),
                    )
                  : Image.network(
                      product.imageUrl,
                      fit: BoxFit.contain,
                      errorBuilder: (_, __, ___) => Center(
                        child: Icon(
                          _placeholderIcon(product.category),
                          size: 105,
                          color: astroNavy.withOpacity(.25),
                        ),
                      ),
                      loadingBuilder: (context, child, progress) {
                        if (progress == null) return child;
                        return const Center(
                          child: CircularProgressIndicator(
                            color: astroBlue,
                            strokeWidth: 2,
                          ),
                        );
                      },
                    ),
            ),
          ),
          Positioned(
            bottom: 10,
            left: 10,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
              decoration: BoxDecoration(
                color: astroNavy.withOpacity(.62),
                borderRadius: BorderRadius.circular(18),
              ),
              child: const Text(
                'صورة المنتج',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionTitle(String title, IconData icon) {
    return Row(
      children: [
        Icon(icon, color: astroBlue, size: 20),
        const SizedBox(width: 8),
        Text(
          title,
          style: const TextStyle(
            color: astroNavy,
            fontSize: 16,
            fontWeight: FontWeight.w900,
          ),
        ),
      ],
    );
  }

  Widget _buildBottomBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 11, 14, 12),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: astroNavy.withOpacity(.07),
            blurRadius: 16,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Row(
          children: [
            Container(
              height: 54,
              padding: const EdgeInsets.symmetric(horizontal: 5),
              decoration: BoxDecoration(
                color: const Color(0xFFF5F8FC),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFFE0E8F2)),
              ),
              child: Row(
                children: [
                  IconButton(
                    visualDensity: VisualDensity.compact,
                    onPressed: quantity > 1
                        ? () => setState(() => quantity--)
                        : null,
                    icon: const Icon(Icons.remove_rounded),
                    color: astroNavy,
                  ),
                  SizedBox(
                    width: 25,
                    child: Text(
                      '$quantity',
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: astroNavy,
                        fontSize: 17,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                  IconButton(
                    visualDensity: VisualDensity.compact,
                    onPressed: () => setState(() => quantity++),
                    icon: const Icon(Icons.add_rounded),
                    color: astroBlue,
                  ),
                ],
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: SizedBox(
                height: 54,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: astroBlue,
                    foregroundColor: Colors.white,
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                  onPressed: _addToCart,
                  icon: const Icon(Icons.add_shopping_cart_rounded, size: 21),
                  label: const Text(
                    'أضف إلى السلة',
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  IconData _placeholderIcon(String category) {
    final value = category.toLowerCase();
    if (value.contains('هاتف') || value.contains('موبايل')) {
      return Icons.smartphone_rounded;
    }
    if (value.contains('لوح') || value.contains('تابلت')) {
      return Icons.tablet_android_rounded;
    }
    if (value.contains('كمال') || value.contains('سما')) {
      return Icons.headphones_rounded;
    }
    return Icons.devices_other_rounded;
  }
}

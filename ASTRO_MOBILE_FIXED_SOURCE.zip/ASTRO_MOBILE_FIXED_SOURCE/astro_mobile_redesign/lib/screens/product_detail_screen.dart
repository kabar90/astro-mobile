import 'package:flutter/material.dart';
import '../main.dart';
import '../models/product.dart';
import '../services/cart_service.dart';
import 'cart_screen.dart';

class ProductDetailScreen extends StatefulWidget {
  final Product product;

  const ProductDetailScreen({
    super.key,
    required this.product,
  });

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  String? selectedColor;
  int quantity = 1;
  int selectedImageIndex = 0;
  bool isFavorite = false;

  List<String> get gallery {
    final images = widget.product.images.isNotEmpty
        ? widget.product.images
        : widget.product.imageUrl.trim().isNotEmpty
            ? [widget.product.imageUrl.trim()]
            : <String>[];
    return images;
  }

  @override
  void initState() {
    super.initState();
    if (widget.product.colors.length == 1) {
      selectedColor = widget.product.colors.first;
    }
  }

  Color colorValue(String name) {
    final value = name.trim().toLowerCase();
    const colors = {
      'أسود': Color(0xFF222222),
      'اسود': Color(0xFF222222),
      'black': Color(0xFF222222),
      'أبيض': Color(0xFFF5F5F5),
      'ابيض': Color(0xFFF5F5F5),
      'white': Color(0xFFF5F5F5),
      'أزرق': Color(0xFF2865B5),
      'ازرق': Color(0xFF2865B5),
      'blue': Color(0xFF2865B5),
      'أخضر': Color(0xFF39845A),
      'اخضر': Color(0xFF39845A),
      'green': Color(0xFF39845A),
      'أحمر': Color(0xFFD83C3C),
      'احمر': Color(0xFFD83C3C),
      'red': Color(0xFFD83C3C),
      'ذهبي': Color(0xFFD6AE55),
      'gold': Color(0xFFD6AE55),
      'بنفسجي': Color(0xFF9470B8),
      'فضي': Color(0xFFC0C0C0),
      'رمادي': Color(0xFF888888),
      'وردي': Color(0xFFE99AB5),
    };
    return colors[value] ?? const Color(0xFFB8B8B8);
  }

  void _addToCart() {
    final product = widget.product;
    if (product.colors.isNotEmpty && selectedColor == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('يرجى اختيار لون المنتج أولاً')),
      );
      return;
    }

    if (product.stockQuantity != null &&
        product.stockQuantity! >= 0 &&
        quantity > product.stockQuantity!) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('الكمية المطلوبة غير متوفرة بالمخزون')),
      );
      return;
    }

    CartService.instance.add(product, selectedColor, quantity: quantity);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('تمت إضافة $quantity من ${product.name} إلى السلة'),
        action: SnackBarAction(
          label: 'عرض السلة',
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const CartScreen()),
            );
          },
        ),
      ),
    );
  }

  void _changeImage(int delta) {
    if (gallery.length < 2) return;
    setState(() {
      selectedImageIndex =
          (selectedImageIndex + delta + gallery.length) % gallery.length;
    });
  }

  @override
  Widget build(BuildContext context) {
    final product = widget.product;

    return Scaffold(
      backgroundColor: const Color(0xFFF1F6FD),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF1F6FD),
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        title: const Text(
          'تفاصيل المنتج',
          style: TextStyle(
            color: astroNavy,
            fontWeight: FontWeight.w900,
            fontSize: 20,
          ),
        ),
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.arrow_back_rounded, color: astroNavy),
        ),
        actions: [
          IconButton(
            tooltip: 'المفضلة',
            onPressed: () => setState(() => isFavorite = !isFavorite),
            icon: Icon(
              isFavorite
                  ? Icons.favorite_rounded
                  : Icons.favorite_border_rounded,
              color: isFavorite ? Colors.redAccent : astroNavy,
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(14, 4, 14, 20),
              children: [
                _buildGallery(product),
                const SizedBox(height: 12),
                _buildProductInformation(product),
              ],
            ),
          ),
          _buildBottomBar(product),
        ],
      ),
    );
  }

  Widget _buildGallery(Product product) {
    final count = gallery.length;
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(27),
        border: Border.all(color: const Color(0xFFE4ECF5)),
      ),
      child: Column(
        children: [
          SizedBox(
            height: 350,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(21),
              child: Stack(
                children: [
                  Positioned.fill(
                    child: DecoratedBox(
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [Color(0xFFF8FBFF), Color(0xFFEAF3FF)],
                        ),
                      ),
                    ),
                  ),
                  Positioned.fill(
                    child: gallery.isEmpty
                        ? Center(
                            child: Icon(
                              _placeholderIcon(product.category),
                              size: 112,
                              color: astroNavy.withOpacity(.25),
                            ),
                          )
                        : Image.network(
                            gallery[selectedImageIndex],
                            fit: BoxFit.contain,
                            errorBuilder: (_, __, ___) => Center(
                              child: Icon(
                                _placeholderIcon(product.category),
                                size: 112,
                                color: astroNavy.withOpacity(.25),
                              ),
                            ),
                            loadingBuilder: (context, child, progress) {
                              if (progress == null) return child;
                              return const Center(
                                child: CircularProgressIndicator(
                                  color: astroBlue,
                                  strokeWidth: 2,
                                ),
                              );
                            },
                          ),
                  ),
                  if (product.isNew)
                    Positioned(
                      top: 13,
                      left: 13,
                      child: _pill('جديد', background: const Color(0xFFE83D4D)),
                    ),
                  if ((product.brand ?? '').isNotEmpty)
                    Positioned(
                      top: 13,
                      right: 13,
                      child: _pill(
                        product.brand!.toUpperCase(),
                        background: astroNavy,
                        foreground: Colors.white,
                      ),
                    ),
                  if (count > 1) ...[
                    Positioned(
                      left: 10,
                      top: 0,
                      bottom: 0,
                      child: Center(
                        child: _galleryArrow(
                          Icons.chevron_left_rounded,
                          () => _changeImage(-1),
                        ),
                      ),
                    ),
                    Positioned(
                      right: 10,
                      top: 0,
                      bottom: 0,
                      child: Center(
                        child: _galleryArrow(
                          Icons.chevron_right_rounded,
                          () => _changeImage(1),
                        ),
                      ),
                    ),
                    Positioned(
                      bottom: 12,
                      right: 12,
                      child: _pill(
                        '${selectedImageIndex + 1} / $count',
                        background: const Color(0x99082C5C),
                        foreground: Colors.white,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
          if (count > 1) ...[
            const SizedBox(height: 10),
            SizedBox(
              height: 66,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: count,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (context, index) {
                  final selected = index == selectedImageIndex;
                  return GestureDetector(
                    onTap: () => setState(() => selectedImageIndex = index),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 160),
                      width: 66,
                      padding: const EdgeInsets.all(3),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(13),
                        border: Border.all(
                          color: selected
                              ? astroBlue
                              : const Color(0xFFE1E8F0),
                          width: selected ? 2 : 1,
                        ),
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(9),
                        child: Image.network(
                          gallery[index],
                          fit: BoxFit.contain,
                          errorBuilder: (_, __, ___) => const Icon(
                            Icons.image_not_supported_outlined,
                            color: Colors.black26,
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildProductInformation(Product product) {
    final hasRating = product.rating != null;
    final hasStock = product.stockQuantity != null;
    final specs = product.specifications;

    return Container(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(25),
        border: Border.all(color: const Color(0xFFE4ECF5)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              _pill(product.category, background: const Color(0xFFE4F2FF)),
              const Spacer(),
              if ((product.brand ?? '').isNotEmpty)
                Text(
                  product.brand!.toUpperCase(),
                  style: const TextStyle(
                    color: astroBlue,
                    fontWeight: FontWeight.w900,
                    fontSize: 16,
                    letterSpacing: 1,
                  ),
                ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            product.name,
            style: const TextStyle(
              color: astroNavy,
              fontSize: 25,
              fontWeight: FontWeight.w900,
              height: 1.2,
            ),
          ),
          if (hasRating) ...[
            const SizedBox(height: 7),
            Row(
              children: [
                const Icon(Icons.star_rounded,
                    color: Color(0xFFFFB928), size: 21),
                const SizedBox(width: 4),
                Text(
                  product.rating!.toStringAsFixed(1),
                  style: const TextStyle(
                    color: astroNavy,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                if (product.reviewCount != null) ...[
                  const SizedBox(width: 5),
                  Text(
                    '(${product.reviewCount} تقييم)',
                    style: const TextStyle(color: Colors.black45),
                  ),
                ],
              ],
            ),
          ],
          const SizedBox(height: 13),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              color: const Color(0xFFE7F3FF),
              borderRadius: BorderRadius.circular(17),
            ),
            child: Row(
              children: [
                Text(
                  '${product.price.toStringAsFixed(0)} د.ل',
                  style: const TextStyle(
                    color: astroNavy,
                    fontSize: 29,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const Spacer(),
                if (hasStock)
                  Row(
                    children: [
                      Icon(
                        product.stockQuantity! > 0
                            ? Icons.verified_rounded
                            : Icons.remove_circle_rounded,
                        color: product.stockQuantity! > 0
                            ? Colors.green
                            : Colors.redAccent,
                        size: 21,
                      ),
                      const SizedBox(width: 5),
                      Text(
                        product.stockQuantity! > 0
                            ? 'متوفر في المخزون'
                            : 'غير متوفر',
                        style: TextStyle(
                          color: product.stockQuantity! > 0
                              ? Colors.green.shade700
                              : Colors.redAccent,
                          fontSize: 12,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ],
                  ),
              ],
            ),
          ),
          if (product.colors.isNotEmpty) ...[
            const SizedBox(height: 22),
            _sectionTitle('اختر لون المنتج', Icons.layers_rounded),
            const SizedBox(height: 11),
            Wrap(
              spacing: 8,
              runSpacing: 9,
              children: product.colors.map((color) {
                final selected = selectedColor == color;
                return InkWell(
                  borderRadius: BorderRadius.circular(15),
                  onTap: () => setState(() => selectedColor = color),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 150),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 13,
                      vertical: 10,
                    ),
                    decoration: BoxDecoration(
                      color: selected
                          ? const Color(0xFFEAF4FF)
                          : const Color(0xFFFAFBFD),
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(
                        color: selected
                            ? astroBlue
                            : const Color(0xFFDDE5EF),
                        width: selected ? 2 : 1,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 25,
                          height: 25,
                          decoration: BoxDecoration(
                            color: colorValue(color),
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: const Color(0xFFD1D8E1),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          color,
                          style: const TextStyle(
                            color: astroNavy,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        if (selected) ...[
                          const SizedBox(width: 5),
                          const Icon(
                            Icons.check_circle_rounded,
                            color: astroBlue,
                            size: 17,
                          ),
                        ],
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),
          ],
          if (specs.isNotEmpty) ...[
            const SizedBox(height: 23),
            _sectionTitle('المواصفات الرئيسية', Icons.layers_outlined),
            const SizedBox(height: 11),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: specs.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 8,
                crossAxisSpacing: 8,
                childAspectRatio: 2.25,
              ),
              itemBuilder: (context, index) {
                final key = specs.keys.elementAt(index);
                final value = specs[key]!;
                return Container(
                  padding: const EdgeInsets.all(9),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF2F6FC),
                    borderRadius: BorderRadius.circular(13),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        key,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Color(0xFF718198),
                          fontSize: 11,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        value,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: astroNavy,
                          fontSize: 13,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ],
          const SizedBox(height: 22),
          _sectionTitle('وصف المنتج', Icons.description_outlined),
          const SizedBox(height: 9),
          Text(
            product.description.trim().isEmpty
                ? 'لا يوجد وصف متاح لهذا المنتج حالياً.'
                : product.description,
            textAlign: TextAlign.start,
            style: const TextStyle(
              color: Color(0xFF65758B),
              fontSize: 14,
              height: 1.8,
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionTitle(String title, IconData icon) {
    return Row(
      children: [
        Icon(icon, color: astroBlue, size: 20),
        const SizedBox(width: 8),
        Text(
          title,
          style: const TextStyle(
            color: astroNavy,
            fontSize: 16,
            fontWeight: FontWeight.w900,
          ),
        ),
      ],
    );
  }

  Widget _pill(
    String text, {
    required Color background,
    Color foreground = astroNavy,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: foreground,
          fontSize: 11,
          fontWeight: FontWeight.w900,
        ),
      ),
    );
  }

  Widget _galleryArrow(IconData icon, VoidCallback onTap) {
    return Material(
      color: Colors.white.withOpacity(.94),
      shape: const CircleBorder(),
      elevation: 2,
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: SizedBox(
          width: 39,
          height: 39,
          child: Icon(icon, color: astroNavy, size: 25),
        ),
      ),
    );
  }

  Widget _buildBottomBar(Product product) {
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 11),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: astroNavy.withOpacity(.08),
            blurRadius: 17,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Row(
          children: [
            Container(
              height: 55,
              padding: const EdgeInsets.symmetric(horizontal: 4),
              decoration: BoxDecoration(
                color: const Color(0xFFF5F7FB),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFFE0E7F0)),
              ),
              child: Row(
                children: [
                  IconButton(
                    visualDensity: VisualDensity.compact,
                    onPressed: quantity > 1
                        ? () => setState(() => quantity--)
                        : null,
                    icon: const Icon(Icons.remove_rounded),
                    color: astroNavy,
                  ),
                  SizedBox(
                    width: 23,
                    child: Text(
                      '$quantity',
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: astroNavy,
                        fontSize: 17,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                  IconButton(
                    visualDensity: VisualDensity.compact,
                    onPressed: product.stockQuantity != null &&
                            quantity >= product.stockQuantity!
                        ? null
                        : () => setState(() => quantity++),
                    icon: const Icon(Icons.add_rounded),
                    color: astroBlue,
                  ),
                ],
              ),
            ),
            const SizedBox(width: 9),
            Expanded(
              child: SizedBox(
                height: 55,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: astroBlue,
                    foregroundColor: Colors.white,
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                  onPressed: product.stockQuantity == 0 ? null : _addToCart,
                  icon: const Icon(Icons.add_shopping_cart_rounded, size: 21),
                  label: const Text(
                    'أضف إلى السلة',
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  IconData _placeholderIcon(String category) {
    final value = category.toLowerCase();
    if (value.contains('هاتف') || value.contains('موبايل')) {
      return Icons.smartphone_rounded;
    }
    if (value.contains('لوح') || value.contains('تابلت')) {
      return Icons.tablet_android_rounded;
    }
    if (value.contains('كمال') || value.contains('سما')) {
      return Icons.headphones_rounded;
    }
    return Icons.devices_other_rounded;
  }
}

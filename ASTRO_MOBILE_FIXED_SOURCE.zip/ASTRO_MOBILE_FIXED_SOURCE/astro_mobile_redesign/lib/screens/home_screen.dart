
import 'package:flutter/material.dart';
import '../main.dart';
import '../models/product.dart';
import '../services/product_repository.dart';
import '../services/cart_service.dart';
import 'cart_screen.dart';
import 'product_detail_screen.dart';
import 'notifications_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final search = TextEditingController();
  String category = 'الكل';
  int nav = 0;

  @override
  void dispose() {
    search.dispose();
    super.dispose();
  }

  void message(String value) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(value),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<Product>>(
      stream: ProductRepository.watchProducts(),
      builder: (context, snapshot) {
        final sourceProducts = snapshot.data ?? [];
        final q = search.text.trim().toLowerCase();

        final products = sourceProducts.where((p) {
          final matchesCategory =
              category == 'الكل' || p.category == category;

          final matchesSearch =
              '${p.name} ${p.category}'.toLowerCase().contains(q);

          return matchesCategory && matchesSearch;
        }).toList();

        return Scaffold(
          appBar: AppBar(
            title: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'ASTRO MOBILE',
                  style: TextStyle(
                    fontSize: 19,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1,
                  ),
                ),
                Text(
                  'كل ما تحتاجه من التقنية',
                  style: TextStyle(fontSize: 11, color: Colors.black45),
                ),
              ],
            ),
            actions: [
              _action(
                Icons.notifications_none_rounded,
                () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const NotificationsScreen(),
                  ),
                ),
              ),
              const SizedBox(width: 7),
              AnimatedBuilder(
                animation: CartService.instance,
                builder: (context, _) => Stack(
                  clipBehavior: Clip.none,
                  children: [
                    _action(
                      Icons.shopping_bag_outlined,
                      () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const CartScreen()),
                      ),
                    ),
                    if (CartService.instance.count > 0)
                      Positioned(
                        right: 0,
                        top: 0,
                        child: Container(
                          padding: const EdgeInsets.all(4),
                          decoration: const BoxDecoration(
                            color: astroGold,
                            shape: BoxShape.circle,
                          ),
                          child: Text(
                            '${CartService.instance.count}',
                            style: const TextStyle(
                              color: astroNavy,
                              fontSize: 9,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(width: 14),
            ],
          ),

          body: CustomScrollView(
            slivers: [
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(18, 8, 18, 16),
                  child: Container(
                    height: 52,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(
                        color: const Color(0xFFE8EBF0),
                      ),
                    ),
                    child: TextField(
                      controller: search,
                      onChanged: (_) => setState(() {}),
                      decoration: const InputDecoration(
                        hintText: 'ابحث عن هاتف أو إكسسوار...',
                        hintStyle: TextStyle(
                          fontSize: 13,
                          color: Colors.black38,
                        ),
                        prefixIcon: Icon(
                          Icons.search,
                          color: astroGold,
                        ),
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(vertical: 15),
                      ),
                    ),
                  ),
                ),
              ),

              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 18),
                  child: Container(
                    height: 174,
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(22),
                      gradient: const LinearGradient(
                        colors: [
                          Color(0xFF101D35),
                          Color(0xFF24466F),
                        ],
                        begin: Alignment.topRight,
                        end: Alignment.bottomLeft,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: astroNavy.withOpacity(.15),
                          blurRadius: 16,
                          offset: const Offset(0, 7),
                        ),
                      ],
                    ),
                    child: Stack(
                      children: [
                        Positioned(
                          left: -5,
                          bottom: -20,
                          child: Icon(
                            Icons.phone_iphone_rounded,
                            size: 130,
                            color: Colors.white.withOpacity(.08),
                          ),
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 5,
                              ),
                              decoration: BoxDecoration(
                                color: astroGold.withOpacity(.18),
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(
                                  color: astroGold.withOpacity(.5),
                                ),
                              ),
                              child: const Text(
                                'ASTRO MOBILE',
                                style: TextStyle(
                                  color: Color(0xFFE8D4A8),
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            const SizedBox(height: 12),
                            const Text(
                              'تقنيتك تبدأ من هنا',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 22,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                            const SizedBox(height: 6),
                            const Text(
                              'هواتف وإكسسوارات مختارة بعناية',
                              style: TextStyle(
                                color: Colors.white70,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              SliverToBoxAdapter(
                child: SizedBox(
                  height: 94,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.fromLTRB(18, 18, 18, 8),
                    children: [
                      _category('الكل', Icons.grid_view_rounded),
                      _category('هواتف', Icons.smartphone_rounded),
                      _category('كماليات', Icons.headphones_rounded),
                      InkWell(
                        onTap: () => message(
                          'قسم المستعمل سيُضاف عند تجهيز منتجاته',
                        ),
                        child: _categoryTile(
                          'مستعمل',
                          Icons.phone_android_rounded,
                          false,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(18, 20, 18, 12),
                  child: Row(
                    children: [
                      const Expanded(
                        child: Text(
                          'اختيارات ASTRO',
                          style: TextStyle(
                            fontSize: 19,
                            fontWeight: FontWeight.w900,
                            color: astroNavy,
                          ),
                        ),
                      ),
                      Text(
                        '${products.length} منتجات',
                        style: const TextStyle(
                          fontSize: 12,
                          color: Colors.black45,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              if (snapshot.connectionState == ConnectionState.waiting &&
                  !snapshot.hasData)
                const SliverToBoxAdapter(
                  child: Padding(
                    padding: EdgeInsets.all(45),
                    child: Center(
                      child: CircularProgressIndicator(
                        color: astroGold,
                      ),
                    ),
                  ),
                )
              else if (snapshot.hasError)
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.all(30),
                    child: Center(
                      child: Column(
                        children: [
                          const Icon(
                            Icons.cloud_off_rounded,
                            size: 48,
                            color: Colors.black38,
                          ),
                          const SizedBox(height: 12),
                          const Text(
                            'تعذر الاتصال بالمتجر حالياً',
                            style: TextStyle(
                              color: astroNavy,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 8),
                          const Text(
                            'يرجى التأكد من اتصال الإنترنت والمحاولة مجدداً.',
                            textAlign: TextAlign.center,
                            style: TextStyle(color: Colors.black45),
                          ),
                          TextButton(
                            onPressed: () => setState(() {}),
                            child: const Text('إعادة المحاولة'),
                          ),
                        ],
                      ),
                    ),
                  ),
                )
              else if (products.isEmpty)
                const SliverToBoxAdapter(
                  child: Padding(
                    padding: EdgeInsets.all(35),
                    child: Center(
                      child: Column(
                        children: [
                          Icon(
                            Icons.inventory_2_outlined,
                            size: 48,
                            color: Colors.black38,
                          ),
                          SizedBox(height: 12),
                          Text(
                            'لا توجد منتجات متاحة حالياً',
                            style: TextStyle(
                              color: astroNavy,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                )
              else
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 22),
                  sliver: SliverGrid(
                    delegate: SliverChildBuilderDelegate(
                      (context, index) => _product(products[index]),
                      childCount: products.length,
                    ),
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      mainAxisSpacing: 14,
                      crossAxisSpacing: 14,
                      childAspectRatio: .66,
                    ),
                  ),
                ),
            ],
          ),

          bottomNavigationBar: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(.06),
                  blurRadius: 12,
                  offset: const Offset(0, -3),
                ),
              ],
            ),
            child: SafeArea(
              top: false,
              child: SizedBox(
                height: 64,
                child: Row(
                  children: [
                    _navItem(0, Icons.storefront_rounded, 'المتجر'),
                    _navItem(1, Icons.category_rounded, 'الأقسام'),
                    _navItem(2, Icons.shopping_cart_outlined, 'السلة'),
                    _navItem(3, Icons.person_outline_rounded, 'حسابي'),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _action(IconData icon, VoidCallback tap) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Material(
        color: Colors.white,
        shape: const CircleBorder(),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: tap,
          child: SizedBox(
            width: 40,
            height: 40,
            child: Icon(icon, color: astroNavy, size: 21),
          ),
        ),
      ),
    );
  }

  Widget _category(String label, IconData icon) {
    return Padding(
      padding: const EdgeInsets.only(left: 9),
      child: _categoryTile(label, icon, category == label),
    );
  }

  Widget _categoryTile(
    String label,
    IconData icon,
    bool selected,
  ) {
    return InkWell(
      borderRadius: BorderRadius.circular(15),
      onTap: () => setState(() {
        category = label == 'مستعمل' ? 'الكل' : label;
      }),
      child: Container(
        width: 76,
        decoration: BoxDecoration(
          color: selected ? astroNavy : Colors.white,
          borderRadius: BorderRadius.circular(15),
          border: Border.all(
            color: selected
                ? astroNavy
                : const Color(0xFFE8EBF0),
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              size: 21,
              color: selected ? astroGold : astroNavy,
            ),
            const SizedBox(height: 6),
            Text(
              label,
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.bold,
                color: selected ? Colors.white : astroNavy,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _product(Product p) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => ProductDetailScreen(product: p),
            ),
          );
        },
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: const Color(0xFFEDEFF3),
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Stack(
                  children: [
                    ClipRRect(
                      borderRadius: const BorderRadius.vertical(
                        top: Radius.circular(18),
                      ),
                      child: SizedBox(
                        width: double.infinity,
                        child: p.imageUrl.isEmpty
                            ? _placeholder(p.category, false)
                            : Image.network(
                                p.imageUrl,
                                fit: BoxFit.contain,
                                loadingBuilder: (context, child, progress) {
                                  if (progress == null) return child;
                                  return _placeholder(p.category, true);
                                },
                                errorBuilder: (_, __, ___) =>
                                    _placeholder(p.category, false),
                              ),
                      ),
                    ),
                    Positioned(
                      top: 9,
                      right: 9,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 9,
                          vertical: 5,
                        ),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF5EBD7),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          p.category,
                          style: const TextStyle(
                            fontSize: 10,
                            color: astroNavy,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(11, 9, 11, 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      p.name,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 13,
                        height: 1.25,
                        fontWeight: FontWeight.w800,
                        color: astroNavy,
                      ),
                    ),
                    const SizedBox(height: 9),
                    Text(
                      '${p.price.toStringAsFixed(0)} د.ل',
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w900,
                        color: astroNavy,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _placeholder(String cat, bool loading) {
    return Container(
      color: const Color(0xFFF2F4F7),
      child: Center(
        child: loading
            ? const SizedBox(
                width: 22,
                height: 22,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: astroGold,
                ),
              )
            : Icon(
                cat == 'هواتف'
                    ? Icons.smartphone_rounded
                    : Icons.headphones_rounded,
                size: 55,
                color: astroNavy.withOpacity(.3),
              ),
      ),
    );
  }

  Widget _navItem(int i, IconData icon, String label) {
    final active = nav == i;

    return Expanded(
      child: InkWell(
        onTap: () {
          setState(() => nav = i);

          if (i == 2) {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const CartScreen()),
            );
          } else if (i != 0) {
            message(
              i == 1
                  ? 'الأقسام تظهر في أعلى المتجر'
                  : 'حساب العميل سيُضاف لاحقاً',
            );
          }
        },
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              color: active ? astroGold : Colors.black38,
              size: 22,
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(
                fontSize: 10,
                color: active ? astroNavy : Colors.black45,
                fontWeight:
                    active ? FontWeight.bold : FontWeight.normal,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

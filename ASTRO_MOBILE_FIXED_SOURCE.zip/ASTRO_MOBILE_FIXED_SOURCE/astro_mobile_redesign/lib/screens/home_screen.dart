
import 'package:flutter/material.dart';
import '../main.dart';
import '../models/product.dart';
import '../services/product_repository.dart';
import '../services/cart_service.dart';
import 'cart_screen.dart';
import 'product_detail_screen.dart';
import 'notifications_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final search = TextEditingController();
  String category = 'الكل';
  int? selectedCategoryId;
  int? selectedSubcategoryId;
  int? categoryPageRootId;
  int? categoryPageSubcategoryId;
  int nav = 0;

  @override
  void dispose() {
    search.dispose();
    super.dispose();
  }

  void message(String value) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(value),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<StoreCategory>>(
      stream: ProductRepository.watchCategories(),
      builder: (context, categorySnapshot) {
        final categories = categorySnapshot.data ?? [];
        final rootCategories = categories
            .where((item) => item.parentId == null && item.isActive)
            .toList()
          ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder));

        StoreCategory? selectedRoot;
        for (final item in categories) {
          if (item.id == selectedCategoryId) {
            selectedRoot = item;
            break;
          }
        }

        final selectedRootId = selectedRoot?.id;
        final selectedRootName = selectedRoot?.name;
        final subcategories = selectedRootId == null
            ? <StoreCategory>[]
            : (categories
                .where((item) =>
                    item.parentId == selectedRootId && item.isActive)
                .toList()
              ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder)));

        return StreamBuilder<List<Product>>(
          stream: ProductRepository.watchProducts(),
          builder: (context, snapshot) {
            final sourceProducts = snapshot.data ?? [];
            final q = search.text.trim().toLowerCase();

            final products = sourceProducts.where((p) {
              final matchesRoot = selectedRootName == null ||
                  p.category == selectedRootName;
              final matchesSubcategory = selectedSubcategoryId == null ||
                  p.subcategoryId == selectedSubcategoryId;
              final matchesSearch =
                  '${p.name} ${p.category}'.toLowerCase().contains(q);

              return matchesRoot && matchesSubcategory && matchesSearch;
            }).toList();

            return Scaffold(
          appBar: AppBar(
            title: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(9),
                  child: Image.asset(
                    'assets/astro-logo.jpg',
                    width: 46,
                    height: 46,
                    fit: BoxFit.contain,
                    errorBuilder: (_, __, ___) => const Icon(
                      Icons.smartphone_rounded,
                      size: 38,
                      color: astroBlue,
                    ),
                  ),
                ),
                const SizedBox(width: 9),
                const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'ASTRO MOBILE',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        letterSpacing: .5,
                        color: astroNavy,
                      ),
                    ),
                    Text(
                      'كل ما تحتاجه من التقنية',
                      style: TextStyle(fontSize: 10, color: Colors.black45),
                    ),
                  ],
                ),
              ],
            ),
            actions: [
              _action(
                Icons.notifications_none_rounded,
                () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const NotificationsScreen(),
                  ),
                ),
              ),
              const SizedBox(width: 7),
              AnimatedBuilder(
                animation: CartService.instance,
                builder: (context, _) => Stack(
                  clipBehavior: Clip.none,
                  children: [
                    _action(
                      Icons.shopping_bag_outlined,
                      () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const CartScreen()),
                      ),
                    ),
                    if (CartService.instance.count > 0)
                      Positioned(
                        right: 0,
                        top: 0,
                        child: Container(
                          padding: const EdgeInsets.all(4),
                          decoration: const BoxDecoration(
                            color: astroGold,
                            shape: BoxShape.circle,
                          ),
                          child: Text(
                            '${CartService.instance.count}',
                            style: const TextStyle(
                              color: astroNavy,
                              fontSize: 9,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(width: 14),
            ],
          ),

          body: nav == 1
              ? _buildCategoriesPage(
                  rootCategories: rootCategories,
                  categories: categories,
                  products: sourceProducts,
                )
              : CustomScrollView(
            slivers: [
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(18, 8, 18, 16),
                  child: Container(
                    height: 52,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(
                        color: const Color(0xFFE8EBF0),
                      ),
                    ),
                    child: TextField(
                      controller: search,
                      onChanged: (_) => setState(() {}),
                      decoration: const InputDecoration(
                        hintText: 'ابحث عن هاتف أو إكسسوار...',
                        hintStyle: TextStyle(
                          fontSize: 13,
                          color: Colors.black38,
                        ),
                        prefixIcon: Icon(
                          Icons.search,
                          color: astroGold,
                        ),
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(vertical: 15),
                      ),
                    ),
                  ),
                ),
              ),

              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 18),
                  child: Container(
                    height: 174,
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(22),
                      gradient: const LinearGradient(
                        colors: [
                          Color(0xFF082C5C),
                          Color(0xFF087FE5),
                        ],
                        begin: Alignment.topRight,
                        end: Alignment.bottomLeft,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: astroNavy.withOpacity(.15),
                          blurRadius: 16,
                          offset: const Offset(0, 7),
                        ),
                      ],
                    ),
                    child: Stack(
                      children: [
                        Positioned(
                          left: -5,
                          bottom: -20,
                          child: Icon(
                            Icons.phone_iphone_rounded,
                            size: 130,
                            color: Colors.white.withOpacity(.08),
                          ),
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 5,
                              ),
                              decoration: BoxDecoration(
                                color: astroGold.withOpacity(.18),
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(
                                  color: astroGold.withOpacity(.5),
                                ),
                              ),
                              child: const Text(
                                'ASTRO MOBILE',
                                style: TextStyle(
                                  color: Color(0xFFBDEBFF),
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            const SizedBox(height: 12),
                            const Text(
                              'تقنيتك تبدأ من هنا',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 22,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                            const SizedBox(height: 6),
                            const Text(
                              'هواتف وإكسسوارات مختارة بعناية',
                              style: TextStyle(
                                color: Colors.white70,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(18, 18, 18, 4),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Expanded(
                            child: Text(
                              'تصفح الأقسام',
                              style: TextStyle(
                                color: astroNavy,
                                fontSize: 15,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ),
                          if (categorySnapshot.connectionState ==
                              ConnectionState.waiting)
                            const SizedBox(
                              width: 15,
                              height: 15,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: astroBlue,
                              ),
                            ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      SizedBox(
                        height: 40,
                        child: ListView(
                          scrollDirection: Axis.horizontal,
                          children: [
                            _categoryChip(
                              'الكل',
                              selectedCategoryId == null,
                              () => setState(() {
                                category = 'الكل';
                                selectedCategoryId = null;
                                selectedSubcategoryId = null;
                              }),
                            ),
                            ...rootCategories.map(
                              (item) => _categoryChip(
                                item.name,
                                selectedCategoryId == item.id,
                                () => setState(() {
                                  category = item.name;
                                  selectedCategoryId = item.id;
                                  selectedSubcategoryId = null;
                                }),
                              ),
                            ),
                          ],
                        ),
                      ),
                      if (selectedRoot != null && subcategories.isNotEmpty) ...[
                        const SizedBox(height: 12),
                        Text(
                          'الأقسام الفرعية في ${selectedRoot.name}',
                          style: const TextStyle(
                            color: Colors.black54,
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 7),
                        SizedBox(
                          height: 36,
                          child: ListView(
                            scrollDirection: Axis.horizontal,
                            children: [
                              _subcategoryChip(
                                'كل ${selectedRoot.name}',
                                selectedSubcategoryId == null,
                                () => setState(() {
                                  selectedSubcategoryId = null;
                                }),
                              ),
                              ...subcategories.map(
                                (item) => _subcategoryChip(
                                  item.name,
                                  selectedSubcategoryId == item.id,
                                  () => setState(() {
                                    selectedSubcategoryId = item.id;
                                  }),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                      if (categorySnapshot.hasError)
                        Padding(
                          padding: const EdgeInsets.only(top: 8),
                          child: Text(
                            'تعذر تحميل الأقسام: ${categorySnapshot.error}',
                            style: const TextStyle(
                              color: Colors.red,
                              fontSize: 11,
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),

              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(18, 20, 18, 12),
                  child: Row(
                    children: [
                      const Expanded(
                        child: Text(
                          'اختيارات ASTRO',
                          style: TextStyle(
                            fontSize: 19,
                            fontWeight: FontWeight.w900,
                            color: astroNavy,
                          ),
                        ),
                      ),
                      Text(
                        '${products.length} منتجات',
                        style: const TextStyle(
                          fontSize: 12,
                          color: Colors.black45,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              if (snapshot.connectionState == ConnectionState.waiting &&
                  !snapshot.hasData)
                const SliverToBoxAdapter(
                  child: Padding(
                    padding: EdgeInsets.all(45),
                    child: Center(
                      child: CircularProgressIndicator(
                        color: astroGold,
                      ),
                    ),
                  ),
                )
              else if (snapshot.hasError)
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.all(30),
                    child: Center(
                      child: Column(
                        children: [
                          const Icon(
                            Icons.cloud_off_rounded,
                            size: 48,
                            color: Colors.black38,
                          ),
                          const SizedBox(height: 12),
                          const Text(
                            'تعذر الاتصال بالمتجر حالياً',
                            style: TextStyle(
                              color: astroNavy,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 8),
                          const Text(
                            'يرجى التأكد من اتصال الإنترنت والمحاولة مجدداً.',
                            textAlign: TextAlign.center,
                            style: TextStyle(color: Colors.black45),
                          ),
                          TextButton(
                            onPressed: () => setState(() {}),
                            child: const Text('إعادة المحاولة'),
                          ),
                        ],
                      ),
                    ),
                  ),
                )
              else if (products.isEmpty)
                const SliverToBoxAdapter(
                  child: Padding(
                    padding: EdgeInsets.all(35),
                    child: Center(
                      child: Column(
                        children: [
                          Icon(
                            Icons.inventory_2_outlined,
                            size: 48,
                            color: Colors.black38,
                          ),
                          SizedBox(height: 12),
                          Text(
                            'لا توجد منتجات متاحة حالياً',
                            style: TextStyle(
                              color: astroNavy,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                )
              else
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 22),
                  sliver: SliverGrid(
                    delegate: SliverChildBuilderDelegate(
                      (context, index) => _product(products[index]),
                      childCount: products.length,
                    ),
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      mainAxisSpacing: 14,
                      crossAxisSpacing: 14,
                      childAspectRatio: .66,
                    ),
                  ),
                ),
            ],
          ),

          bottomNavigationBar: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(.06),
                  blurRadius: 12,
                  offset: const Offset(0, -3),
                ),
              ],
            ),
            child: SafeArea(
              top: false,
              child: SizedBox(
                height: 64,
                child: Row(
                  children: [
                    _navItem(0, Icons.storefront_rounded, 'المتجر'),
                    _navItem(1, Icons.category_rounded, 'الأقسام'),
                    _navItem(2, Icons.shopping_cart_outlined, 'السلة'),
                    _navItem(3, Icons.person_outline_rounded, 'حسابي'),
                  ],
                ),
              ),
            ),
          ),
        );
          },
        );
      },
    );
  }

  Widget _action(IconData icon, VoidCallback tap) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Material(
        color: Colors.white,
        shape: const CircleBorder(),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: tap,
          child: SizedBox(
            width: 40,
            height: 40,
            child: Icon(icon, color: astroNavy, size: 21),
          ),
        ),
      ),
    );
  }

  Widget _categoryChip(
    String label,
    bool selected,
    VoidCallback onTap,
  ) {
    return Padding(
      padding: const EdgeInsetsDirectional.only(end: 8),
      child: Material(
        color: selected ? astroNavy : Colors.white,
        borderRadius: BorderRadius.circular(22),
        child: InkWell(
          borderRadius: BorderRadius.circular(22),
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 17, vertical: 9),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              border: Border.all(
                color: selected ? astroNavy : const Color(0xFFE1E8F0),
              ),
            ),
            child: Text(
              label,
              style: TextStyle(
                color: selected ? Colors.white : astroNavy,
                fontSize: 12,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _subcategoryChip(
    String label,
    bool selected,
    VoidCallback onTap,
  ) {
    return Padding(
      padding: const EdgeInsetsDirectional.only(end: 7),
      child: Material(
        color: selected ? const Color(0xFFDCEEFF) : Colors.white,
        borderRadius: BorderRadius.circular(18),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                color: selected ? astroBlue : const Color(0xFFE5EBF2),
              ),
            ),
            child: Text(
              label,
              style: TextStyle(
                color: selected ? astroBlue : astroNavy,
                fontSize: 11,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _product(Product p) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => ProductDetailScreen(product: p),
            ),
          );
        },
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: const Color(0xFFEDEFF3),
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Stack(
                  children: [
                    ClipRRect(
                      borderRadius: const BorderRadius.vertical(
                        top: Radius.circular(18),
                      ),
                      child: SizedBox(
                        width: double.infinity,
                        child: p.imageUrl.isEmpty
                            ? _placeholder(p.category, false)
                            : Image.network(
                                p.imageUrl,
                                fit: BoxFit.contain,
                                loadingBuilder: (context, child, progress) {
                                  if (progress == null) return child;
                                  return _placeholder(p.category, true);
                                },
                                errorBuilder: (_, __, ___) =>
                                    _placeholder(p.category, false),
                              ),
                      ),
                    ),
                    Positioned(
                      top: 9,
                      right: 9,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 9,
                          vertical: 5,
                        ),
                        decoration: BoxDecoration(
                          color: const Color(0xFFE6F4FF),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          p.category,
                          style: const TextStyle(
                            fontSize: 10,
                            color: astroNavy,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(11, 9, 11, 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      p.name,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 13,
                        height: 1.25,
                        fontWeight: FontWeight.w800,
                        color: astroNavy,
                      ),
                    ),
                    const SizedBox(height: 9),
                    Text(
                      '${p.price.toStringAsFixed(0)} د.ل',
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w900,
                        color: astroNavy,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _placeholder(String cat, bool loading) {
    return Container(
      color: const Color(0xFFF2F4F7),
      child: Center(
        child: loading
            ? const SizedBox(
                width: 22,
                height: 22,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: astroGold,
                ),
              )
            : Icon(
                cat == 'هواتف'
                    ? Icons.smartphone_rounded
                    : Icons.headphones_rounded,
                size: 55,
                color: astroNavy.withOpacity(.3),
              ),
      ),
    );
  }

  Widget _buildCategoriesPage({
    required List<StoreCategory> rootCategories,
    required List<StoreCategory> categories,
    required List<Product> products,
  }) {
    StoreCategory? selectedRoot;
    for (final item in rootCategories) {
      if (item.id == categoryPageRootId) {
        selectedRoot = item;
        break;
      }
    }

    final subcategories = selectedRoot == null
        ? <StoreCategory>[]
        : (categories
            .where((item) =>
                item.parentId == selectedRoot!.id && item.isActive)
            .toList()
          ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder)));

    final visibleProducts = selectedRoot == null
        ? <Product>[]
        : products.where((product) {
            final matchesRoot = product.category == selectedRoot!.name;
            final matchesSubcategory = categoryPageSubcategoryId == null ||
                product.subcategoryId == categoryPageSubcategoryId;
            return matchesRoot && matchesSubcategory;
          }).toList();

    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 22, 18, 12),
            child: Row(
              children: [
                if (selectedRoot != null)
                  IconButton(
                    tooltip: 'العودة إلى جميع الأقسام',
                    onPressed: () => setState(() {
                      categoryPageRootId = null;
                      categoryPageSubcategoryId = null;
                    }),
                    icon: const Icon(Icons.arrow_forward_rounded,
                        color: astroNavy),
                  ),
                Expanded(
                  child: Text(
                    selectedRoot == null ? 'جميع الأقسام' : selectedRoot.name,
                    style: const TextStyle(
                      color: astroNavy,
                      fontSize: 21,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
                if (selectedRoot != null)
                  TextButton(
                    onPressed: () => setState(() {
                      categoryPageSubcategoryId = null;
                    }),
                    child: const Text('كل المنتجات'),
                  ),
              ],
            ),
          ),
        ),
        if (selectedRoot == null)
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
            sliver: SliverGrid(
              delegate: SliverChildBuilderDelegate(
                (context, index) {
                  final item = rootCategories[index];
                  final childCount = categories
                      .where((category) =>
                          category.parentId == item.id && category.isActive)
                      .length;
                  return Material(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(18),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(18),
                      onTap: () => setState(() {
                        categoryPageRootId = item.id;
                        categoryPageSubcategoryId = null;
                      }),
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: const Color(0xFFE1E8F0)),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Icon(Icons.grid_view_rounded,
                                color: astroBlue, size: 30),
                            const SizedBox(height: 10),
                            Text(
                              item.name,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                color: astroNavy,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                            const SizedBox(height: 5),
                            Text(
                              childCount == 0
                                  ? 'تصفح المنتجات'
                                  : '$childCount أقسام فرعية',
                              style: const TextStyle(
                                color: Colors.black54,
                                fontSize: 11,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
                childCount: rootCategories.length,
              ),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 1.35,
              ),
            ),
          )
        else ...[
          if (subcategories.isNotEmpty)
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                child: Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _subcategoryChip(
                      'الكل',
                      categoryPageSubcategoryId == null,
                      () => setState(() => categoryPageSubcategoryId = null),
                    ),
                    ...subcategories.map(
                      (item) => _subcategoryChip(
                        item.name,
                        categoryPageSubcategoryId == item.id,
                        () => setState(
                            () => categoryPageSubcategoryId = item.id),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 12, 18, 10),
              child: Row(
                children: [
                  const Expanded(
                    child: Text(
                      'المنتجات',
                      style: TextStyle(
                        color: astroNavy,
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                  Text(
                    '${visibleProducts.length} منتجات',
                    style: const TextStyle(
                        color: Colors.black45, fontSize: 12),
                  ),
                ],
              ),
            ),
          ),
          if (visibleProducts.isEmpty)
            const SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.all(28),
                child: Center(
                  child: Text(
                    'لا توجد منتجات في هذا القسم حالياً',
                    style: TextStyle(color: Colors.black54),
                  ),
                ),
              ),
            )
          else
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              sliver: SliverGrid(
                delegate: SliverChildBuilderDelegate(
                  (context, index) => _product(visibleProducts[index]),
                  childCount: visibleProducts.length,
                ),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 14,
                  crossAxisSpacing: 14,
                  childAspectRatio: .66,
                ),
              ),
            ),
        ],
      ],
    );
  }

  Widget _navItem(int i, IconData icon, String label) {
    final active = nav == i;

    return Expanded(
      child: InkWell(
        onTap: () {
          if (i == 2) {
            setState(() => nav = 0);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const CartScreen()),
            );
          } else if (i == 1) {
            setState(() {
              nav = 1;
              categoryPageRootId = null;
              categoryPageSubcategoryId = null;
            });
          } else if (i == 0) {
            setState(() => nav = 0);
          } else {
            setState(() => nav = 3);
            message('حساب العميل سيُضاف لاحقاً');
          }
        },
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              color: active ? astroGold : Colors.black38,
              size: 22,
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(
                fontSize: 10,
                color: active ? astroNavy : Colors.black45,
                fontWeight:
                    active ? FontWeight.bold : FontWeight.normal,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

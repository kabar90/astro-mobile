import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../main.dart';
import '../services/cart_service.dart';
import 'bank_transfer_screen.dart';

class CheckoutScreen extends StatefulWidget {
  const CheckoutScreen({super.key});

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _address = TextEditingController();
  final _db = Supabase.instance.client;

  String _payment = 'cash';
  String _delivery = 'delivery';
  bool _busy = false;

  Future<void> _submit() async {
    final cart = CartService.instance;

    if (cart.items.isEmpty) {
      _message('السلة فارغة');
      return;
    }
    if (_name.text.trim().isEmpty || _phone.text.trim().isEmpty) {
      _message('يرجى إدخال الاسم ورقم الهاتف');
      return;
    }
    if (_delivery == 'delivery' && _address.text.trim().isEmpty) {
      _message('يرجى إدخال عنوان التوصيل');
      return;
    }

    // التحويل المصرفي يفتح صفحة مستقلة لعرض بيانات الحساب
    // وإرفاق إيصال التحويل ثم إرسال الطلب.
    if (_payment == 'transfer') {
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => BankTransferScreen(
            customerName: _name.text.trim(),
            customerPhone: _phone.text.trim(),
            customerAddress:
                _delivery == 'pickup' ? '' : _address.text.trim(),
            deliveryMethod: _delivery,
          ),
        ),
      );
      return;
    }

    setState(() => _busy = true);
    try {
      final items = cart.items.map((item) => {
        'product_id': item.product.id,
        'product_name': item.product.name,
        'quantity': item.quantity,
        'unit_price': item.product.price,
        'color': item.color,
      }).toList();

      final result = await _db.rpc('astro_create_order', params: {
        'p_customer_name': _name.text.trim(),
        'p_customer_phone': _phone.text.trim(),
        'p_customer_address':
            _delivery == 'pickup' ? '' : _address.text.trim(),
        'p_delivery_method': _delivery,
        'p_payment_method': 'cash',
        'p_total_price': cart.total,
        'p_items': items,
        'p_receipt_path': null,
      });

      cart.clear();
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) => AlertDialog(
          title: const Text('تم استلام طلبك بنجاح'),
          content: Text('رقم الطلب: $result\nسنتواصل معك لتأكيد الطلب.'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(dialogContext).pop();
                Navigator.of(context).popUntil((route) => route.isFirst);
              },
              child: const Text('حسناً'),
            ),
          ],
        ),
      );
    } catch (e) {
      if (mounted) _message('تعذر إرسال الطلب: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _message(String value) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(value)),
    );
  }

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _address.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: astroBackground,
      appBar: AppBar(title: const Text('إتمام الطلب')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          _field('الاسم الكامل', _name),
          _field('رقم الهاتف', _phone, keyboard: TextInputType.phone),
          if (_delivery == 'delivery')
            _field('العنوان / المدينة', _address),
          const SizedBox(height: 12),
          const Text('طريقة الاستلام',
              style: TextStyle(fontWeight: FontWeight.bold)),
          RadioListTile<String>(
            value: 'delivery',
            groupValue: _delivery,
            title: const Text('توصيل إلى العنوان'),
            onChanged: (value) => setState(() => _delivery = value!),
          ),
          RadioListTile<String>(
            value: 'pickup',
            groupValue: _delivery,
            title: const Text('استلام من المحل'),
            onChanged: (value) => setState(() => _delivery = value!),
          ),
          const Divider(),
          const Text('طريقة الدفع',
              style: TextStyle(fontWeight: FontWeight.bold)),
          RadioListTile<String>(
            value: 'cash',
            groupValue: _payment,
            title: const Text('نقداً عند الاستلام'),
            onChanged: (value) => setState(() => _payment = value!),
          ),
          RadioListTile<String>(
            value: 'transfer',
            groupValue: _payment,
            title: const Text('تحويل مصرفي – مصرف شمال أفريقيا'),
            subtitle: const Text('ستظهر بيانات الحساب في الصفحة التالية'),
            onChanged: (value) => setState(() => _payment = value!),
          ),
          const SizedBox(height: 18),
          Text(
            'الإجمالي: ${CartService.instance.total.toStringAsFixed(2)} د.ل',
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 18),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _busy ? null : _submit,
              style: ElevatedButton.styleFrom(
                backgroundColor: astroNavy,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.all(16),
              ),
              child: Text(_busy ? 'جارٍ إرسال الطلب...' : 'متابعة'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _field(
    String label,
    TextEditingController controller, {
    TextInputType? keyboard,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        keyboardType: keyboard,
        decoration: InputDecoration(
          labelText: label,
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
    );
  }
}

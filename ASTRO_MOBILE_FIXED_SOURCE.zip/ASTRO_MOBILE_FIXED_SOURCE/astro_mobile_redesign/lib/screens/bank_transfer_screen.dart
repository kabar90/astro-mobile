import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../main.dart';
import '../services/cart_service.dart';

class BankTransferScreen extends StatefulWidget {
  final String customerName;
  final String customerPhone;
  final String customerAddress;
  final String deliveryMethod;

  const BankTransferScreen({
    super.key,
    required this.customerName,
    required this.customerPhone,
    required this.customerAddress,
    required this.deliveryMethod,
  });

  @override
  State<BankTransferScreen> createState() => _BankTransferScreenState();
}

class _BankTransferScreenState extends State<BankTransferScreen> {
  final _db = Supabase.instance.client;
  Map<String, dynamic>? _bank;
  XFile? _receipt;
  bool _loading = true;
  bool _sending = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadBankDetails();
  }

  Future<void> _loadBankDetails() async {
    try {
      final data = await _db.from('bank_transfer_settings')
          .select().eq('id', 1).maybeSingle();
      if (!mounted) return;
      setState(() {
        _bank = data;
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _error = 'تعذر تحميل بيانات الحساب المصرفي';
        _loading = false;
      });
    }
  }

  Future<void> _copy(String value, String label) async {
    if (value.trim().isEmpty) return;
    await Clipboard.setData(ClipboardData(text: value));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('تم نسخ $label')),
    );
  }

  Future<void> _pickReceipt() async {
    final file = await ImagePicker().pickImage(
      source: ImageSource.gallery,
      imageQuality: 80,
    );
    if (file != null && mounted) setState(() => _receipt = file);
  }

  String _receiptFileName() {
    final random = Random.secure().nextInt(0x7fffffff).toRadixString(16);
    final mime = _receipt?.mimeType?.toLowerCase() ?? '';
    final originalName = _receipt?.name.toLowerCase() ?? '';
    final extension = mime == 'image/png' || originalName.endsWith('.png')
        ? 'png'
        : mime == 'image/webp' || originalName.endsWith('.webp')
            ? 'webp'
            : 'jpg';
    return 'orders/${DateTime.now().millisecondsSinceEpoch}_$random.$extension';
  }

  Future<void> _confirmTransfer() async {
    final cart = CartService.instance;
    if (cart.items.isEmpty) {
      _showMessage('السلة فارغة');
      return;
    }
    if (_bank == null ||
        (_bank!['account_number']?.toString().trim().isEmpty ?? true)) {
      _showMessage('بيانات الحساب المصرفي غير مكتملة. يرجى التواصل مع المتجر.');
      return;
    }
    if (_receipt == null) {
      _showMessage('يرجى إرفاق إيصال التحويل أولاً');
      return;
    }

    setState(() => _sending = true);
    try {
      final receiptPath = _receiptFileName();
      await _db.storage.from('receipts').uploadBinary(
        receiptPath,
        await _receipt!.readAsBytes(),
        fileOptions: FileOptions(
          upsert: false,
          contentType: _receipt!.mimeType ?? 'image/jpeg',
        ),
      );

      final items = cart.items.map((item) => {
        'product_id': item.product.id,
        'product_name': item.product.name,
        'quantity': item.quantity,
        'unit_price': item.product.price,
        'color': item.color,
      }).toList();

      final result = await _db.rpc('astro_create_order', params: {
        'p_customer_name': widget.customerName,
        'p_customer_phone': widget.customerPhone,
        'p_customer_address': widget.customerAddress,
        'p_delivery_method': widget.deliveryMethod,
        'p_payment_method': 'transfer',
        'p_total_price': cart.total,
        'p_items': items,
        'p_receipt_path': receiptPath,
      });

      cart.clear();
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) => AlertDialog(
          title: const Text('تم إرسال طلبك بنجاح'),
          content: Text('رقم الطلب: $result\n'
              'سيتم مراجعة إيصال التحويل والتواصل معك لتأكيد الطلب.'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(dialogContext).pop();
                Navigator.of(context).popUntil((route) => route.isFirst);
              },
              child: const Text('حسناً'),
            ),
          ],
        ),
      );
    } catch (e) {
      if (mounted) _showMessage('تعذر إرسال الطلب: $e');
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  Widget _accountRow(String label, String? value) {
    final text = value?.trim() ?? '';
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.black12),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: const TextStyle(
                  color: Colors.grey, fontSize: 13,
                )),
                const SizedBox(height: 7),
                SelectableText(
                  text.isEmpty ? 'لم تتم إضافة البيانات بعد' : text,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold, fontSize: 15,
                  ),
                ),
              ],
            ),
          ),
          if (text.isNotEmpty)
            IconButton(
              onPressed: () => _copy(text, label),
              icon: const Icon(Icons.copy),
              color: astroNavy,
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bank = _bank ?? {};
    return Scaffold(
      backgroundColor: astroBackground,
      appBar: AppBar(title: const Text('بيانات التحويل المصرفي')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(child: Text(_error!))
              : ListView(
                  padding: const EdgeInsets.all(18),
                  children: [
                    const Icon(Icons.account_balance,
                        size: 48, color: astroNavy),
                    const SizedBox(height: 12),
                    const Text(
                      'حوّل قيمة طلبك إلى الحساب التالي',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 18, fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 20),
                    _accountRow('اسم المصرف', bank['bank_name']?.toString()),
                    _accountRow('اسم صاحب الحساب',
                        bank['account_holder']?.toString()),
                    _accountRow('الفرع', bank['branch_name']?.toString()),
                    _accountRow('رقم الحساب العادي',
                        bank['account_number']?.toString()),
                    _accountRow('رقم الحساب الدولي IBAN',
                        bank['iban']?.toString()),
                    _accountRow('تفاصيل وتعليمات التحويل',
                        bank['account_details']?.toString()),
                    const SizedBox(height: 10),
                    const Text('إرفاق إيصال التحويل',
                        style: TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 16,
                        )),
                    const SizedBox(height: 10),
                    OutlinedButton.icon(
                      onPressed: _sending ? null : _pickReceipt,
                      icon: const Icon(Icons.upload_file),
                      label: Text(_receipt == null
                          ? 'اختيار صورة الإيصال' : _receipt!.name),
                    ),
                    if (_receipt != null)
                      const Padding(
                        padding: EdgeInsets.only(top: 8),
                        child: Text('تم اختيار الإيصال.',
                            style: TextStyle(color: Colors.green)),
                      ),
                    const SizedBox(height: 20),
                    Text(
                      'إجمالي الطلب: '
                      '${CartService.instance.total.toStringAsFixed(2)} د.ل',
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontSize: 20, fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 18),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _sending ? null : _confirmTransfer,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: astroNavy,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.all(16),
                        ),
                        child: Text(_sending
                            ? 'جارٍ إرسال الطلب...'
                            : 'تأكيد التحويل وإرسال الطلب'),
                      ),
                    ),
                  ],
                ),
    );
  }
}

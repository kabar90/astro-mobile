import 'package:flutter/material.dart';
import '../main.dart';
import '../services/notification_service.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  late Future<List<Map<String, dynamic>>> _items;

  @override
  void initState() {
    super.initState();
    _items = NotificationService.instance.history();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: astroBackground,
      appBar: AppBar(title: const Text('الإشعارات')),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: _items,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          final items = snapshot.data ?? [];
          if (items.isEmpty) {
            return const Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.notifications_none, size: 58, color: Colors.black26),
                  SizedBox(height: 12),
                  Text('لا توجد إشعارات حتى الآن'),
                ],
              ),
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, index) {
              final item = items[index];
              return Card(
                color: Colors.white,
                child: ListTile(
                  leading: const CircleAvatar(
                    backgroundColor: Color(0xFFF5EBD7),
                    child: Icon(Icons.notifications_active, color: astroNavy),
                  ),
                  title: Text(item['title']?.toString() ?? 'ASTRO MOBILE'),
                  subtitle: Text(item['body']?.toString() ?? ''),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

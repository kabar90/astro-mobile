
class Product {
  final String id;
  final String name;
  final String category;
  final int? subcategoryId;
  final double price;
  final String imageUrl;
  final String description;
  final bool isActive;
  final List<String> colors;

  const Product({
    required this.id,
    required this.name,
    required this.category,
    this.subcategoryId,
    required this.price,
    required this.imageUrl,
    required this.description,
    this.isActive = true,
    this.colors = const [],
  });

  factory Product.fromMap(String id, Map<String, dynamic> data) {
    final rawPrice = data['price'];
    final rawColors = data['colors'];

    List<String> productColors = [];

    if (rawColors is List) {
      productColors = rawColors
          .map((color) => color.toString().trim())
          .where((color) => color.isNotEmpty)
          .toList();
    } else if (rawColors is String && rawColors.trim().isNotEmpty) {
      productColors = rawColors
          .split(RegExp(r'[,،\n]'))
          .map((color) => color.trim())
          .where((color) => color.isNotEmpty)
          .toList();
    }

    return Product(
      id: id,
      name: (data['name'] ?? '').toString(),
      category: (data['category'] ?? 'هواتف').toString(),
      subcategoryId: data['subcategory_id'] is int
          ? data['subcategory_id'] as int
          : int.tryParse('${data['subcategory_id'] ?? ''}'),
      price: rawPrice is num
          ? rawPrice.toDouble()
          : double.tryParse('$rawPrice') ?? 0,
      imageUrl: (data['image_url'] ?? data['imageUrl'] ?? '').toString(),
      description: (data['description'] ?? '').toString(),
      isActive: data['is_active'] is bool
          ? data['is_active'] as bool
          : data['isActive'] is bool
              ? data['isActive'] as bool
              : true,
      colors: productColors,
    );
  }
}

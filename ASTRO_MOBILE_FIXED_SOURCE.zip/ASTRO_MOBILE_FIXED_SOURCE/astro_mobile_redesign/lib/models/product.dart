class Product {
  final String id;
  final String name;
  final String category;
  final int? subcategoryId;
  final double price;
  final String imageUrl;
  final List<String> images;
  final String description;
  final bool isActive;
  final List<String> colors;
  final String? brand;
  final double? rating;
  final int? reviewCount;
  final int? stockQuantity;
  final bool isNew;
  final Map<String, String> specifications;

  const Product({
    required this.id,
    required this.name,
    required this.category,
    this.subcategoryId,
    required this.price,
    required this.imageUrl,
    this.images = const [],
    required this.description,
    this.isActive = true,
    this.colors = const [],
    this.brand,
    this.rating,
    this.reviewCount,
    this.stockQuantity,
    this.isNew = false,
    this.specifications = const {},
  });

  factory Product.fromMap(String id, Map<String, dynamic> data) {
    final rawPrice = data['price'];
    final rawColors = data['colors'];
    final rawImages = data['images'] ?? data['gallery_images'];
    final mainImage =
        (data['image_url'] ?? data['imageUrl'] ?? '').toString().trim();

    List<String> productColors = [];
    if (rawColors is List) {
      productColors = rawColors
          .map((color) => color.toString().trim())
          .where((color) => color.isNotEmpty)
          .toList();
    } else if (rawColors is String && rawColors.trim().isNotEmpty) {
      productColors = rawColors
          .split(RegExp(r'[,،\n]'))
          .map((color) => color.trim())
          .where((color) => color.isNotEmpty)
          .toList();
    }

    List<String> gallery = [];
    if (rawImages is List) {
      gallery = rawImages
          .map((image) => image.toString().trim())
          .where((image) => image.isNotEmpty)
          .toList();
    } else if (rawImages is String && rawImages.trim().isNotEmpty) {
      gallery = rawImages
          .split(RegExp(r'[,،\n]'))
          .map((image) => image.trim())
          .where((image) => image.isNotEmpty)
          .toList();
    }
    if (mainImage.isNotEmpty && !gallery.contains(mainImage)) {
      gallery.insert(0, mainImage);
    }

    final rawSpecs = data['specifications'] ?? data['specs'];
    final Map<String, String> specs = {};
    if (rawSpecs is Map) {
      rawSpecs.forEach((key, value) {
        final label = key.toString().trim();
        final content = value?.toString().trim() ?? '';
        if (label.isNotEmpty && content.isNotEmpty) {
          specs[label] = content;
        }
      });
    }

    double? asDouble(dynamic value) {
      if (value is num) return value.toDouble();
      return double.tryParse('${value ?? ''}');
    }

    int? asInt(dynamic value) {
      if (value is int) return value;
      if (value is num) return value.toInt();
      return int.tryParse('${value ?? ''}');
    }

    return Product(
      id: id,
      name: (data['name'] ?? '').toString(),
      category: (data['category'] ?? 'هواتف').toString(),
      subcategoryId: asInt(data['subcategory_id']),
      price: rawPrice is num
          ? rawPrice.toDouble()
          : double.tryParse('$rawPrice') ?? 0,
      imageUrl: mainImage,
      images: gallery,
      description: (data['description'] ?? '').toString(),
      isActive: data['is_active'] is bool
          ? data['is_active'] as bool
          : data['isActive'] is bool
              ? data['isActive'] as bool
              : true,
      colors: productColors,
      brand: (data['brand'] ?? '').toString().trim().isEmpty
          ? null
          : data['brand'].toString().trim(),
      rating: asDouble(data['rating']),
      reviewCount: asInt(data['review_count'] ?? data['reviews_count']),
      stockQuantity:
          asInt(data['stock_quantity'] ?? data['stock'] ?? data['quantity']),
      isNew: data['is_new'] == true || data['isNew'] == true,
      specifications: specs,
    );
  }
}

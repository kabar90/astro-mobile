
import 'package:flutter/material.dart';
import '../main.dart';
import '../models/product.dart';

class ProductDetailScreen extends StatefulWidget {
  final Product product;

  const ProductDetailScreen({
    super.key,
    required this.product,
  });

  @override
  State<ProductDetailScreen> createState() =>
      _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  String? selectedColor;

  @override
  void initState() {
    super.initState();

    if (widget.product.colors.length == 1) {
      selectedColor = widget.product.colors.first;
    }
  }

  Color colorValue(String name) {
    final value = name.trim().toLowerCase();

    const colors = {
      'أسود': Color(0xFF222222),
      'اسود': Color(0xFF222222),
      'black': Color(0xFF222222),
      'أبيض': Color(0xFFF5F5F5),
      'ابيض': Color(0xFFF5F5F5),
      'white': Color(0xFFF5F5F5),
      'أزرق': Color(0xFF2865B5),
      'ازرق': Color(0xFF2865B5),
      'blue': Color(0xFF2865B5),
      'أخضر': Color(0xFF39845A),
      'اخضر': Color(0xFF39845A),
      'green': Color(0xFF39845A),
      'أحمر': Color(0xFFD83C3C),
      'احمر': Color(0xFFD83C3C),
      'red': Color(0xFFD83C3C),
      'ذهبي': Color(0xFFD6AE55),
      'gold': Color(0xFFD6AE55),
      'بنفسجي': Color(0xFF9470B8),
      'فضي': Color(0xFFC0C0C0),
      'رمادي': Color(0xFF888888),
      'وردي': Color(0xFFE99AB5),
    };

    return colors[value] ?? const Color(0xFFB8B8B8);
  }

  @override
  Widget build(BuildContext context) {
    final product = widget.product;

    return Scaffold(
      backgroundColor: astroBackground,
      appBar: AppBar(
        title: const Text(
          'تفاصيل المنتج',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 17,
          ),
        ),
        actions: [
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.favorite_border_rounded),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 18),
              children: [
                Container(
                  height: 300,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(22),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: product.imageUrl.isEmpty
                      ? Center(
                          child: Icon(
                            product.category == 'هواتف'
                                ? Icons.smartphone_rounded
                                : Icons.headphones_rounded,
                            size: 100,
                            color: astroNavy.withOpacity(.25),
                          ),
                        )
                      : Image.network(
                          product.imageUrl,
                          fit: BoxFit.contain,
                          errorBuilder: (_, __, ___) => Center(
                            child: Icon(
                              product.category == 'هواتف'
                                  ? Icons.smartphone_rounded
                                  : Icons.headphones_rounded,
                              size: 100,
                              color: astroNavy.withOpacity(.25),
                            ),
                          ),
                        ),
                ),

                const SizedBox(height: 18),

                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 11,
                          vertical: 6,
                        ),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF5EBD7),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          product.category,
                          style: const TextStyle(
                            color: astroNavy,
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),

                      const SizedBox(height: 12),

                      Text(
                        product.name,
                        style: const TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w900,
                          color: astroNavy,
                        ),
                      ),

                      const SizedBox(height: 10),

                      Text(
                        '${product.price.toStringAsFixed(0)} د.ل',
                        style: const TextStyle(
                          fontSize: 23,
                          fontWeight: FontWeight.w900,
                          color: astroNavy,
                        ),
                      ),

                      if (product.colors.isNotEmpty) ...[
                        const Divider(height: 30),

                        const Text(
                          'اختر لون المنتج',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: astroNavy,
                          ),
                        ),

                        const SizedBox(height: 15),

                        Wrap(
                          spacing: 14,
                          runSpacing: 14,
                          children: product.colors.map((color) {
                            final selected = selectedColor == color;

                            return InkWell(
                              borderRadius: BorderRadius.circular(14),
                              onTap: () {
                                setState(() {
                                  selectedColor = color;
                                });
                              },
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 12,
                                  vertical: 10,
                                ),
                                decoration: BoxDecoration(
                                  color: selected
                                      ? const Color(0xFFFFF8E9)
                                      : Colors.white,
                                  borderRadius: BorderRadius.circular(14),
                                  border: Border.all(
                                    color: selected
                                        ? astroGold
                                        : const Color(0xFFE5E8ED),
                                    width: selected ? 2 : 1,
                                  ),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Container(
                                      width: 23,
                                      height: 23,
                                      decoration: BoxDecoration(
                                        color: colorValue(color),
                                        shape: BoxShape.circle,
                                        border: Border.all(
                                          color: const Color(0xFFD5D5D5),
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    Text(
                                      color,
                                      style: const TextStyle(
                                        color: astroNavy,
                                        fontSize: 13,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    if (selected) ...[
                                      const SizedBox(width: 5),
                                      const Icon(
                                        Icons.check_circle,
                                        color: astroGold,
                                        size: 17,
                                      ),
                                    ],
                                  ],
                                ),
                              ),
                            );
                          }).toList(),
                        ),

                        if (selectedColor != null) ...[
                          const SizedBox(height: 12),
                          Text(
                            'اللون المختار: $selectedColor',
                            style: const TextStyle(
                              color: astroNavy,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ],

                      const Divider(height: 28),

                      const Text(
                        'وصف المنتج',
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          color: astroNavy,
                        ),
                      ),

                      const SizedBox(height: 8),

                      Text(
                        product.description,
                        style: const TextStyle(
                          fontSize: 14,
                          height: 1.7,
                          color: Colors.black54,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          Container(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
            decoration: const BoxDecoration(
              color: Colors.white,
              border: Border(
                top: BorderSide(
                  color: Color(0xFFEDEFF3),
                ),
              ),
            ),
            child: SafeArea(
              top: false,
              child: SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: astroNavy,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  onPressed: () {
                    if (product.colors.isNotEmpty &&
                        selectedColor == null) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('يرجى اختيار لون المنتج أولاً'),
                        ),
                      );
                      return;
                    }

                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          product.colors.isNotEmpty
                              ? 'تم اختيار اللون $selectedColor. السلة ستُفعّل في المرحلة التالية.'
                              : 'السلة ستُفعّل في المرحلة التالية',
                        ),
                      ),
                    );
                  },
                  icon: const Icon(
                    Icons.add_shopping_cart_rounded,
                    color: astroGold,
                  ),
                  label: const Text(
                    'أضف إلى السلة',
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

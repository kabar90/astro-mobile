import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../main.dart';
import '../services/cart_service.dart';
import 'bank_transfer_screen.dart';
import '../services/notification_service.dart';

class CheckoutScreen extends StatefulWidget {
  const CheckoutScreen({super.key});

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _address = TextEditingController();
  final _db = Supabase.instance.client;

  String _payment = 'cash';
  String _delivery = 'delivery';
  bool _busy = false;
  int _pointsBalance = 0;
  bool _pointsLoading = true;

  @override
  void initState() {
    super.initState();
    _loadPointsBalance();
  }

  Future<void> _loadPointsBalance() async {
    final user = _db.auth.currentUser;
    if (user == null) {
      if (mounted) setState(() => _pointsLoading = false);
      return;
    }
    try {
      final row = await _db
          .from('customer_points')
          .select('balance')
          .eq('user_id', user.id)
          .maybeSingle();
      if (!mounted) return;
      setState(() {
        _pointsBalance = (row?['balance'] as num?)?.toInt() ?? 0;
        _pointsLoading = false;
      });
    } catch (_) {
      if (mounted) setState(() => _pointsLoading = false);
    }
  }

  bool get _cartAllowsPoints {
    final items = CartService.instance.items;
    return items.isNotEmpty && items.every((item) => item.product.allowPointsPayment);
  }

  int get _requiredPoints => (CartService.instance.total * 10).ceil();

  Future<void> _submit() async {
    final cart = CartService.instance;

    if (cart.items.isEmpty) {
      _message('السلة فارغة');
      return;
    }
    if (_name.text.trim().isEmpty || _phone.text.trim().isEmpty) {
      _message('يرجى إدخال الاسم ورقم الهاتف');
      return;
    }
    if (_delivery == 'delivery' && _address.text.trim().isEmpty) {
      _message('يرجى إدخال عنوان التوصيل');
      return;
    }

    if (_payment == 'points') {
      await _submitPointsOrder();
      return;
    }

    // التحويل المصرفي يفتح صفحة مستقلة لعرض بيانات الحساب
    // وإرفاق إيصال التحويل ثم إرسال الطلب.
    if (_payment == 'transfer') {
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => BankTransferScreen(
            customerName: _name.text.trim(),
            customerPhone: _phone.text.trim(),
            customerAddress:
                _delivery == 'pickup' ? '' : _address.text.trim(),
            deliveryMethod: _delivery,
          ),
        ),
      );
      return;
    }

    setState(() => _busy = true);
    try {
      final items = cart.items.map((item) => {
        'product_id': item.product.id,
        'product_name': item.product.name,
        'quantity': item.quantity,
        'unit_price': item.product.price,
        'color': item.color,
      }).toList();

      final result = await _db.rpc('astro_create_order', params: {
        'p_customer_name': _name.text.trim(),
        'p_customer_phone': _phone.text.trim(),
        'p_customer_address':
            _delivery == 'pickup' ? '' : _address.text.trim(),
        'p_delivery_method': _delivery,
        'p_payment_method': 'cash',
        'p_total_price': cart.total,
        'p_items': items,
        'p_receipt_path': null,
      });

      await NotificationService.instance.bindCurrentCustomerPhone(_phone.text.trim());
      cart.clear();
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) => AlertDialog(
          title: const Text('تم استلام طلبك بنجاح'),
          content: Text('رقم الطلب: $result\nسنتواصل معك لتأكيد الطلب.'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(dialogContext).pop();
                Navigator.of(context).popUntil((route) => route.isFirst);
              },
              child: const Text('حسناً'),
            ),
          ],
        ),
      );
    } catch (e) {
      if (mounted) _message('تعذر إرسال الطلب: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _submitPointsOrder() async {
    final user = _db.auth.currentUser;
    if (user == null) {
      _message('يجب تسجيل الدخول لاستخدام نقاط المكافآت');
      return;
    }
    if (!_cartAllowsPoints) {
      _message('بعض منتجات السلة غير متاحة للشراء بالنقاط');
      return;
    }
    if (_pointsBalance < _requiredPoints) {
      _message('رصيد النقاط غير كافٍ لإتمام شراء السلة');
      return;
    }

    final pointsToSpend = _requiredPoints;
    setState(() => _busy = true);
    try {
      final items = CartService.instance.items.map((item) => {
        'product_id': item.product.id,
        'quantity': item.quantity,
        'color': item.color,
      }).toList();

      final result = await _db.rpc('astro_create_points_order', params: {
        'p_customer_name': _name.text.trim(),
        'p_customer_phone': _phone.text.trim(),
        'p_customer_address': _delivery == 'pickup' ? '' : _address.text.trim(),
        'p_delivery_method': _delivery,
        'p_items': items,
      });

      await NotificationService.instance.bindCurrentCustomerPhone(_phone.text.trim());
      CartService.instance.clear();
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) => AlertDialog(
          title: const Text('تم إنشاء طلبك بالنقاط بنجاح'),
          content: Text('رقم الطلب: $result\nتم خصم $pointsToSpend نقطة من رصيدك.'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(dialogContext).pop();
                Navigator.of(context).popUntil((route) => route.isFirst);
              },
              child: const Text('حسناً'),
            ),
          ],
        ),
      );
    } catch (e) {
      if (mounted) _message('تعذر إتمام الشراء بالنقاط: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _message(String value) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(value)),
    );
  }

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _address.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: astroBackground,
      appBar: AppBar(title: const Text('إتمام الطلب')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          _field('الاسم الكامل', _name),
          _field('رقم الهاتف', _phone, keyboard: TextInputType.phone),
          if (_delivery == 'delivery')
            _field('العنوان / المدينة', _address),
          const SizedBox(height: 12),
          const Text('طريقة الاستلام',
              style: TextStyle(fontWeight: FontWeight.bold)),
          RadioListTile<String>(
            value: 'delivery',
            groupValue: _delivery,
            title: const Text('توصيل إلى العنوان'),
            onChanged: (value) => setState(() => _delivery = value!),
          ),
          RadioListTile<String>(
            value: 'pickup',
            groupValue: _delivery,
            title: const Text('استلام من المحل'),
            onChanged: (value) => setState(() => _delivery = value!),
          ),
          const Divider(),
          const Text('طريقة الدفع',
              style: TextStyle(fontWeight: FontWeight.bold)),
          RadioListTile<String>(
            value: 'cash',
            groupValue: _payment,
            title: const Text('نقداً عند الاستلام'),
            onChanged: (value) => setState(() => _payment = value!),
          ),
          RadioListTile<String>(
            value: 'transfer',
            groupValue: _payment,
            title: const Text('تحويل مصرفي – مصرف شمال أفريقيا'),
            subtitle: const Text('ستظهر بيانات الحساب في الصفحة التالية'),
            onChanged: (value) => setState(() => _payment = value!),
          ),
          if (_cartAllowsPoints && _db.auth.currentUser != null) ...[
            RadioListTile<String>(
              value: 'points',
              groupValue: _payment,
              title: const Text('الدفع بنقاط المكافآت'),
              subtitle: Text(
                _pointsLoading
                    ? 'جارٍ تحميل رصيدك...'
                    : 'رصيدك: $_pointsBalance نقطة • المطلوب: $_requiredPoints نقطة',
              ),
              onChanged: _pointsLoading ? null : (value) => setState(() => _payment = value!),
            ),
            if (!_pointsLoading && _pointsBalance < _requiredPoints)
              const Padding(
                padding: EdgeInsetsDirectional.only(start: 16, bottom: 8),
                child: Text(
                  'رصيدك غير كافٍ لشراء جميع منتجات السلة بالنقاط.',
                  style: TextStyle(color: Colors.red, fontSize: 12),
                ),
              ),
          ] else if (_db.auth.currentUser == null)
            const Padding(
              padding: EdgeInsetsDirectional.only(start: 16, bottom: 8),
              child: Text(
                'سجّل الدخول لاستخدام نقاط المكافآت.',
                style: TextStyle(color: Colors.grey, fontSize: 12),
              ),
            ),
          const SizedBox(height: 18),
          Text(
            'الإجمالي: ${CartService.instance.total.toStringAsFixed(2)} د.ل',
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 18),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _busy ? null : _submit,
              style: ElevatedButton.styleFrom(
                backgroundColor: astroNavy,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.all(16),
              ),
              child: Text(_busy ? 'جارٍ إرسال الطلب...' : 'متابعة'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _field(
    String label,
    TextEditingController controller, {
    TextInputType? keyboard,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        keyboardType: keyboard,
        decoration: InputDecoration(
          labelText: label,
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
    );
  }
}

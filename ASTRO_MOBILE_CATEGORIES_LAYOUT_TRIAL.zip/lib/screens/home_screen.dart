
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../main.dart';
import '../models/product.dart';
import '../services/product_repository.dart';
import '../services/cart_service.dart';
import 'cart_screen.dart';
import 'product_detail_screen.dart';
import 'notifications_screen.dart';
import 'account_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final search = TextEditingController();
  final storeSearch = TextEditingController();
  String category = 'الكل';
  int? selectedCategoryId;
  int? selectedSubcategoryId;
  int? categoryPageRootId;
  int? categoryPageSubcategoryId;
  int nav = 0;
  String? _activeHomeSectionTitle;
  List<Product>? _activeHomeSectionProducts;

  @override
  void dispose() {
    search.dispose();
    storeSearch.dispose();
    super.dispose();
  }

  void message(String value) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(value),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<StoreCategory>>(
      stream: ProductRepository.watchCategories(),
      builder: (context, categorySnapshot) {
        final categories = categorySnapshot.data ?? [];
        final rootCategories = categories
            .where((item) => item.parentId == null && item.isActive)
            .toList()
          ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder));

        StoreCategory? selectedRoot;
        for (final item in categories) {
          if (item.id == selectedCategoryId) {
            selectedRoot = item;
            break;
          }
        }

        final selectedRootId = selectedRoot?.id;
        final selectedRootName = selectedRoot?.name;
        final subcategories = selectedRootId == null
            ? <StoreCategory>[]
            : (categories
                .where((item) =>
                    item.parentId == selectedRootId && item.isActive)
                .toList()
              ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder)));

        return StreamBuilder<List<Product>>(
          stream: ProductRepository.watchProducts(),
          builder: (context, snapshot) {
            final sourceProducts = snapshot.data ?? [];
            final visibleRootCategories = rootCategories.where((item) =>
                sourceProducts.any((product) => product.category == item.name)).toList();
            final homeCategoryTiles = <StoreCategory>[
              ...rootCategories,
              ...categories.where((item) => item.parentId != null && item.isActive),
            ].take(8).toList();
            final q = search.text.trim().toLowerCase();
            final storeQuery = storeSearch.text.trim().toLowerCase();
            final storeProducts = sourceProducts.where((p) =>
                '${p.name} ${p.category} ${p.brand}'.toLowerCase().contains(storeQuery)).toList();

            final products = sourceProducts.where((p) {
              final matchesRoot = selectedRootName == null ||
                  p.category == selectedRootName;
              final matchesSubcategory = selectedSubcategoryId == null ||
                  p.subcategoryId == selectedSubcategoryId;
              final matchesSearch =
                  '${p.name} ${p.category}'.toLowerCase().contains(q);

              return matchesRoot && matchesSubcategory && matchesSearch;
            }).toList();


            return Scaffold(
          appBar: (_activeHomeSectionTitle != null || nav == 2 || nav == 3) ? null : AppBar(
            centerTitle: true,
            title: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'ASTRO MOBILE',
                      style: TextStyle(
                        fontSize: 19,
                        fontWeight: FontWeight.w900,
                        letterSpacing: .5,
                        color: astroNavy,
                      ),
                    ),
                    Text(
                      'كل ما تحتاجه من التقنية',
                      style: TextStyle(fontSize: 10, color: Colors.black45),
                    ),
                  ],
                ),
                const SizedBox(width: 7),
                ClipRRect(
                  borderRadius: BorderRadius.circular(13),
                  child: Image.asset(
                    'assets/astro-logo.jpg',
                    width: 48,
                    height: 48,
                    fit: BoxFit.contain,
                    errorBuilder: (_, __, ___) => const Icon(
                      Icons.smartphone_rounded,
                      size: 36,
                      color: astroBlue,
                    ),
                  ),
                ),
              ],
            ),
            actions: [
              _action(
                Icons.notifications_none_rounded,
                () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const NotificationsScreen(),
                  ),
                ),
              ),
              const SizedBox(width: 7),
              AnimatedBuilder(
                animation: CartService.instance,
                builder: (context, _) => Stack(
                  clipBehavior: Clip.none,
                  children: [
                    _action(
                      Icons.shopping_bag_outlined,
                      () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const CartScreen()),
                      ),
                    ),
                    if (CartService.instance.count > 0)
                      Positioned(
                        right: 0,
                        top: 0,
                        child: Container(
                          padding: const EdgeInsets.all(4),
                          decoration: const BoxDecoration(
                            color: astroGold,
                            shape: BoxShape.circle,
                          ),
                          child: Text(
                            '${CartService.instance.count}',
                            style: const TextStyle(
                              color: astroNavy,
                              fontSize: 9,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(width: 14),
            ],
          ),

          body: _activeHomeSectionTitle != null && _activeHomeSectionProducts != null
              ? _buildHomeSectionProductsPage(
                  _activeHomeSectionTitle!,
                  _activeHomeSectionProducts!,
                )
              : nav == 3
                  ? const AccountScreen()
                  : nav == 2
                      ? const CartScreen()
                      : nav == 4
                          ? _buildStorePage(storeProducts)
                          : nav == 1
              ? _buildCategoriesPage(
                  rootCategories: rootCategories,
                  categories: categories,
                  products: sourceProducts,
                )
              : CustomScrollView(
            slivers: [
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(18, 8, 18, 16),
                  child: Container(
                    height: 52,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(
                        color: const Color(0xFFE8EBF0),
                      ),
                    ),
                    child: TextField(
                      controller: search,
                      onChanged: (_) => setState(() {}),
                      decoration: const InputDecoration(
                        hintText: 'ابحث عن هاتف أو إكسسوار...',
                        hintStyle: TextStyle(
                          fontSize: 13,
                          color: Colors.black38,
                        ),
                        prefixIcon: Icon(
                          Icons.search,
                          color: astroGold,
                        ),
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(vertical: 15),
                      ),
                    ),
                  ),
                ),
              ),

              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 18),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(23),
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        onTap: () => setState(() => nav = 4),
                        child: SizedBox(
                          width: double.infinity,
                          height: 158,
                          child: Image.asset(
                            'assets/astro-banner-phones.jpg',
                            fit: BoxFit.cover,
                            alignment: Alignment.center,
                            errorBuilder: (_, __, ___) => Container(
                              decoration: const BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [Color(0xFF0878D8), Color(0xFF061D49)],
                                ),
                              ),
                              child: const Center(
                                child: Text(
                                  'ASTRO MOBILE',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 22,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),

              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(18, 20, 18, 2),
                  child: Row(
                    children: [
                      const Icon(Icons.grid_view_rounded, color: astroBlue, size: 19),
                      const SizedBox(width: 6),
                      const Text(
                        'الأقسام الرئيسية',
                        style: TextStyle(color: astroNavy, fontSize: 17, fontWeight: FontWeight.w900),
                      ),
                      const Spacer(),
                      TextButton(
                        onPressed: () => setState(() => nav = 1),
                        child: const Row(
                          children: [
                            Text('عرض الكل', style: TextStyle(color: astroBlue, fontSize: 11, fontWeight: FontWeight.w800)),
                            Icon(Icons.chevron_left_rounded, size: 18, color: astroBlue),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SliverToBoxAdapter(
                child: SizedBox(
                  height: 142,
                  child: ListView.separated(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
                    scrollDirection: Axis.horizontal,
                    itemCount: homeCategoryTiles.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 11),
                    itemBuilder: (context, index) {
                      final item = homeCategoryTiles[index];
                      final isRoot = item.parentId == null;
                      StoreCategory? rootForTile;
                      if (isRoot) {
                        rootForTile = item;
                      } else {
                        for (final root in rootCategories) {
                          if (root.id == item.parentId) {
                            rootForTile = root;
                            break;
                          }
                        }
                      }
                      final categoryAsset = _categoryAsset(item.name);
                      final palette = const [
                        Color(0xFFDCEEFF), Color(0xFFDDF5E8), Color(0xFFEFE2FF),
                        Color(0xFFFFE8D5), Color(0xFFFFE1EA), Color(0xFFE3EAFF),
                        Color(0xFFDDF5F7), Color(0xFFFFF1D9),
                      ];
                      return SizedBox(
                        width: 116,
                        child: Material(
                          color: Colors.transparent,
                          child: InkWell(
                            borderRadius: BorderRadius.circular(20),
                            onTap: () => setState(() {
                              if (isRoot) {
                                category = item.name;
                                selectedCategoryId = item.id;
                                selectedSubcategoryId = null;
                              } else {
                                category = rootForTile?.name ?? item.name;
                                selectedCategoryId = rootForTile?.id;
                                selectedSubcategoryId = item.id;
                              }
                            }),
                            child: Ink(
                              decoration: BoxDecoration(
                                color: palette[index % palette.length],
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(color: const Color(0xFFD5E4F3)),
                              ),
                              padding: const EdgeInsets.all(9),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Expanded(
                                    child: Image.asset(
                                      categoryAsset,
                                      fit: BoxFit.contain,
                                      errorBuilder: (_, __, ___) => Icon(
                                        _categoryIcon(item.name), color: astroBlue, size: 42,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 6),
                                  Text(item.name, maxLines: 1, overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.center,
                                    style: const TextStyle(color: astroNavy, fontSize: 11, fontWeight: FontWeight.w900)),
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),


              SliverToBoxAdapter(
                child: StreamBuilder<List<Map<String, dynamic>>>(
                  stream: Supabase.instance.client
                      .from('offers')
                      .stream(primaryKey: ['id']),
                  builder: (context, offerSnapshot) {
                    final now = DateTime.now();
                    final activeOffers = (offerSnapshot.data ?? []).where((offer) {
                      final starts = DateTime.tryParse('${offer['starts_at'] ?? ''}');
                      final ends = DateTime.tryParse('${offer['ends_at'] ?? ''}');
                      return offer['is_active'] == true && starts != null && ends != null &&
                          !now.isBefore(starts) && now.isBefore(ends);
                    }).toList();

                    final offerCards = <Widget>[];
                    final usedProducts = <String>{};
                    for (final offer in activeOffers) {
                      final type = '${offer['offer_type'] ?? ''}';
                      if (type == 'bundle') continue;
                      final discountType = '${offer['discount_type'] ?? ''}';
                      final discountValue = double.tryParse('${offer['discount_value'] ?? ''}') ?? 0;
                      if (discountValue <= 0) continue;

                      for (final product in products) {
                        final matches = type == 'product'
                            ? product.id == '${offer['product_id']}'
                            : type == 'category' && product.category == '${offer['category_name'] ?? ''}';
                        if (!matches || usedProducts.contains(product.id)) continue;
                        final salePrice = discountType == 'percentage'
                            ? product.price * (1 - discountValue / 100)
                            : discountValue;
                        if (salePrice < 0 || salePrice >= product.price) continue;
                        usedProducts.add(product.id);
                        offerCards.add(_offerProductCard(
                          product,
                          salePrice,
                          discountType == 'percentage'
                              ? 'خصم ${discountValue.toStringAsFixed(0)}%'
                              : 'سعر خاص',
                        ));
                      }
                    }

                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Padding(
                          padding: const EdgeInsets.fromLTRB(18, 20, 18, 8),
                          child: Row(
                            children: const [
                              Text('العروض والتخفيضات', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: astroNavy)),
                              Spacer(),
                              Icon(Icons.local_offer_rounded, color: Color(0xFFE44755), size: 20),
                            ],
                          ),
                        ),
                        if (offerCards.isEmpty)
                          Padding(
                            padding: const EdgeInsets.fromLTRB(18, 4, 18, 10),
                            child: Container(
                              height: 76,
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                color: const Color(0xFFFFF0F1),
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(color: const Color(0xFFFFD8DD)),
                              ),
                              child: const Text('ترقبوا عروض ASTRO MOBILE قريباً',
                                style: TextStyle(color: astroNavy, fontWeight: FontWeight.w800)),
                            ),
                          )
                        else
                          SizedBox(
                            height: 164,
                            child: ListView.separated(
                              padding: const EdgeInsets.symmetric(horizontal: 16),
                              scrollDirection: Axis.horizontal,
                              itemCount: offerCards.length,
                              separatorBuilder: (_, __) => const SizedBox(width: 11),
                              itemBuilder: (_, index) => offerCards[index],
                            ),
                          ),
                      ],
                    );
                  },
                ),
              ),

              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(18, 20, 18, 12),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          selectedRoot == null ? 'أحدث المنتجات' : 'منتجات ${selectedRoot.name}',
                          style: TextStyle(
                            fontSize: 19,
                            fontWeight: FontWeight.w900,
                            color: astroNavy,
                          ),
                        ),
                      ),
                      Text(
                        '${products.length} منتجات',
                        style: const TextStyle(
                          fontSize: 12,
                          color: Colors.black45,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              if (snapshot.connectionState == ConnectionState.waiting &&
                  !snapshot.hasData)
                const SliverToBoxAdapter(
                  child: Padding(
                    padding: EdgeInsets.all(45),
                    child: Center(
                      child: CircularProgressIndicator(
                        color: astroGold,
                      ),
                    ),
                  ),
                )
              else if (snapshot.hasError)
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.all(30),
                    child: Center(
                      child: Column(
                        children: [
                          const Icon(
                            Icons.cloud_off_rounded,
                            size: 48,
                            color: Colors.black38,
                          ),
                          const SizedBox(height: 12),
                          const Text(
                            'تعذر الاتصال بالمتجر حالياً',
                            style: TextStyle(
                              color: astroNavy,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 8),
                          const Text(
                            'يرجى التأكد من اتصال الإنترنت والمحاولة مجدداً.',
                            textAlign: TextAlign.center,
                            style: TextStyle(color: Colors.black45),
                          ),
                          TextButton(
                            onPressed: () => setState(() {}),
                            child: const Text('إعادة المحاولة'),
                          ),
                        ],
                      ),
                    ),
                  ),
                )
              else if (products.isEmpty)
                const SliverToBoxAdapter(
                  child: Padding(
                    padding: EdgeInsets.all(35),
                    child: Center(
                      child: Column(
                        children: [
                          Icon(
                            Icons.inventory_2_outlined,
                            size: 48,
                            color: Colors.black38,
                          ),
                          SizedBox(height: 12),
                          Text(
                            'لا توجد منتجات متاحة حالياً',
                            style: TextStyle(
                              color: astroNavy,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                )
              else
                SliverToBoxAdapter(
                  child: SizedBox(
                    height: 258,
                    child: ListView.separated(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 18),
                      scrollDirection: Axis.horizontal,
                      itemCount: products.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 12),
                      itemBuilder: (context, index) => _horizontalProductCard(products[index]),
                    ),
                  ),
                ),

              SliverToBoxAdapter(
                child: _managedHomeSections(sourceProducts),
              ),
            ],
          ),

          bottomNavigationBar: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(.06),
                  blurRadius: 12,
                  offset: const Offset(0, -3),
                ),
              ],
            ),
            child: SafeArea(
              top: false,
              child: SizedBox(
                height: 64,
                child: Row(
                  children: [
                    _navItem(3, Icons.person_outline_rounded, 'حسابي'),
                    _navItem(2, Icons.shopping_cart_outlined, 'السلة'),
                    _navItem(0, Icons.home_rounded, 'الرئيسية'),
                    _navItem(1, Icons.grid_view_rounded, 'الأقسام'),
                    _navItem(4, Icons.storefront_outlined, 'المتجر'),
                  ],
                ),
              ),
            ),
          ),
        );
          },
        );
      },
    );
  }

  Widget _action(IconData icon, VoidCallback tap) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Material(
        color: Colors.white,
        shape: const CircleBorder(),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: tap,
          child: SizedBox(
            width: 40,
            height: 40,
            child: Icon(icon, color: astroNavy, size: 21),
          ),
        ),
      ),
    );
  }

  Widget _categoryChip(
    String label,
    bool selected,
    VoidCallback onTap,
  ) {
    return Padding(
      padding: const EdgeInsetsDirectional.only(end: 8),
      child: Material(
        color: selected ? astroNavy : Colors.white,
        borderRadius: BorderRadius.circular(22),
        child: InkWell(
          borderRadius: BorderRadius.circular(22),
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 17, vertical: 9),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              border: Border.all(
                color: selected ? astroNavy : const Color(0xFFE1E8F0),
              ),
            ),
            child: Text(
              label,
              style: TextStyle(
                color: selected ? Colors.white : astroNavy,
                fontSize: 12,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _subcategoryChip(
    String label,
    bool selected,
    VoidCallback onTap,
  ) {
    return Padding(
      padding: const EdgeInsetsDirectional.only(end: 7),
      child: Material(
        color: selected ? const Color(0xFFDCEEFF) : Colors.white,
        borderRadius: BorderRadius.circular(18),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                color: selected ? astroBlue : const Color(0xFFE5EBF2),
              ),
            ),
            child: Text(
              label,
              style: TextStyle(
                color: selected ? astroBlue : astroNavy,
                fontSize: 11,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _offerProductCard(Product product, double salePrice, String label) {
    final discount = product.price > 0
        ? (((product.price - salePrice) / product.price) * 100).round()
        : 0;
    return SizedBox(
      width: 248,
      child: Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(17),
        child: InkWell(
          borderRadius: BorderRadius.circular(17),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProductDetailScreen(product: product))),
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(17),
              border: Border.all(color: const Color(0xFFFFD8DD)),
            ),
            padding: const EdgeInsets.all(8),
            child: Row(
              children: [
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: product.imageUrl.isEmpty
                        ? _placeholder(product.category, false)
                        : Image.network(product.imageUrl, fit: BoxFit.contain,
                            errorBuilder: (_, __, ___) => _placeholder(product.category, false)),
                  ),
                ),
                const SizedBox(width: 9),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                        decoration: BoxDecoration(color: const Color(0xFFFFE8EB), borderRadius: BorderRadius.circular(20)),
                        child: Text(label, style: const TextStyle(color: Color(0xFFC6283D), fontSize: 9, fontWeight: FontWeight.w900)),
                      ),
                      const SizedBox(height: 6),
                      Text(product.name, maxLines: 2, overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: astroNavy, fontSize: 11, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 4),
                      Text('${product.price.toStringAsFixed(0)} د.ل',
                        style: const TextStyle(color: Colors.black38, fontSize: 10, decoration: TextDecoration.lineThrough)),
                      Text('${salePrice.toStringAsFixed(0)} د.ل',
                        style: const TextStyle(color: Color(0xFFD92D42), fontSize: 14, fontWeight: FontWeight.w900)),
                      if (discount > 0)
                        Text('وفّر $discount%', style: const TextStyle(color: Color(0xFFD92D42), fontSize: 9, fontWeight: FontWeight.w800)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }


  Widget _homeProductSection({
    required String title,
    required List<Product> products,
    required String badge,
    required VoidCallback onViewAll,
  }) {
    if (products.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(top: 8, bottom: 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 10),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    title,
                    textAlign: TextAlign.right,
                    style: const TextStyle(
                      color: astroNavy,
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
                TextButton(
                  onPressed: onViewAll,
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text('عرض الكل', style: TextStyle(color: astroBlue, fontSize: 11, fontWeight: FontWeight.w800)),
                      Icon(Icons.chevron_left_rounded, color: astroBlue, size: 18),
                    ],
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 258,
            child: ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              scrollDirection: Axis.horizontal,
              itemCount: products.length,
              separatorBuilder: (_, __) => const SizedBox(width: 12),
              itemBuilder: (context, index) => _horizontalProductCard(
                products[index],
                badge: badge,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _horizontalProductCard(Product p, {String? badge}) {
    return SizedBox(
      width: 174,
      child: Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProductDetailScreen(product: p))),
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: const Color(0xFFDCE8F5)),
              boxShadow: [BoxShadow(color: astroNavy.withOpacity(.045), blurRadius: 8, offset: const Offset(0, 3))],
            ),
            padding: const EdgeInsets.all(9),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Stack(
                    children: [
                      Positioned.fill(
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: p.imageUrl.isEmpty
                              ? _placeholder(p.category, false)
                              : Image.network(p.imageUrl, fit: BoxFit.contain,
                                  errorBuilder: (_, __, ___) => _placeholder(p.category, false)),
                        ),
                      ),
                      if (badge != null)
                        Positioned(
                          top: 5,
                          right: 5,
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
                            decoration: BoxDecoration(
                              color: const Color(0xFFE6F4FF),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Text(
                              badge,
                              style: const TextStyle(color: astroNavy, fontSize: 8, fontWeight: FontWeight.w900),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
                const SizedBox(height: 7),
                Text(p.name, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: astroNavy, fontSize: 11, fontWeight: FontWeight.w800)),
                const SizedBox(height: 3),
                Row(
                  children: [
                    Text('${p.price.toStringAsFixed(0)} د.ل', style: const TextStyle(color: astroBlue, fontSize: 13, fontWeight: FontWeight.w900)),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _product(Product p) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(19),
      elevation: 1,
      shadowColor: astroNavy.withOpacity(.07),
      child: InkWell(
        borderRadius: BorderRadius.circular(19),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => ProductDetailScreen(product: p),
            ),
          );
        },
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(19),
            border: Border.all(
              color: const Color(0xFFE0EAF5),
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Stack(
                  children: [
                    ClipRRect(
                      borderRadius: const BorderRadius.vertical(
                        top: Radius.circular(19),
                      ),
                      child: SizedBox(
                        width: double.infinity,
                        child: p.imageUrl.isEmpty
                            ? _placeholder(p.category, false)
                            : Image.network(
                                p.imageUrl,
                                fit: BoxFit.contain,
                                loadingBuilder: (context, child, progress) {
                                  if (progress == null) return child;
                                  return _placeholder(p.category, true);
                                },
                                errorBuilder: (_, __, ___) =>
                                    _placeholder(p.category, false),
                              ),
                      ),
                    ),
                    Positioned(
                      top: 9,
                      right: 9,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 9,
                          vertical: 5,
                        ),
                        decoration: BoxDecoration(
                          color: const Color(0xFFE6F4FF),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          p.category,
                          style: const TextStyle(
                            fontSize: 10,
                            color: astroNavy,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(11, 9, 11, 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      p.name,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 13,
                        height: 1.25,
                        fontWeight: FontWeight.w800,
                        color: astroNavy,
                      ),
                    ),
                    const SizedBox(height: 9),
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            '${p.price.toStringAsFixed(0)} د.ل',
                            style: const TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w900,
                              color: astroNavy,
                            ),
                          ),
                        ),
                        Material(
                          color: astroBlue,
                          borderRadius: BorderRadius.circular(10),
                          child: InkWell(
                            borderRadius: BorderRadius.circular(10),
                            onTap: () {
                              if (p.colors.isNotEmpty) {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (_) => ProductDetailScreen(product: p)),
                                );
                              } else {
                                CartService.instance.add(p, null);
                                message('تمت إضافة ${p.name} إلى السلة');
                              }
                            },
                            child: const SizedBox(
                              width: 32,
                              height: 30,
                              child: Icon(Icons.shopping_cart_outlined, color: Colors.white, size: 17),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 7),
                    Row(
                      children: [
                        const Icon(
                          Icons.card_giftcard_rounded,
                          size: 15,
                          color: Color(0xFFD69A22),
                        ),
                        const SizedBox(width: 5),
                        Expanded(
                          child: Text(
                            'نقاط المكافأة: ${p.rewardPoints} نقطة',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w800,
                              color: Color(0xFF8A6416),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _placeholder(String cat, bool loading) {
    return Container(
      color: const Color(0xFFF2F4F7),
      child: Center(
        child: loading
            ? const SizedBox(
                width: 22,
                height: 22,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: astroGold,
                ),
              )
            : Icon(
                cat == 'هواتف'
                    ? Icons.smartphone_rounded
                    : Icons.headphones_rounded,
                size: 55,
                color: astroNavy.withOpacity(.3),
              ),
      ),
    );
  }

  String _categoryAsset(String name) {
    final value = name.trim().toLowerCase();
    if (value.contains('هواتف') || value.contains('هاتف') ||
        value.contains('موبايل') || value.contains('جوال') || value.contains('phone')) {
      return 'assets/category_phones.jpg';
    }
    if (value.contains('كمال') || value.contains('اكسسوار') ||
        value.contains('إكسسوار') || value.contains('سما') ||
        value.contains('aux') || value.contains('وصلا') || value.contains('كفر')) {
      return 'assets/category_accessories.jpg';
    }
    if (value.contains('مستعمل') || value.contains('used')) {
      return 'assets/category_used.jpg';
    }
    if (value.contains('لوح') || value.contains('تابلت') || value.contains('tablet')) {
      return 'assets/category_tablets.jpg';
    }
    if (value.contains('ساع') || value.contains('watch')) {
      return 'assets/category_watches.jpg';
    }
    if (value.contains('شبك') || value.contains('راوتر') || value.contains('router') || value.contains('رينج')) {
      return 'assets/category_network.jpg';
    }
    if (value.contains('عرض') || value.contains('خصم') || value.contains('offer')) {
      return 'assets/category_offers.jpg';
    }
    return 'assets/category_other.jpg';
  }

  IconData _categoryIcon(String name) {
    final value = name.trim().toLowerCase();

    if (value.contains('هواتف') || value.contains('هاتف') ||
        value.contains('موبايل') || value.contains('جوال') ||
        value.contains('phone')) {
      return Icons.smartphone_rounded;
    }
    if (value.contains('كمال') || value.contains('اكسسوار') ||
        value.contains('إكسسوار') || value.contains('سما') ||
        value.contains('headphone')) {
      return Icons.headphones_rounded;
    }
    if (value.contains('مستعمل') || value.contains('used')) {
      return Icons.recycling_rounded;
    }
    if (value.contains('لوح') || value.contains('تابلت') ||
        value.contains('tablet')) {
      return Icons.tablet_android_rounded;
    }
    if (value.contains('ساع') || value.contains('watch')) {
      return Icons.watch_rounded;
    }
    if (value.contains('كمبيوتر') || value.contains('لابتوب') ||
        value.contains('حاسوب') || value.contains('computer')) {
      return Icons.laptop_chromebook_rounded;
    }
    return Icons.widgets_rounded;
  }

  Widget _buildCategoriesPage({
    required List<StoreCategory> rootCategories,
    required List<StoreCategory> categories,
    required List<Product> products,
  }) {
    StoreCategory? selectedRoot;
    for (final item in rootCategories) {
      if (item.id == categoryPageRootId) {
        selectedRoot = item;
        break;
      }
    }

    final subcategories = selectedRoot == null
        ? <StoreCategory>[]
        : (categories
            .where((item) =>
                item.parentId == selectedRoot!.id && item.isActive)
            .toList()
          ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder)));

    final visibleProducts = selectedRoot == null
        ? <Product>[]
        : products.where((product) {
            final matchesRoot = product.category == selectedRoot!.name;
            final matchesSubcategory = categoryPageSubcategoryId == null ||
                product.subcategoryId == categoryPageSubcategoryId;
            return matchesRoot && matchesSubcategory;
          }).toList();

    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 22, 18, 12),
            child: Row(
              children: [
                if (selectedRoot != null)
                  IconButton(
                    tooltip: 'العودة إلى جميع الأقسام',
                    onPressed: () => setState(() {
                      categoryPageRootId = null;
                      categoryPageSubcategoryId = null;
                    }),
                    icon: const Icon(Icons.arrow_forward_rounded,
                        color: astroNavy),
                  ),
                Expanded(
                  child: Text(
                    selectedRoot == null ? 'جميع الأقسام' : selectedRoot.name,
                    style: const TextStyle(
                      color: astroNavy,
                      fontSize: 21,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
                if (selectedRoot != null)
                  TextButton(
                    onPressed: () => setState(() {
                      categoryPageSubcategoryId = null;
                    }),
                    child: const Text('كل المنتجات'),
                  ),
              ],
            ),
          ),
        ),
        if (selectedRoot == null) ...[
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
            sliver: SliverGrid(
              delegate: SliverChildBuilderDelegate(
                (context, index) {
                  final item = rootCategories[index];
                  final childCount = categories
                      .where((category) =>
                          category.parentId == item.id && category.isActive)
                      .length;
                  final categoryIcon = _categoryIcon(item.name);
                  final categoryAsset = _categoryAsset(item.name);
                  return Material(
                    color: Colors.transparent,
                    borderRadius: BorderRadius.circular(20),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(20),
                      onTap: () => setState(() {
                        categoryPageRootId = item.id;
                        categoryPageSubcategoryId = null;
                      }),
                      child: Ink(
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            begin: Alignment.topRight,
                            end: Alignment.bottomLeft,
                            colors: [Colors.white, Color(0xFFF0F7FF)],
                          ),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: const Color(0xFFDCE9F6),
                            width: 1.1,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: astroNavy.withOpacity(.055),
                              blurRadius: 13,
                              offset: const Offset(0, 5),
                            ),
                          ],
                        ),
                        padding: const EdgeInsets.fromLTRB(14, 15, 14, 13),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              width: 76,
                              height: 76,
                              padding: const EdgeInsets.all(7),
                              decoration: BoxDecoration(
                                gradient: const LinearGradient(
                                  colors: [Color(0xFFEAF4FF), Color(0xFFDCEEFF)],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                ),
                                borderRadius: BorderRadius.circular(19),
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(13),
                                child: Image.asset(
                                  categoryAsset,
                                  fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) => Icon(
                                    categoryIcon,
                                    color: astroBlue,
                                    size: 34,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(height: 12),
                            Text(
                              item.name,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                color: astroNavy,
                                fontSize: 16,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                            const SizedBox(height: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 4,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(.9),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Text(
                                childCount == 0
                                    ? 'تصفح المنتجات'
                                    : '$childCount أقسام فرعية',
                                style: const TextStyle(
                                  color: Color(0xFF6B7F93),
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
                childCount: rootCategories.length,
              ),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 1.12,
              ),
            ),
          ),
          if (products.isNotEmpty) ...[
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(18, 2, 18, 12),
                child: Row(
                  children: [
                    const Expanded(
                      child: Text(
                        'منتجات مختارة',
                        style: TextStyle(color: astroNavy, fontSize: 18, fontWeight: FontWeight.w900),
                      ),
                    ),
                    Text('${products.length} منتج', style: const TextStyle(color: Colors.black45, fontSize: 12)),
                  ],
                ),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              sliver: SliverGrid(
                delegate: SliverChildBuilderDelegate(
                  (context, index) => _product(products[index]),
                  childCount: products.length > 4 ? 4 : products.length,
                ),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 14,
                  crossAxisSpacing: 14,
                  childAspectRatio: .72,
                ),
              ),
            ),
          ],
        ] else ...[
          if (subcategories.isNotEmpty)
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(0, 0, 0, 12),
                child: SizedBox(
                  height: 44,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: subcategories.length + 1,
                    separatorBuilder: (_, __) => const SizedBox(width: 8),
                    itemBuilder: (context, index) {
                      if (index == 0) {
                        return _subcategoryChip(
                          'الكل',
                          categoryPageSubcategoryId == null,
                          () => setState(
                            () => categoryPageSubcategoryId = null,
                          ),
                        );
                      }
                      final item = subcategories[index - 1];
                      return _subcategoryChip(
                        item.name,
                        categoryPageSubcategoryId == item.id,
                        () => setState(
                          () => categoryPageSubcategoryId = item.id,
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 12, 18, 10),
              child: Row(
                children: [
                  const Expanded(
                    child: Text(
                      'المنتجات',
                      style: TextStyle(
                        color: astroNavy,
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                  Text(
                    '${visibleProducts.length} منتجات',
                    style: const TextStyle(
                        color: Colors.black45, fontSize: 12),
                  ),
                ],
              ),
            ),
          ),
          if (visibleProducts.isEmpty)
            const SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.all(28),
                child: Center(
                  child: Text(
                    'لا توجد منتجات في هذا القسم حالياً',
                    style: TextStyle(color: Colors.black54),
                  ),
                ),
              ),
            )
          else
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              sliver: SliverGrid(
                delegate: SliverChildBuilderDelegate(
                  (context, index) => _product(visibleProducts[index]),
                  childCount: visibleProducts.length,
                ),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 14,
                  crossAxisSpacing: 14,
                  childAspectRatio: .72,
                ),
              ),
            ),
        ],
      ],
    );
  }

  Widget _buildStorePage(List<Product> products) {
    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 18, 18, 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('المتجر', style: TextStyle(color: astroNavy, fontSize: 22, fontWeight: FontWeight.w900)),
                const SizedBox(height: 12),
                TextField(
                  controller: storeSearch,
                  onChanged: (_) => setState(() {}),
                  textInputAction: TextInputAction.search,
                  decoration: InputDecoration(
                    hintText: 'ابحث عن منتج أو قسم أو علامة تجارية...',
                    prefixIcon: const Icon(Icons.search, color: astroBlue),
                    suffixIcon: storeSearch.text.isEmpty ? null : IconButton(
                      icon: const Icon(Icons.close),
                      onPressed: () { storeSearch.clear(); setState(() {}); },
                    ),
                    filled: true, fillColor: Colors.white,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
                  ),
                ),
              ],
            ),
          ),
        ),
        if (products.isEmpty)
          const SliverToBoxAdapter(child: Padding(padding: EdgeInsets.all(30), child: Center(child: Text('لا توجد منتجات مطابقة'))))
        else
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
            sliver: SliverGrid(
              delegate: SliverChildBuilderDelegate((context, index) => _product(products[index]), childCount: products.length),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 14, crossAxisSpacing: 14, childAspectRatio: .66),
            ),
          ),
      ],
    );
  }

  Widget _buildHomeSectionProductsPage(String title, List<Product> products) {
    // This page is rendered without the main AppBar, so keep its header below
    // the Android status bar and separate the back control from long Arabic titles.
    return SafeArea(
      top: true,
      bottom: false,
      child: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsetsDirectional.fromSTEB(12, 8, 16, 14),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(
                    width: 44,
                    height: 44,
                    child: IconButton(
                      padding: EdgeInsets.zero,
                      tooltip: 'رجوع',
                      onPressed: () => setState(() {
                        _activeHomeSectionTitle = null;
                        _activeHomeSectionProducts = null;
                      }),
                      icon: const Icon(Icons.arrow_forward_rounded, color: astroNavy),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      title,
                      textAlign: TextAlign.right,
                      maxLines: 2,
                      softWrap: true,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: astroNavy,
                        fontSize: 20,
                        height: 1.25,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        if (products.isEmpty)
          const SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.all(30),
              child: Center(child: Text('لا توجد منتجات في هذا القسم حالياً')),
            ),
          )
        else
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
            sliver: SliverGrid(
              delegate: SliverChildBuilderDelegate(
                (context, index) => _product(products[index]),
                childCount: products.length,
              ),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 14,
                crossAxisSpacing: 14,
                childAspectRatio: .66,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _managedHomeSections(List<Product> sourceProducts) {
    return StreamBuilder<List<Map<String, dynamic>>>(
      stream: Supabase.instance.client
          .from('home_page_sections')
          .stream(primaryKey: ['section_key']),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const SizedBox.shrink();
        final rows = [...snapshot.data!]
          ..sort((a, b) => (a['sort_order'] as num? ?? 0)
              .compareTo(b['sort_order'] as num? ?? 0));
        final sections = <Widget>[];
        for (final row in rows) {
          if (row['is_enabled'] == false) continue;
          final rawIds = row['product_ids'];
          if (rawIds is! List || rawIds.isEmpty) continue;
          // Preserve the exact product order selected by the administrator.
          final ids = rawIds.map((value) => value.toString()).toList();
          final productsById = <String, Product>{
            for (final product in sourceProducts) product.id: product,
          };
          final selected = ids
              .map((id) => productsById[id])
              .whereType<Product>()
              .toList();
          if (selected.isEmpty) continue;
          final key = '${row['section_key'] ?? ''}';
          final badge = switch (key) {
            'best_selling' => 'الأكثر طلباً',
            'used' => 'مستعمل',
            'accessories' => 'كماليات',
            'budget' => 'سعر مناسب',
            _ => 'اختيارات ASTRO',
          };
          sections.add(_homeProductSection(
            title: '${row['title'] ?? 'منتجات مختارة'}',
            products: selected,
            badge: badge,
            onViewAll: () {
              setState(() {
                _activeHomeSectionTitle = '${row['title'] ?? 'منتجات مختارة'}';
                _activeHomeSectionProducts = List<Product>.unmodifiable(selected);
              });
            },
          ));
        }
        if (sections.isEmpty) return const SizedBox.shrink();
        return Column(children: sections);
      },
    );
  }

  Widget _navItem(int i, IconData icon, String label) {
    final active = nav == i;

    return Expanded(
      child: InkWell(
        onTap: () {
          setState(() {
            _activeHomeSectionTitle = null;
            _activeHomeSectionProducts = null;
            nav = i;
            if (i == 1) {
              categoryPageRootId = null;
              categoryPageSubcategoryId = null;
            }
          });
        },
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              width: active ? 38 : 32,
              height: active ? 30 : 27,
              decoration: BoxDecoration(
                color: active ? astroBlue : Colors.transparent,
                borderRadius: BorderRadius.circular(18),
              ),
              child: Icon(
                icon,
                color: active ? Colors.white : const Color(0xFF53657A),
                size: active ? 19 : 21,
              ),
            ),
            const SizedBox(height: 3),
            Text(
              label,
              style: TextStyle(
                fontSize: 10,
                color: active ? astroBlue : const Color(0xFF53657A),
                fontWeight: active ? FontWeight.w900 : FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
